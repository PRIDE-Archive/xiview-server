import multiprocessing as mp
import queue as Q
import argparse
import tempfile
import sys
import re
import os
import traceback
import time
import copy
import getpass
from dirlock import DirLock
import setuptools_scm
from .search import SearchContext, SpectrumProcessor
from .result_writer import TsvResultWriter, DummyResultWriter, ParguetResultWriter, \
    RecaliResultWriter
from .load_test import LoadTest, load_test_config, RealDataLoadTest
from .xi_logging import log_enable, progress_enable, log, ProgressBar, log_file
from .config import Config, ConfigReader
from .cache import Cache
from .spectra_reader import PeakListWrapper
from .lookup import EmptyDatabase
import threading
import signal

child_pids = None


def dump_all_thread_traces():
    """Return a formatted string with stack traces for all threads in the current process."""
    result = []
    frames = sys._current_frames()
    threads = {t.ident: t for t in threading.enumerate()}
    for thread_id, frame in frames.items():
        thread = threads.get(thread_id)
        thread_name = thread.name if thread else "Unknown"
        result.append(
            f"\n--- Thread ID: {thread_id} | Name: {thread_name} ---\n"
            + "".join(traceback.format_stack(frame))
        )
    return "".join(result)


# signal handlers for SIGTERM to return also the current stack trace before being killed
def handle_sigterm(signum, frame):
    print(f"\n[PID {os.getpid()}] Received SIGTERM. Stack trace:")
    traceback.print_stack(frame)
    sys.exit(0)


def handle_sigusr1_child(signum, frame):
    """
    Handle SIGUSR1 signal in child processes.

    This function dumps the stack trace of all threads in the
    current process and logs it.
    """
    pid = os.getpid()
    try:
        pname = mp.current_process().name
    except Exception:
        pname = "unknown name"
    message = (
        f"\n[PID {pid}] [{pname}] Received SIGUSR1. Stack trace:\n"
        f"{dump_all_thread_traces()}"
    )
    try:
        log(message)
    except Exception:
        print(f"Logging failed: {message}")
    print(message)


def handle_sigusr1_parent(signum, frame):
    """
    Handle SIGUSR1 signal in the parent process.

    This function dumps the stack trace of all threads in the
    current process and logs it. It also sends the SIGUSR1 signal to all
    child processes to dump their stack traces.
    """
    pid = os.getpid()
    message = (
        f"\n[Main PID {pid}] Received SIGUSR1. Stack trace:\n"
        f"{dump_all_thread_traces()}"
    )
    try:
        log(message)
    except Exception:
        print(f"Logging failed: {message}")
    print(message)

    if len(child_pids) == 0:
        try:
            log("No child processes found to dump traces.")
        except Exception:
            print("Logging failed: No child processes found to dump traces.")
        return
    try:
        log("child traces")
    except Exception:
        print("Logging failed: child traces")
    old_pids = []
    for pid in child_pids:
        # make sure each process has time to write out its own block
        try:
            os.kill(pid, signal.SIGUSR1)
            time.sleep(1)
        except ProcessLookupError:
            old_pids.append(str(pid))
    if len(old_pids) > 0:
        try:
            log(f"Child processes {','.join(old_pids)} not found anymore")
        except Exception:
            print(f"Logging failed: Child processes {','.join(old_pids)} not found anymore")


# Initializer for worker processes used for propagating signal sigusr1
def init_worker():
    pid = os.getpid()
    child_pids.append(pid)
    signal.signal(signal.SIGUSR1, handle_sigusr1_child)
    try:
        log(f"[Worker PID {pid}] Initialized")
    except Exception:
        print(f"Logging failed: [Worker PID {pid}] Initialized")


# From python 3.14, spawning will be the default.
# Windows does not support forking. When working on windows compatiblity, use 'spawn' method.
# For spawning, all objects that are used in the new process need to be importable/initialisable
# from __main__. The XiSearch class might help with this.
# As for now, the code only works with 'fork' method, because there are some global variables
# that cannot be imported as they are dependend on user options (see comment below).
mp.set_start_method('fork', force=True)

# ### Variables needed globally for multiprocessing.
# The multiprocessing variables need to be set globally because they are used in multiprocessing.
# The following methods used in the multiprocessing need to be pickable (second level functions are
# not pickable) but also depend on user options. Therefore, some variables are initiated globally
# before they get their final value. For using multiprocessing with the 'spawn' method (see comment
# above), the user dependent variables need to be importable/initialisable from __main__, which is
# not supported at the moment.
#
# The following methods are affected by this:
# ## write_queue
# write_queue uses the result_queue to write out the results but also needs result_writer, which
# is dependend on the user options.
# ## bar_updater
# bar_updater uses bar_queue to update the progress bar, which is dependend on the user options.
# ## process_spectrum_wrapper
# process_spectrum_wrapper uses the result_queue, the bar_queue (if requested) and the processor.
# The processor needs the context to be set, which in turn is depended on user options.
result_writer = []
processor = None
result_queue = None
bar_queue = None
# writer_process needs to be global - so I can make sure it is killed if the main process dies
writer_process = None


def write_queue(queue, keep_writing, writing_finished):
    init_worker()
    while keep_writing.value:
        try:
            s = queue.get(True, 1)
            while len(s.matches) > 0:
                for rw in result_writer:
                    rw.write(s)
                s = queue.get(False)
        except Q.Empty:
            ...
    for rw in result_writer:
        rw.close()
    writing_finished.value = True


def bar_updater(bar):
    init_worker()
    while True:
        s = bar_queue.get()
        if s:
            bar.next()
        else:
            return


# This is a dummy function that is then overwritten in the XiSearch class.
# It is needed to be able to use the function in the multiprocessing.
def process_spectrum_wrapper(spectrum):
    pass


def process_spectrum_wrapper_noprogressbar(spectrum):
    try:
        processor.process_spectrum(spectrum, result_queue)
    except Exception:
        traceback.print_exc()
        return False
    return True


def process_spectrum_wrapper_progressbar(spectrum):
    try:
        processor.process_spectrum(spectrum, result_queue)
        bar_queue.put(True)
    except Exception:
        traceback.print_exc()
        return False
    return True


class OptionsParser(argparse.ArgumentParser):
    '''
    Options wrapper for the user options.
    '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.add_argument(
            "-f",
            "--fasta",
            dest="fasta",
            action="append",
            help="FASTA file with proteins to search against",
            metavar="DB",
        )
        self.add_argument(
            "-b",
            "--no-bar",
            dest="progress_bar",
            default=True,
            action="store_false",
            help="Show progress bar",
        )
        self.add_argument(
            "-c", "--config",
            dest="config",
            help="JSON configuration file",
            metavar="JSON"
        )
        self.add_argument(
            "-i",
            "--input",
            dest="mgf",
            action="append",
            help="Path to file with spectra to search (MGF, mzML, Thermo RAW)",
            metavar="MGF",
        )
        self.add_argument(
            "-o",
            "--output",
            dest="tsv",
            help="TSV file to output search results",
            metavar="TSV",
        )
        self.add_argument(
            "-q",
            "--parquet-output",
            dest="parquet",
            help="parquet file to output search results",
            metavar="parquet",
        )
        self.add_argument(
            "--parquet-buffer-size",
            dest="parquet_buffer",
            default=1000,
            help="parquet file are written in batches of [parquet-buffer-size] matches",
            metavar="parquet",
        )
        self.add_argument(
            "-C",
            "--cache",
            dest="cache",
            help="Cache directory (default is system temp dir)",
            metavar="DIR",
        )
        self.add_argument(
            "-s",
            "--setup-only",
            dest="setup_only",
            default=False,
            action="store_true",
            help="Run setup only",
        )
        self.add_argument(
            "-l",
            "--load-test",
            dest="load_test",
            help="Run load test with N synthetic spectra",
            metavar="N",
            type=int,
        )
        self.add_argument(
            "-L",
            "--load-test-real",
            dest="load_test_real",
            help="Run load test with real data. Valid options: "
            + ", ".join(RealDataLoadTest.test_cases),
            metavar="TYPE",
        )
        self.add_argument(
            "-w",
            "--write-test",
            dest="write_test",
            action="store_const",
            const=tempfile.gettempdir(),
            help="Write out load test results to system temp dir",
        )
        self.add_argument(
            "-p",
            "--profile",
            dest="profile",
            default=False,
            action="store_true",
            help="Profile application code only",
        )
        self.add_argument(
            "-P",
            "--profile-all",
            dest="profile_all",
            default=False,
            action="store_true",
            help="Profile entire code stack",
        )
        self.add_argument(
            "-S",
            "--profile-statistic",
            dest="profile_statistic",
            default=False,
            action="store_true",
            help="Use a statisical profiler",
        )
        self.add_argument(
            "--log",
            dest="log_file",
            help="Write logging output to file",
            metavar="TYPE",
        )
        self.add_argument(
            "-O",
            "--config-option",
            dest="additional_config_options",
            default=[],
            action="append",
            help="additional config-option to be evaluated",
        )
        self.add_argument(
            "--pg",
            action="store_true",
            dest="pg_sql",
            default=False,
            help="Enable writing output to PostgreSQL",
        )
        self.add_argument(
            "-n",
            "--pg-search-name",
            dest="result_name",
            help="Name for the new result set to write",
            metavar="NAME",
            default="",
        )
        self.add_argument(
            "-N",
            "--pg-search-note",
            dest="result_note",
            help="Note for the new result set to write",
            metavar="NOTE",
            default="",
        )
        self.add_argument(
            "--pg-hostname",
            dest="pg_hostname",
            default=None,
            help="Hostname of PostgreSQL server to connect to",
        )
        self.add_argument(
            "--pg-port",
            dest="pg_port",
            default=5432,
            help="TCP port to use for connecting to PostgreSQL",
        )
        self.add_argument(
            "--pg-username",
            dest="pg_username",
            default=None,
            help="Username to use for connecting to PostgreSQL",
        )
        self.add_argument(
            "--pg-password",
            dest="pg_password",
            default=None,
            help="Password to use for connecting to PostgreSQL",
        )
        self.add_argument(
            "--pg-database",
            dest="pg_database",
            default=None,
            help="Database to use after connecting to PostgreSQL",
        )
        self.add_argument(
            "--pg-uuid",
            dest="pg_uuid",
            default=None,
            help="search UUID - if not given a new one is generated",
        )
        self.add_argument(
            "--pg-uuid-output",
            dest="pg_uuid_output",
            default=None,
            help="File to write the resulting search UUID",
        )
        self.add_argument(
            "-t", "--task",
            dest="cluster_task",
            default=0, type=int, metavar="N",
            help="defines that this is the nth task of all tasks (zero based)"
        )
        self.add_argument(
            "-T", "--total-tasks",
            dest="cluster_all_tasks",
            default=1, type=int, metavar="N",
            help="in how many tasks is the search split up"
        )
        self.add_argument(
            "--recalibration",
            dest="recali",
            default=False,
            action="store_true",
            help="perform search for recalibration",
        )
        self.add_argument(
            "--no_recalibration",
            dest="no_recali",
            default=False,
            action="store_true",
            help="don't perform search for recalibration",
        )
        self.add_argument(
            "--recalibration_only",
            dest="recali_only",
            default=False,
            action="store_true",
            help="only perform search for recalibration",
        )
        self.add_argument(
            "--recalibration_output",
            dest="recali_output",
            default=None,
            help="path to output directory for recalibration results",
        )
        self.add_argument(
            "--version",
            dest="print_version",
            default=False,
            action="store_true",
            help="print the xisearch2 version"
        )


def get_version():
    # Try to get version from version file
    try:
        from ._version import __version__
        return __version__
    except Exception:
        pass
    # Try to get version from workdir
    try:
        return setuptools_scm.get_version()
    except Exception:
        pass
    # No version found
    return "unkown"


def fail(message):
    log(message)
    sys.exit(1)


def validate_options(options):
    '''
    Validate the user options/command line arguments.
    '''
    message = ''

    if options.pg_sql:
        if not options.pg_hostname:
            message = 'PG hostname is required with PG result writer'
        if not options.pg_username:
            message = 'PG username is required with PG result writer'
        if not options.pg_database:
            message = 'PG database is required with PG result writer'
        if (not options.pg_uuid_output) and options.pg_uuid is None:
            message = 'PG UUID Output is required with PG result writer'

    if options.load_test and options.load_test_real:
        message = 'Choose either synthetic data or real data load test'

    if options.load_test or options.load_test_real:
        if options.mgf:
            message = 'Load test is mutually exclusive with input peaklist file name'
        if options.tsv:
            message = 'TSV output is not supported for load test'
        if options.parquet:
            message = 'Parquet output is not supported for load test'
    else:
        if options.write_test:
            message = 'write-test requires load-test option'
        if not options.mgf:
            message = 'input peaklist file name is required'
        if not options.pg_sql and not (options.tsv or options.parquet) and \
                not options.recali_only:
            message = 'TSV or parquet output file_name is required when not using PG result ' \
                      'writer'

    # check if we have valid settings for split processing
    if options.cluster_task is not None:
        if options.cluster_task >= options.cluster_all_tasks:
            message = '"task" (-t) has to be smaller then "all tasks" (-T)'

    if options.recali_only:
        options.recali = True

    if options.recali and options.no_recali:
        message("recalibration can not be enabled and disabled at the same time")

    if options.config:
        if not os.path.isfile(options.config):
            message = f'Config file {options.config} does not exist'
        else:
            # check if config is valid
            try:
                config = ConfigReader.load_file(options.config)
            except Exception as e:
                message = f'Config file {options.config} is not valid: {e}'

            # read if the config disabled recalibration
            if not (config.recalibrate_spectra or options.recali):
                # explicitly set no_recali
                options.no_recali = True
                options.recali_only = False
                options.recali_output = None

    if message != '':
        fail(message)


class XiSearch():
    '''
    The XiSearch class is the main class for running the search. It initiates the neccessary objects
    based on the user options and runs the search. It also initiates the recalibration search
    (another XiSearch instance) if requested.
    '''
    def __init__(self, options, is_recali=False, context=None):
        '''
        Initiate the XiSearch class. Parse user options, and set the context,
        config, processor, and result_writer.

        :param options: argparse options
        :param is_recali: boolean to indicate if the search is for recalibration
        :param context: search context to be used for the recalibration search
        '''
        if not options.fasta and not options.load_test_real:
            fail('FASTA protein database file_name is required')

        self.options = copy.deepcopy(options)
        self.is_recali = is_recali
        self.result_writer = []

        if is_recali and context is None:
            fail('Recalibration search requires a context object')

        # Select cache
        if self.options.cache:
            cache_directory = self.options.cache
        else:
            cache_directory = os.path.join(tempfile.gettempdir(), getpass.getuser(),
                                           "xisearch2", "cache")

        log("Cache directory used: " + cache_directory)

        # Create cache directory if it does not exist yet
        os.makedirs(cache_directory, exist_ok=True)

        self.cache = Cache(cache_directory)

        # Load config from file or create new config
        if self.options.load_test:
            test = LoadTest(self.cache, n_spectra=self.options.load_test)
            self.set_config(load_test_config)
        elif self.options.load_test_real:
            test = RealDataLoadTest(self.options.load_test_real)
            self.options.fasta = test.fasta
            self.set_config(test.config)
        elif self.options.config:
            self.set_config(ConfigReader.load_file(self.options.config))
        else:
            self.set_config(Config())

        for o in self.options.additional_config_options:
            exec("self.config." + o)

        # Set recalibration specific options and settings and initiate new Config
        if is_recali:
            # set recalibration specific options
            self.options.pg_sql = None
            self.options.tsv = None

            # set recalibration specific settings
            ms1_tol, ms1_tol_unit = self.config.parse_ms_tol(self.config.ms1_tol)
            ms2_tol, ms2_tol_unit = self.config.parse_ms_tol(self.config.ms2_tol)
            # increase the tolerances for recalibration search as that defines
            # the window in wich the recalibration can happen
            self.config.ms1_tol = f'{5 * ms1_tol} {ms1_tol_unit}'
            self.config.ms2_tol = f'{5 * ms2_tol} {ms2_tol_unit}'
            self.config.crosslinker = []
            self.config.reporting_requirements.report_top_ranking_only = True
            self.config.noncovalent_peptides = False
            # the context is transferred from the main search, so the proteins are not digested
            # again
            # self.config.digestion.missed_cleavages = 2
            # self.config.modification.modifications = []
            # TODO: might want to flag modifications as excluded from recalibration
            # self.config.modification.modifications = \
            #      [x for x in self.config.modification.modifications if not x.no_recali]

            # initiate new Config (sets instance variables and checks validity of config).
            self.set_config(self.config)

            # Create result directory if it does not exist yet
            if self.options.recali_output is None and\
                    not (self.options.tsv is None and self.options.parquet is None):
                if self.options.tsv is not None:
                    os.makedirs(os.path.dirname(self.options.tsv), exist_ok=True)
                    self.options.recali_output = re.sub(r'.tsv$', '', self.options.tsv,
                                                        flags=re.I) + '.recali'
                    os.makedirs(os.path.dirname(self.options.recali_output), exist_ok=True)
                elif self.options.parquet is not None:
                    os.makedirs(os.path.dirname(self.options.parquet), exist_ok=True)
                    self.options.recali_output = re.sub(r'.parquet$', '', self.options.parquet,
                                                        flags=re.I) + '.recali'
                    os.makedirs(os.path.dirname(self.options.recali_output), exist_ok=True)

            if self.options.recali_output is None:
                t = hex(time.time_ns())
                self.options.recali_output = os.path.join(tempfile.gettempdir(),
                                                          getpass.getuser(), "xisearch2",
                                                          "recali_" + t)

            os.makedirs(self.options.recali_output, exist_ok=True)

            self.context = context
            # the config needs to be replaced with the current one, and changed back later
            self.original_config = self.context.config
            self.context.config = self.config
            self.context.set_tolerances_and_errors()

            # the fragment_db is replaced with an empty one, and changed back later
            self.original_fragment_db = self.context.fragment_db
            self.context.fragment_db = EmptyDatabase()
        else:
            self.context = SearchContext(
                self.options.fasta,
                self.config,
                self.cache,
                search_uuid=self.options.pg_uuid,
                this_task=self.options.cluster_task,
                all_tasks=self.options.cluster_all_tasks
            )

        # Create processor based on context
        self.processor = SpectrumProcessor(self.context)

        if self.options.progress_bar:
            self.process_spectrum_wrapper = process_spectrum_wrapper_progressbar
        else:
            self.process_spectrum_wrapper = process_spectrum_wrapper_noprogressbar

        if self.options.load_test or self.options.load_test_real:
            test.setup(self.context)
            if self.options.setup_only:
                sys.exit(0)

            self.options.mgf = test.mgf
            if self.options.write_test:
                out_file = os.path.join(self.options.write_test, "load_test.tsv")
                self.result_writer.append(TsvResultWriter(out_file, self.context))
            else:
                self.result_writer.append(DummyResultWriter(self.context))

        else:
            if self.options.setup_only:
                sys.exit(0)

            if self.options.pg_sql:
                from .pg_result_writer import PGResultWriter
                json_config = open(self.options.config, "r").read()
                self.result_writer.append(PGResultWriter(
                    self.options.pg_hostname,
                    self.options.pg_port,
                    self.options.pg_username,
                    self.options.pg_password,
                    self.options.pg_database,
                    self.options.pg_uuid_output,
                    json_config,
                    self.context,
                    self.options.result_name,
                    self.options.result_note,
                ))

        log("Loading spectra")
        self.spectra_wrapper = PeakListWrapper(self.context)
        self.spectra_wrapper.load(self.options.mgf)
        self.num_spectra = self.spectra_wrapper.count_spectra()
        log("Loaded %d spectra" % self.num_spectra)

        if is_recali:
            self.recali_conf_out_path = os.path.join(self.options.recali_output,
                                                     'recalibrated_config.json')
            self.recali_lock_file = self.recali_conf_out_path + '.lock'
            self.result_writer.append(
                RecaliResultWriter(self.context, self.options.recali_output,
                                   self.recali_conf_out_path, self.recali_lock_file,
                                   self.original_config))

        # Append result writers
        if self.options.tsv:
            os.makedirs(os.path.dirname(self.options.tsv), exist_ok=True)

            self.result_writer.append(TsvResultWriter(self.options.tsv, self.context))

        if self.options.parquet:
            os.makedirs(os.path.dirname(self.options.parquet), exist_ok=True)

            self.result_writer.append(
                ParguetResultWriter(self.options.parquet, self.context,
                                    cache_size=self.options.parquet_buffer))

    def setup_globals(self):
        '''
        Setup the global variables result_writer, processor and process_spectrum_wrapper.
        '''
        global result_writer
        global processor
        global process_spectrum_wrapper

        result_writer = self.result_writer
        processor = self.processor
        process_spectrum_wrapper = self.process_spectrum_wrapper

    def _search(self):
        '''
        Execute the search.
        '''
        # This is a shared value to be used with the writer process: it allows us to let
        # the writer know that we are done processing and the writer can close itself.
        keep_writing = mp.Value("b", True)
        # Shared value to get feedback from the writer when it is done writing out.
        writing_finished = mp.Value("b", False)

        global result_queue
        # use the global writer process variable - so it can be termintated if there is an
        # unexpected crash somehwere in here
        global writer_process
        result_queue = mp.Queue()

        # writer process can't be a daemon process, as at least the recalibration writer needs to
        # be able to spawn new processes
        writer_process = mp.Process(
            target=write_queue,
            args=(result_queue, keep_writing, writing_finished),
            daemon=False,
        )
        writer_process.start()

        log("Starting search")

        if self.options.progress_bar:
            global bar_queue
            bar_queue = mp.Queue()
            bar = ProgressBar("Processing spectra", self.num_spectra)
            bar_process = mp.Process(target=bar_updater, args=(bar, ), daemon=True)
            bar_process.start()

        if self.options.profile:
            if self.options.profile_statistic:
                try:
                    from pprofile import StatisticalProfile
                except ImportError:
                    raise ImportError("The StatisticalProfile module could not be imported - run "
                                      "pipenv -d install")
                profile = StatisticalProfile()
            else:
                try:
                    from pprofile import Profile
                except ImportError:
                    raise ImportError("The Profile module could not be imported - run "
                                      "pipenv -d install")
                profile = Profile()

            with profile():
                for spectrum in self.spectra_wrapper.spectra:
                    process_spectrum_wrapper(spectrum)
            if self.options.profile_all:
                filenames = profile.getFilenameSet()
            else:
                filenames = {
                    f
                    for f in profile.getFilenameSet()
                    if f.startswith(os.path.dirname(__file__))
                }
            with open("callgrind.out", "w+") as f:
                profile.callgrind(f, commandline=" ".join(sys.argv), filename=filenames)

        else:
            thread_count = self.config.threads
            if thread_count <= 0:
                thread_count = mp.cpu_count() + thread_count

            if thread_count == 1:
                for spectrum in self.spectra_wrapper.spectra:
                    process_spectrum_wrapper(spectrum)
            else:
                thread_pool = mp.Pool(thread_count, initializer=init_worker)
                # process spectra across threads
                for r in thread_pool.imap_unordered(process_spectrum_wrapper,
                                                    self.spectra_wrapper.spectra, 10):
                    if not r:
                        raise Exception(
                            "Exception occurred during search! See stack trace above for details."
                        )

                # https://pytest-cov.readthedocs.io/en/latest/subprocess-support.html#if-you-use-multiprocessing-pool
                thread_pool.close()  # Marks the pool as closed.
                thread_pool.join()  # Waits for workers to exit.

        # end progress bar
        if self.options.progress_bar:
            bar.finish()
            bar_queue.put(False)
            bar_queue.close()
            bar_queue.join_thread()
            bar_process.join(1)

        # tell the writer we're done and wait for it to stop
        keep_writing.value = False
        # Not sure why we need the next 5 lines, just a `writer_process.join()` should be
        # enough. But for some reason, the writer_process doesn't always die, and then the
        # `join` doesn't return.
        log("Search finished, waiting for result writer to complete...")
        result_queue.close()
        result_queue.join_thread()
        # Wait for the writer to finish writing
        # initially for 30 seconds
        writer_process.join(30)
        write_wait_time = 0
        while not writing_finished.value:
            log("Writing not finished. Still waiting...")
            time.sleep(30)
            write_wait_time += 30
            if write_wait_time >= 1800:
                write_time_out_msg = (
                    "Writing timeout! Writing did not finish in 30 minutes. Writing aborted."
                )
                log(write_time_out_msg)
                writer_process.terminate()
                raise TimeoutError(write_time_out_msg)

    def _recalibrate(self):
        '''
        Run the recalibration search for each peak-list file.
        '''
        log('Recalibration search started.')
        self._search()
        log('Recalibration search finished.')

        if self.options.recali_only:
            if self.options.cluster_all_tasks > 1:
                log('Recalibration only, not waiting for last task to finish.')
        else:
            # if running with serveral tasks (-t and -T arguments) wait for last task to finish
            while True:
                time.sleep(30)
                with DirLock(self.recali_lock_file):
                    try:
                        self.set_config(ConfigReader.load_file(self.recali_conf_out_path))
                    except FileNotFoundError:
                        log('Config file not found. Waiting for last task to finish. Trying again '
                            'in 30 seconds.')
                    else:
                        log('Collecting recalibration results.')
                        break

            # rest the fragment_db to the original one
            self.context.fragment_db = self.original_fragment_db

    def run(self):
        '''
        Run the search or recalibration search.
        '''
        # set up the global variables again according to the main search options
        self.setup_globals()

        if self.is_recali:
            self._recalibrate()
            log('Finished recalibration search(es)!')
        else:
            self._search()
            log('Finished search!')

    def init_recali(self):
        '''
        Initiate recalibration search with the same options as the main search.
        '''
        return XiSearch(self.options, is_recali=True, context=self.context)

    def set_config(self, config):
        '''
        Set the config and update the context with the new config.
        The Config object is newly initiated.

        :param config: Config object
        '''
        self.config = Config(**config.to_dict())
        if hasattr(self, 'context') and self.context is not None:
            self.context.config = self.config


if __name__ == "__main__":

    # Shared manager list for storing child PIDs
    manager = mp.Manager()
    child_pids = manager.list()

    # setup signal handlers for SIGTERM and SIGUSR1
    try:
        # sigterm is just a workaround, as I seem to receive sigterms during
        # running tests at time and that makes them fail
        signal.signal(signal.SIGTERM, handle_sigterm)
    except ValueError:
        log('SIGTERM signal handler could not be set. ')

    try:
        # sigusr1 is used to dump the stack trace of all threads in the main
        # process and then in all worker processes by forwarding the signal
        signal.signal(signal.SIGUSR1, handle_sigusr1_parent)
    except ValueError:
        log('SIGUSR1 signal handler could not be set.')

    parser = OptionsParser()
    options = parser.parse_args()

    log_enable(True)
    if options.log_file:
        log_file(options.log_file)

    if options.print_version:
        print(get_version())
        sys.exit(0)

    validate_options(options)

    log(f'Running xisearch2 version {get_version()}')
    # for sending sigusr1 signals it's best to know the process id
    log(f'PID {os.getpid()}')

    if options.profile_all:
        options.profile = True
    if options.profile_statistic:
        options.profile = True

    progress_enable(options.progress_bar)

    xisearch = XiSearch(options)

    if not options.no_recali:
        # initiate recalibration search
        recali = xisearch.init_recali()

        # run recalibration search
        try:
            recali.run()
        except Exception:
            log('Recalibration search failed! terminating'
                'writer process and exiting.')
            writer_process.terminate()
            raise

        # set recalibration results to main search
        xisearch.config.recalibration = recali.config.recalibration

        # make sure that the config is validated
        xisearch.set_config(xisearch.config)

        # set new tolerances is only run at initialisation of the Context
        # to update the existing context, we need to run the set_tolerances_and_errors method again
        xisearch.context.set_tolerances_and_errors()

    if not options.recali_only:
        # run main search
        try:
            xisearch.run()
        except Exception:
            log('Search failed! terminating writer process and exiting.')
            writer_process.terminate()
            raise
