"""
This module contains the ResultWriter classes for writing out xiSEARCH2 results.

Available ResultWriters are:
    - TsvResultWriter: writes results to tsv file
    - MemoryResultWriter: writes results to a list in memory
    - RecaliResultWriter: dumps needed results to pickle files and calculates
      mass errors and tolerances
"""

import re
import os
import math
import multiprocessing as mp
import hashlib
import glob
import pickle
from abc import ABC, abstractmethod
import pandas as pd
import numpy as np
import fastparquet as fp
import plotnine as p9
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde
from matplotlib.colors import CenteredNorm
import json
from dirlock import DirLock
from itertools import repeat
import time
from xisearch2.output_format import create_mod_str, create_mod_mass_str, create_mod_pos_str
from xisearch2.xi_logging import log
from xisearch2.config import RecalibrationConfig
from numpy.linalg import LinAlgError


class ResultWriter(ABC):
    """Base class for the different ways to write out search results."""

    # a list of columns to be writen out in csv format
    # columns only present for some searches can be marked as optional
    # by square brackets (i.e. turn them into single entry lists)
    ordered_output_columns = [
        'run_name',  # run name parsed from peaklist file
        'scan_index',  # index of the scan
        'scan_number',  # scan number
        'match_score',  # final score of the match
        'top_ranking',  # top ranking match for this scan
        'sequence_p1',  # AA sequence (incl. modifications) of p1
        'sequence_p2',  # AA sequence (incl. modifications) of p2
        'link_pos_p1',  # linked AA residue position in p1
        'link_pos_p2',  # linked AA residue position in p2
        'protein_p1',  # protein(s) p1 could come from
        'protein_p2',  # protein(s) p2 could come from
        'protein_link_p1',  # link position(s) in the protein(s) for p1
        'protein_link_p2',  # link position(s) in the protein(s) for p2
        'decoy_p1',  # if p1 is a decoy peptide
        'decoy_p2',  # if p2 is a decoy peptide
        'base_sequence_p1',  # AA seq without modifications of p1
        'base_sequence_p2',  # AA seq without modifications of p2
        'mass_p1',  # neutral mass of p1
        'mass_p2',  # neutral mass of p2
        'linked_aa_p1',  # Amino acid that is linked on p1
        'linked_aa_p2',  # Amino acid that is linked on p2
        'aa_len_p1',  # number of amino acids in p1
        'aa_len_p2',  # number of amino acids in p2
        'peaklist_file',  # name of the peaklist file
        'source',  # path to peaklist source
        'spectrum_mz',  # precursor mz from the spectrum
        'spectrum_charge',  # precursor charge state from the spectrum
        'precursor_mz',  # m/z of the precursor (potentially corrected)
        'precursor_missing_isotope_peak',  # how many missing isotopic peaks are assumed
        'precursor_charge',  # precursor charge state (potentially corrected)
        'precursor_mass',  # neutral mass of the precursor
        'precursor_intensity',  # intensity of the precursor
        'retention_time',  # retention time in seconds
        'calc_mass',  # theoretical/calculated mass
        'calc_mz',  # theoretical/calculated m/z
        'linear',  # linear or crosslinked peptide
        'crosslinker_name',  # name of the crosslinker
        'crosslinker_mass',  # mass of the crosslinker
        'start_pos_p1',  # start position(s) of p1 in the protein(s)
        'start_pos_p2',  # start position(s) of p2 in the protein(s)
        'fasta_p1',  # fasta header(s) of p1
        'fasta_p2',  # fasta header(s) of p2
        'position_count_p1',  # how often p1 occurs in the fasta(s)
        'position_count_p2',  # how often p2 occurs in the fasta(s)
        'protein_count_p1',  # in how many different proteins p1 occurs
        'protein_count_p2',  # in how many different proteins p2 occurs
        'mods_p1',  # modification(s) in p1
        'mods_p2',  # modification(s) in p2
        'mod_pos_p1',  # position(s) of modification(s) in p1
        'mod_pos_p2',  # position(s) of modification(s) in p2
        'mod_mass_p1',  # mass(es) of modification(s) in p1
        'mod_mass_p2',  # mass(es) of modification(s) in p2
        'alpha_id',  # alpha pep_id (1 or 2, if alpha pep is p1 or p2)
        'alpha_rank',  # rank of the alpha peptide
        'alpha_score',  # score of the alpha peptide
        'alpha_delta_score',  # delta score to the second best unique alpha score
        'beta_id',  # beta pep_id (1 or 2, if beta pep is p1 or p2)
        'beta_score',  # score of the beta peptide
        'beta_count',  # number of beta peptides found for this alpha peptide
        'beta_count_inverse',  # inverse of beta_count
        'alpha_beta_rank',  # rank of the alpha beta candidate
        'alpha_beta_score',  # score of the alpha beta candidate
        'alpha_beta_delta_score',  # delta score to the second best unique alpha_beta score
        'alpha_beta_sum',  # sum of alpha and beta scores
        # misc sub scores
        'link_score_site_p1',  # possible link sites on p1
        'link_score_site_p2',  # possible link sites on p2
        'link_score',  # scores for possible link sites
        'var_mod_count_p1',  # variable modification count of p1
        'var_mod_count_p2',  # variable modification count of p2
        'var_mod_count_pp',  # variable modification count of the peptide pair
        'total_fragments_p1',
        'total_fragments_p2',
        'total_fragments_pp',
        'primary_fragments_p1',
        'primary_fragments_p2',
        'primary_fragments_pp',
        'loss_fragments_p1',
        'loss_fragments_p2',
        'loss_fragments_pp',
        'all_fragsites_p1',
        'all_fragsites_p2',
        'all_fragsites_pp',
        'all_coverage_p1',
        'all_coverage_p2',
        'all_coverage_pp',
        'primary_fragsites_p1',
        'primary_fragsites_p2',
        'primary_fragsites_pp',
        'primary_coverage_p1',
        'primary_coverage_p2',
        'primary_coverage_pp',
        'loss_fragsites_p1',
        'loss_fragsites_p2',
        'loss_fragsites_pp',
        'loss_coverage_p1',
        'loss_coverage_p2',
        'loss_coverage_pp',
        'conservative_fragsites_p1',
        'conservative_fragsites_p2',
        'conservative_fragsites_pp',
        'conservative_coverage_p1',
        'conservative_coverage_p2',
        'conservative_coverage_pp',
        'conservative_multi_fragsites_p1',
        'conservative_multi_fragsites_p2',
        'conservative_multi_fragsites_pp',
        'conservative_multi_coverage_p1',
        'conservative_multi_coverage_p2',
        'conservative_multi_coverage_pp',
        'unique_peak_fragsites_p1',
        'unique_peak_fragsites_p2',
        'unique_peak_fragsites_pp',
        'unique_peak_coverage_p1',
        'unique_peak_coverage_p2',
        'unique_peak_coverage_pp',
        'unique_peak_primary_fragsites_p1',
        'unique_peak_primary_fragsites_p2',
        'unique_peak_primary_fragsites_pp',
        'unique_peak_primary_coverage_p1',
        'unique_peak_primary_coverage_p2',
        'unique_peak_primary_coverage_pp',
        'unique_peak_loss_fragsites_p1',
        'unique_peak_loss_fragsites_p2',
        'unique_peak_loss_fragsites_pp',
        'unique_peak_loss_coverage_p1',
        'unique_peak_loss_coverage_p2',
        'unique_peak_loss_coverage_pp',
        'unique_peak_conservative_fragsites_p1',
        'unique_peak_conservative_fragsites_p2',
        'unique_peak_conservative_fragsites_pp',
        'unique_peak_conservative_coverage_p1',
        'unique_peak_conservative_coverage_p2',
        'unique_peak_conservative_coverage_pp',
        'unique_peak_primary_crosslink_fragsites_p1',
        'unique_peak_primary_crosslink_fragsites_p2',
        'unique_peak_primary_crosslink_fragsites_pp',
        'unique_peak_conservative_crosslink_fragsites_p1',
        'unique_peak_conservative_crosslink_fragsites_p2',
        'unique_peak_conservative_crosslink_fragsites_pp',
        'sequence_tag_fragsites_p1',
        'sequence_tag_fragsites_p2',
        'sequence_tag_fragsites_pp',
        'sequence_tag_coverage_p1',
        'sequence_tag_coverage_p2',
        'sequence_tag_coverage_pp',
        'fragment_error_ppm_mean',
        'fragment_error_ppm_abs_mean',
        'fragment_error_ppm_abs_lin_p1_mean',
        'fragment_error_ppm_abs_lin_p2_mean',
        'fragment_error_ppm_abs_cl_mean',
        'fragment_error_ppm_mean_square',
        'fragment_error_ppm_mean_square_root',
        'fragment_error_normalized_mean',
        'fragment_error_1-normalized_mean',
        'precursor_error',
        'precursor_error_ppm',
        'precursor_error_ppm_abs',
        'precursor_error_normalized',
        'precursor_error_1-normalized',
        'frag_max_charge',
        'frag_mean_charge',
        'rel_frag_max_charge',
        'rel_frag_mean_charge',
        'intensity_coverage',
        'primary_intensity_coverage',
        'conservative_intensity_coverage',
        'isotope_intensity_coverage',
        'isotope_intensity_matched_fraction',
        'isotope_peak_matched_fraction',
        'single_peak_coverage',
        'top10_peak_coverage',
        'top10_peak_coverage_limited',
        'top20_peak_coverage',
        'top20_peak_coverage_limited',
        'top40_peak_coverage',
        'top40_peak_coverage_limited',
        'top100_peak_coverage',
        'top100_peak_coverage_limited',
        'total_peak_coverage',
        'fragment_library_score',
        'fragment_library_score_log',
        'fragment_library_score_exponential',
        # crosslinker stub scores
        ['cc_pep_frag_p1'],
        ['cc_pep_frag_p2'],
        ['cc_pep_frag_pp'],
        ['cc_pep_frag_min_error_ppm_p1'],
        ['cc_pep_frag_min_error_ppm_p2'],
        ['cc_pep_frag_min_error_ppm_pp'],
        ['cc_pep_frag_count_p1'],
        ['cc_pep_frag_count_p2'],
        ['cc_pep_frag_count_pp'],
        # delta scores
        'delta',
        'delta_mod',
        'delta_combined',
        # combined scores
        'spectrum_quality_score',
        'p1_score',
        'p2_score',
        'auto_validation',
    ]

    @abstractmethod
    def __init__(self, context):
        self.context = context

    @abstractmethod
    def write(self, result):
        """
        Write result.

        :param result: (np.array) result to write.
        """
        pass

    @abstractmethod
    def close(self):
        """Close the writer."""
        pass

    def put(self, result):
        self.write(result)

    def _to_dataframe(self, results):
        """
        Convert result to pandas DataFrame.

        :param results: (list of tuples) list of result tuples to convert.
            (np.array) spectrum match results.
            (np.array) protein link sites.
        :return:
        """
        context = self.context
        # convert numpy struct arrays to pandas Dataframes
        # For the result_df we need to create a DataFrame from each result an concatenate them
        # because the length of the string data types do not match.
        xl_names = np.array([xl.name for xl in context.config.crosslinker] + [''])
        xl_masses = np.array([xl.mass for xl in context.config.crosslinker] + [np.nan])
        result_df = pd.concat(
            [pd.concat(
                [
                    # direct forwarded match info
                    pd.DataFrame(r.matches),
                    # spectrum info
                    self._replicate_spectrum_info(r),
                    # crosslinker info
                    self._crosslinker_info_to_dataframe(r, xl_names, xl_masses),
                    # peptide info
                    self._peptide_info_to_dataframe(r)
                ], axis=1)
                for r in results],
            ignore_index=True)

        # fix base_sequence for linears
        linear_mask = result_df['p2_index'] == -1
        result_df.loc[linear_mask, 'base_sequence_p2'] = ''

        # change link_pos to 1-based for output
        result_df["link_pos_p1"] = result_df["link_pos_p1"].map(
            lambda x: x + 1 if x != -1 else x
        )
        result_df["link_pos_p2"] = result_df["link_pos_p2"].map(
            lambda x: x + 1 if x != -1 else x
        )

        # write result index
        enum_result_arr = np.arange(len(results))
        result_df['result_idx'] = np.repeat(
            enum_result_arr, [len(r.matches) for r in results]
        )

        # For protein link sites we can simply concatenate all and then turn it into a DataFrame.
        prot_link_sites_df = pd.DataFrame(
            np.concatenate([r.protein_link_sites for r in results])
        )
        prot_link_sites_df["result_idx"] = np.repeat(
            enum_result_arr, [len(r.protein_link_sites) for r in results]
        )

        # create protein_df to fill in protein related info
        protein_df = pd.DataFrame()
        prot_group = prot_link_sites_df.groupby(["result_idx", "alpha_beta_index"])
        # protein accessions
        protein_df[["protein_p1", "protein_p2"]] = prot_group.agg(
            {
                "prot1": lambda x: ";".join(context.proteins[x]["accession"]),
                "prot2": lambda x: ";".join(context.proteins[x[x >= 0]]["accession"]),
            }
        )
        # Fasta header
        protein_df[["fasta_p1", "fasta_p2"]] = prot_group.agg(
            {
                "prot1": lambda x: ";".join(context.proteins[x]["header"]),
                "prot2": lambda x: ";".join(context.proteins[x[x >= 0]]["header"]),
            }
        )
        # start position of the peptide and link sites in the protein
        protein_df[
            ["start_pos_p1", "start_pos_p2", "protein_link_p1", "protein_link_p2"]
        ] = prot_group.agg(
            {
                # aggregate as 1-based, semicolon separated strings ignoring linears (-1)
                "pep_pos1": lambda x: ";".join(x[x >= 0].__add__(1).astype(str)),
                "pep_pos2": lambda x: ";".join(x[x >= 0].__add__(1).astype(str)),
                "link_pos1": lambda x: ";".join(x[x >= 0].__add__(1).astype(str)),
                "link_pos2": lambda x: ";".join(x[x >= 0].__add__(1).astype(str)),
            }
        )
        # protein_count from how many distinct proteins could this peptide come from
        protein_df[["protein_count_p1", "protein_count_p2"]] = prot_group.agg(
            {"prot1": lambda x: x.nunique(), "prot2": lambda x: x[x >= 0].nunique()}
        )
        # position count how often does that peptide occur in the fasta
        protein_df[["position_count_p1", "position_count_p2"]] = prot_group.agg(
            {"prot1": lambda x: x.count(), "prot2": lambda x: x[x >= 0].count()}
        )
        # join protein related info to result df
        result_df = result_df.join(protein_df, on=["result_idx", "alpha_beta_index"])

        # create pep link sites score df
        pep_link_sites_info_df = pd.DataFrame(np.concatenate(
            [r.peptide_link_sites_info[['alpha_beta_index', 'link_p1', 'link_p2', 'score']]
             for r in results])
        )
        pep_link_sites_info_df['result_idx'] = np.repeat(
            enum_result_arr, [len(r.peptide_link_sites_info) for r in results]
        )
        # create pep_site_score_df and aggregate link score site info
        pep_site_score_df = pd.DataFrame()
        pep_link_sites_info_df['score'] = pep_link_sites_info_df['score'].astype(str)
        pep_group = pep_link_sites_info_df.groupby(['result_idx', 'alpha_beta_index'])
        pep_site_score_df[
            ['link_score_site_p1', 'link_score_site_p2', 'link_score']] = pep_group.agg(
            {
                # aggregate as 1-based, semicolon separated strings ignoring linear and non-cov(-1)
                'link_p1': lambda x: ";".join(x[x >= 0].__add__(1).astype(str)),
                'link_p2': lambda x: ";".join(x[x >= 0].__add__(1).astype(str)),
                'score': ';'.join
            }
        )
        # set link score array to empty string for non-crosslink matches
        pep_site_score_df.loc[pep_site_score_df['link_score_site_p1'] == '', 'link_score'] = ''
        # join pep site score related info to result df
        result_df = result_df.join(pep_site_score_df, on=['result_idx', 'alpha_beta_index'])

        # fill in modification information
        result_df["mods_p1"] = create_mod_str(context, result_df["p1_index"])
        result_df["mod_pos_p1"] = create_mod_pos_str(context, result_df["p1_index"])
        result_df["mod_mass_p1"] = create_mod_mass_str(context, result_df["p1_index"])
        cl_mask = result_df["p2_index"] >= 0
        result_df["mods_p2"] = ""
        result_df.loc[cl_mask, "mods_p2"] = create_mod_str(
            context, result_df[cl_mask]["p2_index"]
        )
        result_df["mod_pos_p2"] = ""
        result_df.loc[cl_mask, "mod_pos_p2"] = create_mod_pos_str(
            context, result_df[cl_mask]["p2_index"]
        )
        result_df["mod_mass_p2"] = ""
        result_df.loc[cl_mask, "mod_mass_p2"] = create_mod_mass_str(
            context, result_df[cl_mask]["p2_index"]
        )

        return result_df

    def _replicate_spectrum_info(self, result):
        """
        Return the spectrum info in a DataFrame once per every row in result.matches.

        :param result - (SpectrumResult) result for a single spectrum
        """
        return pd.concat([pd.DataFrame(
            {'scan_index': [result.spectrum.scan_index],
             'scan_number': [result.spectrum.scan_number],
             'retention_time': [result.spectrum.rt],
             'run_name': [result.spectrum.run_name],
             'peaklist_file': [result.spectrum.file_name],
             'source': [result.spectrum.source_path],
             'spectrum_mz': [result.spectrum.precursor_mz],
             'spectrum_charge': [result.spectrum.precursor_charge],
             # numpy and pandas treat missing values differently
             'precursor_intensity': [np.nan
                                     if result.spectrum.precursor_int is None
                                     else result.spectrum.precursor_int]})] * len(
            result.matches), ignore_index=True)

    def _crosslinker_info_to_dataframe(self, result, xl_names, xl_masses):
        """
        Return the crosslinker info in a DataFrame for every row in result.matches.

        :param result - (SpectrumResult) result for a single spectrum
        :param xl_names - (array) names of all crosslinker
        :param xl_masses - (array) masses of all crosslinker
        """
        return pd.DataFrame({
            'crosslinker_name': xl_names[result.matches['crosslinker_index']],
            'crosslinker_mass': xl_masses[result.matches['crosslinker_index']],
        })

    def _peptide_info_to_dataframe(self, result):
        """
        Return the peptide info in a DataFrame for every row in result.matches.

        :param result - (SpectrumResult) result for a single spectrum
        """
        return pd.DataFrame({
            'sequence_p1': np.char.decode(self.context.peptide_db.mod_pep_sequence(
                result.matches['p1_index']), encoding='ascii'),
            'base_sequence_p1': np.char.decode(self.context.peptide_db.unmod_pep_sequence(
                result.matches['p1_index']), encoding='ascii'),
            'sequence_p2': np.char.decode(self.context.peptide_db.mod_pep_sequence(
                result.matches['p2_index']), encoding='ascii'),
            'base_sequence_p2': np.char.decode(self.context.peptide_db.unmod_pep_sequence(
                result.matches['p2_index']), encoding='ascii'),
        })


class TsvResultWriter(ResultWriter):
    """Write results as tab-separated values."""

    def __init__(self, out_path, context, cache_size=50):
        """
        Initialise the tsv result writer.

        :param out_path: (str) where to write the result file.
        :param context: (SearchContext) the context of the search results to write.
        :param cache_size: (int) cache size for batched writing of results to file.
        """
        super().__init__(context)
        self.cache = []
        self.cache_size = cache_size
        self.file = open(out_path, "w")
        self._header_written = False

    def write(self, result):
        """
        Write the results to the TSV file (or to cache).

        Append result to tsv file. Write a header if it's the first result for this file.
        :param result: (tuple) result to write.
            (np.array) spectrum match results.
            (np.array) protein link sites.
        """
        self.cache.append(result)
        if len(self.cache) >= self.cache_size:
            self._write()

    def _write(self):
        """Write the results and clear the cache."""
        result = self._to_dataframe(self.cache)
        if not self._header_written:
            # remove any optional columns that are not present in the result
            self.ordered_output_columns = [x[0] if isinstance(x, list) else x
                                           for x in self.ordered_output_columns
                                           if not isinstance(x, list) or x[0] in result.columns]
            result = result[self.ordered_output_columns]
            result.to_csv(
                self.file,
                header=True,
                sep="\t",
                index=False,
                na_rep="NaN",
            )
        else:
            result = result[self.ordered_output_columns]
            result.to_csv(
                self.file,
                header=False,
                sep="\t",
                index=False,
                na_rep="NaN",
            )
        self._header_written = True
        self.cache = []

    def close(self):
        """Write the remaining cached results and close the file."""
        if len(self.cache) > 0:
            self._write()
        self.file.close()


class ParguetResultWriter(ResultWriter):
    """Write results as tab-separated values."""

    def __init__(self, out_path, context, cache_size=1000, compression='snappy'):
        """
        Initialise the tsv result writer.

        :param out_path: (str) where to write the result file.
        :param context: (SearchContext) the context of the search results to write.
        :param cache_size: (int) cache size for batched writing of results to file.
        """
        super().__init__(context)
        self.cache = []
        self.cache_size = cache_size
        self.out_path = out_path
        self._first_written = False
        self.compression = compression

    def write(self, result):
        """
        Write the results to the TSV file (or to cache).

        Append result to tsv file. Write a header if it's the first result for this file.
        :param result: (tuple) result to write.
            (np.array) spectrum match results.
            (np.array) protein link sites.
        """
        self.cache.append(result)
        if len(self.cache) >= self.cache_size:
            self._write()

    def _write(self):
        """Write the results and clear the cache."""
        result = self._to_dataframe(self.cache)
        if not self._first_written:
            # remove any optional columns that are not present in the result
            self.ordered_output_columns = [x[0] if isinstance(x, list) else x
                                           for x in self.ordered_output_columns
                                           if not isinstance(x, list) or x[0] in result.columns]

        result = result[self.ordered_output_columns]
        fp.write(self.out_path, result, compression=self.compression, append=self._first_written)
        self._first_written = True

        self.cache = []

    def close(self):
        """Write the remaining cached results and close the file."""
        if len(self.cache) > 0:
            self._write()


class MemoryResultWriter(ResultWriter):
    """Write results to a list in memory."""

    def __init__(self, context):
        """
        Initialise the memory result writer.

        :param context: (SearchContext) the context of the search results to write.
        """
        super().__init__(context)
        self._results = []
        self.context = context
        self._header_written = False

    def write(self, result):
        """
        Append result to self._results list.

        :param result: (np.array) result to write.
        """
        result = self._to_dataframe([result])
        if not self._header_written:
            # remove any optional columns that are not present in the result
            self.ordered_output_columns = [x[0] if isinstance(x, list) else x
                                           for x in self.ordered_output_columns
                                           if not isinstance(x, list) or x[0] in result.columns]
            self._header_written = True
        result = result[self.ordered_output_columns]
        self._results.append(result)

    def close(self):
        """Close not needed when writing to memory."""
        pass

    def results(self):
        """Return results."""
        return self._results


class RecaliResultWriter(ResultWriter):
    """Write only results needed for recalibration to a list in memory."""

    def __init__(self, context, recali_output, json_out_path, json_lock_file,
                 config, scan_cache_size=10000, frag_cache_size=100000):
        """
        Initialise the recalibration result writer. Initialises a numpy array as memory cache. When
        the result data exceeds the remaining cache size, the cache is written to a pickle file. A
        cache size of 100000 is approximately 4 MB.

        :param context: (SearchContext) the context of the search results to write.
        :param recali_output: (str) output directory for recalibration results.
        :param json_out_path: (str) output path for config file containing the original config and
            the recalibration results.
        :param json_lock_file: (str) lock file for json_out_path.
        :param config: (Config) original Config object for writing out.
        :param scan_cache_size: (int) size of the scan cache.
        :param frag_cache_size: (int) size of the fragment cache.
        """
        super().__init__(context)

        self.scan_cache_size = scan_cache_size
        self.scan_cache_index = 0
        self.scan_cache = np.empty(scan_cache_size, dtype=[
            ('scan_index', np.int32), ('scan_number', np.int32),
            ('retention_time', np.float32), ('mz', np.float64),
            ('intensity', np.float64), ('error', np.float64),
            ('is_decoy', bool)])

        self.frag_cache_size = frag_cache_size
        self.frag_cache_index = 0
        self.frag_cache = np.empty(frag_cache_size, dtype=[
            ('scan_index', np.int32), ('scan_number', np.int32),
            ('retention_time', np.float32), ('mz', np.float64),
            ('intensity', np.float64), ('error', np.float64),
            ('nlosses', np.uint32), ('is_decoy', bool)])

        self._plot_variables = ['intensity', 'mz', 'retention_time']
        self.source_path = ''
        self.recali_output_dir = recali_output
        self.json_out_path = json_out_path
        self.json_lock_file = json_lock_file
        self.config = config
        self.progress_file = os.path.join(self.recali_output_dir, 'progress.json')
        self.lock_file = os.path.join(self.recali_output_dir, 'progress.json.lock')
        self.cluster_task = self.context.cluster["this_task"]
        self.cluster_all_tasks = self.context.cluster["all_tasks"]
        self.decoy_adj = 1

    def write(self, result):
        """
        Append result to self._results list.

        :param result: (np.array) result to write.
        """
        # (re)set variables for each source path
        if self.source_path != result.spectrum.source_path:
            # write cache to file if not first source path
            if self.source_path != '' and self.scan_cache_index > 0:
                self._write_scan_cache()
                self._write_frag_cache()

            self._set_path_variables(result.spectrum.source_path)

            # update progress file
            self._progress_update(f'Writing recalibration data for {self.identifier}.')

        # consider only one match per spectrum
        psm = result.matches[0]

        # TODO: what if data ist not there? nan?

        if self.scan_cache_index >= self.scan_cache_size:
            self._write_scan_cache()

        self.scan_cache[self.scan_cache_index] = (
            result.spectrum.scan_index, result.spectrum.scan_number,
            result.spectrum.rt, psm['precursor_mz'],
            result.spectrum.precursor_int, psm['precursor_error_ppm'],
            psm['decoy_p1']
        )
        self.scan_cache_index += 1

        n_frags = result.annotations[0].size

        if self.frag_cache_index + n_frags > self.frag_cache_size:
            self._write_frag_cache()

        self.frag_cache[self.frag_cache_index:self.frag_cache_index + n_frags][
            ['scan_index', 'scan_number', 'retention_time']] = [
                (result.spectrum.scan_index, result.spectrum.scan_number, result.spectrum.rt)
        ] * n_frags
        self.frag_cache[self.frag_cache_index:self.frag_cache_index + n_frags][
            ['mz', 'intensity', 'nlosses']] = result.annotations[0][
                ['peak_mz', 'peak_int', 'nlosses']]
        self.frag_cache[self.frag_cache_index:self.frag_cache_index + n_frags][
            'error'] = result.annotations[0]['rel_error'] * 1e6
        self.frag_cache[self.frag_cache_index:self.frag_cache_index + n_frags][
            'is_decoy'] = [psm['decoy_p1']] * n_frags

        self.frag_cache_index += n_frags

    def _write_scan_cache(self):
        """Write the scan cache to file and clear the cache."""
        with open(self.scan_cache_out_path, "ab") as f:
            self.scan_cache[:self.scan_cache_index].dump(f)
        self.scan_cache_index = 0

    def _write_frag_cache(self):
        """Write the fragment cache to file and clear the cache."""
        with open(self.frag_cache_out_path, "ab") as f:
            self.frag_cache[:self.frag_cache_index].dump(f)
        self.frag_cache_index = 0

    def _progress_update(self, msg):
        with DirLock(self.lock_file):
            try:
                with open(self.progress_file, "r") as f:
                    progress = json.load(f)
            except FileNotFoundError:
                progress = {
                    'tasks': {},
                    'files': {}
                }

            progress['tasks'][str(self.cluster_task)] = msg

            if self.identifier not in progress['files']:
                progress['files'][self.identifier] = self.source_path

            with open(self.progress_file, "w") as f:
                json.dump(progress, f, indent=2)

        return len(progress['tasks']) == self.cluster_all_tasks and \
            all(status == 'done.' for status in progress['tasks'].values())

    def _set_path_variables(self, source_path):
        """Set path variables for the source path."""

        # (re)set source path-based variables
        self.source_path = source_path
        self.identifier = (f'{os.path.basename(self.source_path)}_'
                           f'{hashlib.md5(self.source_path.encode()).hexdigest()}')
        self.scan_cache_out_path = os.path.join(self.recali_output_dir,
                                                f'{self.identifier}_{self.cluster_task}_scan.pkl')
        self.frag_cache_out_path = os.path.join(self.recali_output_dir,
                                                f'{self.identifier}_{self.cluster_task}_frag.pkl')

        # reset plot variables (are extended if retention_time is not present)
        self._plot_variables = ['intensity', 'mz', 'retention_time']

    def _read_scan_cache(self):
        """
        Read scan cache from file.

        :return: (generator) scan cache data.
        """
        for cache_path in glob.glob(
                os.path.join(self.recali_output_dir, f'{self.identifier}_*_scan.pkl')):
            with open(cache_path, "rb") as f:
                while 1:
                    try:
                        yield pickle.load(f)
                    except EOFError:
                        break

    def _read_frag_cache(self):
        """
        Read frag cache from file.

        :return: (generator) frag cache data.
        """
        for cache_path in glob.glob(
                os.path.join(self.recali_output_dir, f'{self.identifier}_*frag.pkl')):
            with open(cache_path, "rb") as f:
                while 1:
                    try:
                        yield pickle.load(f)
                    except EOFError:
                        break

    def close(self):
        """
        Write out remaining cache. Recalibrate and write out config if all tasks are done.

        """
        if self.scan_cache_index > 0:
            self._write_scan_cache()
        if self.frag_cache_index > 0:
            self._write_frag_cache()

        # all tasks are done, calculate recalibrations
        if self._progress_update('done.'):
            log(f'Calculating errors and writing to {self.json_out_path}.')
            with DirLock(self.lock_file):
                with open(self.progress_file, "r") as f:
                    progress = json.load(f)

            for source_path in progress['files'].values():
                self._set_path_variables(source_path)

                log(f'Calculate MS1 recalibration for {self.source_path}.')
                self.scan_cache = np.concatenate(
                    [c for c in self._read_scan_cache()]
                )

                ms1_error, ms1_tol = self.ms1_error()
                self.scan_cache = None

                log(f'Calculate MS2 recalibration for {self.source_path}.')
                self.frag_cache = np.concatenate(
                    [c for c in self._read_frag_cache()]
                )

                # adjust the peak hit chance for decoy hits
                self.approx_match_hit_chance()

                ms2_error, ms2_tol = self.ms2_error()
                self.frag_cache = None

                log(f'Recommended errors for {self.source_path}. '
                    f'MS1: {round(ms1_error, 3)} ppm, '
                    f'MS2: {round(ms2_error, 3)} ppm.')
                log(f'Recommended tolerances for {self.source_path}. '
                    f'MS1: {round(ms1_tol, 3)} ppm, '
                    f'MS2: {round(ms2_tol, 3)} ppm.')
                self.config.recalibration.append(
                    RecalibrationConfig(
                        file=self.source_path,
                        ms1_error=f'{ms1_error} ppm',
                        ms2_error=f'{ms2_error} ppm',
                        ms1_tol=f'{ms1_tol} ppm',
                        ms2_tol=f'{ms2_tol} ppm'
                    )
                )

            # write new config to file
            with DirLock(self.json_lock_file):
                self.config.write(self.json_out_path)

        # reset source path
        self.source_path = ''

    def approx_match_hit_chance(self, bin_width=0.25):
        '''
        Approximates the target/decoy ratio of the peak matches for false
        positive peak matches and set it as self.decoy_adj.
        Decoy peak matches represent only the peak matches of false positive
        target peptide matches. However also true positive target matches will
        have some false positive peak matches. This function calculates the
        target/decoy ratio of the peak matches and uses the 0.25 quantile
        of the sorted target/decoy ratio to adjust the peak match chance for
        decoy matches. The 0.25 quantile is used as a estimate of the
        target/decoy ratio of pure random peak matches.

        :param bin_width: (float) width of the histogram bins.
        '''
        # filter out fragments with losses
        self.frag_cache = self.frag_cache[np.where(self.frag_cache['nlosses'] == 0)]
        arr_errors = self.frag_cache

        # Create views of target and decoy data
        arr_target = arr_errors[~arr_errors['is_decoy']]['error']
        arr_decoy = arr_errors[arr_errors['is_decoy']]['error']
        arr_all = arr_errors['error']

        # if all values are the same, recalibration is not useful/possible
        if (arr_all.max() - arr_all.min()) == 0:
            return

        # Determine number of bins
        num_bins = math.ceil((arr_all.max() - arr_all.min()) / bin_width)

        # Create histogram bins
        bin_edges = np.linspace(arr_all.min(), arr_all.max(), num_bins + 1)

        # Histogram counts for targets and decoys
        hist_target, _ = np.histogram(arr_target, bins=bin_edges)
        hist_decoy, _ = np.histogram(arr_decoy, bins=bin_edges)
        # devide target by decoy and fill non finite values with nan
        hist_td_ratio = np.divide(hist_target, hist_decoy,
                                  out=np.full(hist_target.shape, np.nan, dtype=np.float64),
                                  where=hist_decoy != 0, dtype=np.float64)

        # Forward fill NaNs
        mask = np.isnan(hist_td_ratio)
        # Create an index array where non-NaN values are replaced with their index
        idx = np.where(~mask, np.arange(len(hist_td_ratio)), 0)
        # Use np.maximum.accumulate to fill NaN values with the last non-NaN value
        # This is done by taking the maximum of the current index and the last non-NaN index
        np.maximum.accumulate(idx, out=idx)

        hist_td_ratio[mask] = hist_td_ratio[idx][mask]

        # If first element is still NaN (all were NaN at start), set to 1
        if not np.isfinite(hist_td_ratio[0]):
            hist_td_ratio[0] = 1

        # Sort by T/D ratio
        sorted_indices = np.argsort(hist_td_ratio)
        sorted_hist_td_ratio = hist_td_ratio[sorted_indices]

        quantile_0_25 = sorted_hist_td_ratio[len(sorted_hist_td_ratio) // 4]

        df_cumsum_truepos = pd.DataFrame({
            'index': np.linspace(0, len(sorted_hist_td_ratio), len(sorted_hist_td_ratio)),
            'td_ratio': sorted_hist_td_ratio})
        df_quantile_0_25 = pd.DataFrame({
            'l': [round(quantile_0_25, 2)],
            'x': [sorted_hist_td_ratio.argmax()],
            'y': [quantile_0_25],
            'value': ['T/D at 0.25 quantile']
        })
        plot = (
            p9.ggplot(df_cumsum_truepos, p9.aes(x='index', y='td_ratio'))
            + p9.geom_point()
            + p9.geom_text(p9.aes(label='l', x='x', y='y'), size=7, data=df_quantile_0_25,
                           inherit_aes=False)
            + p9.geom_hline(p9.aes(yintercept='y', linetype='value'), data=df_quantile_0_25,
                            inherit_aes=False)
            + p9.scale_linetype_manual(values=['solid', 'dotted', 'dashed'])
            + p9.ggtitle('MS2 target/decoy ratio')
            + p9.xlab('Index')
            + p9.ylab('Sorted target/decoy ratio')
        )
        plot.save(os.path.join(self.recali_output_dir, f'{self.identifier}_ms2_td_ratio.svg'),
                  verbose=False)

        if quantile_0_25 <= 0 or not np.isfinite(quantile_0_25):
            log(f'MS2 target/decoy ratio is {quantile_0_25}. '
                f'MS2 decoy match chance not adjusted for {self.source_path}.')
            quantile_0_25 = 1
        self.decoy_adj = quantile_0_25

    def ms1_error(self):
        """
        Wrapper method for calculating MS1 error and tolerance. Crossvalidates the error and plots
        the error distribution and the window counts.
        """
        # error plots
        self._plot(self.scan_cache, plot_label='ms1')

        # calculate before the crossvalidation to be able to output the data anyway
        median, tolerance = self.median_in_mode_interval(
            self.scan_cache,
            plot=True,
            plot_output_dir=self.recali_output_dir,
            prefix=self.identifier,
            plot_label='ms1'
        )

        if self._kfoldcrossvalidation(self.scan_cache)[0]:
            return (median, tolerance)
        else:
            log(f'Crossvalidation suggests that accurate recalibration of MS1 data is not '
                f'possible for {self.source_path}.')
            return (0, tolerance)

    def ms2_error(self):
        """
        Wrapper method for calculating MS2 error and tolerance. Only considers fragments without
        losses. Crossvalidates the error and plots the error distribution and the window counts.
        """
        # filter out fragments with losses
        self.frag_cache = self.frag_cache[np.where(self.frag_cache['nlosses'] == 0)]

        # error plots
        self._plot(self.frag_cache, plot_label='ms2', decoy_adj=self.decoy_adj)

        # calculate before the crossvaildation to be able to output the data anyway
        median, tolerance = self.median_in_mode_interval(
            self.frag_cache,
            plot=True,
            plot_output_dir=self.recali_output_dir,
            prefix=self.identifier,
            plot_label='ms2',
            decoy_adj=self.decoy_adj
        )

        if self._kfoldcrossvalidation(self.frag_cache)[0]:
            return (median, tolerance)
        else:
            log(f'Crossvalidation suggests that accurate recalibration of MS2 data is not '
                f'possible for {self.source_path}.')
            return (0, tolerance)

    @staticmethod
    def median_in_mode_interval(
        arr_errors,
        bin_width=0.01,
        window_size_init=100,
        plot=False,
        plot_output_dir=None,
        prefix='',
        plot_label=None,
        decoy_adj=1
    ):
        '''
        Aproximate the mod of a histogram by using a rolling window of binned error values.
        The error values get binned and a rolling window is applied to the histogram.
        The window with the highest number of entries is selected and the bin containing the median
        is determined. The median is calculated as the interpolation of the bin edges.
        '''
        # Create views of target and decoy data
        arr_target = arr_errors[~arr_errors['is_decoy']]['error']
        arr_decoy = arr_errors[arr_errors['is_decoy']]['error']
        arr_all = arr_errors['error']

        # if all values are the same, recalibration is not useful/possible
        if (arr_all.max() - arr_all.min()) == 0:
            return arr_all.max(), 0

        # Determine number of bins
        num_bins = math.ceil((arr_all.max() - arr_all.min()) / bin_width)

        # Create histogram bins
        bin_edges = np.linspace(arr_all.min(), arr_all.max(), num_bins + 1)

        # the following loop will make sure that there is a unique mode window (window with the
        # highest number of true positive targets) but will most likely be executed once only. if
        # there are two mode windows, the window size will be increased by window_size_step until
        # there is only one mode window.
        # this allow different window sizes during the cross validation, which is suboptimal, but
        # as we do not expect big differences in windows sizes, we do not expect an impact on the
        # final result
        window_size_step = 10
        window_size = window_size_init
        window_sums = np.array([])

        while window_size == window_size_init or \
                len(np.where(window_sums == window_sums.max())[0]) > 1:
            # if window_size is bigger than the number of bins, set it to the number of bins
            # ser_all_intervals is one longer because it contains the interval boundaries
            if num_bins < window_size:
                window_size = num_bins

            # Histogram counts for targets and decoys
            hist_target, _ = np.histogram(arr_target, bins=bin_edges)
            hist_decoy, _ = np.histogram(arr_decoy, bins=bin_edges)
            hist_truepos = hist_target - hist_decoy * decoy_adj

            # Compute rolling sums
            window_sums = np.convolve(hist_truepos, np.ones(window_size, dtype=int), 'same')

            window_size += window_size_step

            # negative counts might appear due to sparseness of the target data, but the
            # negative counts should be taken into account. with a small chance and a sparse target
            # data set, there are more than one mode windows.
            # TODO the whole point was not to have an exception for sparse data. if there are
            # multiple mode windows the idxmax below with pick the leftmost one, which is not
            # optimal.
            # Fix: Rolling above was run with min_periods=1, which allowed more than one final max
            # value. With min_periods=window_size (default), the rolling sum will be NaN if there
            # are not enough values in the window. This should prevent running into the following
            # condition.
            if num_bins == window_size - window_size_step and \
                    len(np.where(window_sums == window_sums.max())[0]) > 1:
                break

        # Adjust window size because of loop
        window_size -= window_size_step

        # Find mode window
        mode_window_idx = np.argmax(window_sums)
        left_window_idx = mode_window_idx - window_size // 2
        right_window_idx = mode_window_idx + window_size // 2

        # if window size is uneven, the right boundary index has to be increased by one
        if window_size % 2 == 1:
            right_window_idx += 1

        # Ensure indices are within bounds
        left_window_idx = max(left_window_idx, 0)
        right_window_idx = min(right_window_idx, num_bins)

        # Get histogram values within the mode window
        mode_window_hist = hist_truepos[left_window_idx:right_window_idx]

        # Calculate cumulative sum to find the median-containing bin
        cumsum = np.cumsum(mode_window_hist)
        median_bin_idx = np.where(cumsum >= cumsum[-1] / 2)[0][0]

        # Compute the median as the interpolation of the bin edges
        median_bin_left = bin_edges[left_window_idx + median_bin_idx]
        median_bin_right = bin_edges[left_window_idx + median_bin_idx + 1]
        left_cumsum = cumsum[median_bin_idx - 1] if median_bin_idx > 0 else 0
        right_cumsum = cumsum[median_bin_idx]
        fraction = (cumsum[-1] / 2 - left_cumsum) / (right_cumsum - left_cumsum)
        median = bin_edges[left_window_idx + median_bin_idx] + \
            fraction * (median_bin_right - median_bin_left)

        # Calculate tolerance
        # the percentile can decrease somtimes again, because the bins might contain negative
        # counts. the negative counts appear due to sparseness of the target data, and should be
        # taken into account
        midpoints = (bin_edges[:-1] + bin_edges[1:]) / 2
        recalibrated_errors = np.abs(midpoints - median)

        # Percentiles and Euclidean distance to (0, 1)
        # the percentile of the true positive identifications (cumulative sum divided by
        # the total number of identifications) can be above one because of negative counts
        sorted_indices = np.argsort(recalibrated_errors)
        sorted_hist_truepos = hist_truepos[sorted_indices]
        sorted_recalibrated_errors = recalibrated_errors[sorted_indices]

        # TODO mask out negative counts or not?
        # mask out bins with negative counts
        # negative counts could lead to wrong percentiles. nevertheless, we should take them into
        # account, because in real data they reduce the number of true positive identifications.
        # positive_mask = sorted_hist_truepos > 0
        # sorted_hist_truepos_cumsum = np.cumsum(sorted_hist_truepos * positive_mask)

        # the correct implementation of the percentile calculation is to divide by the total sum
        # (np.sum(sorted_hist_truepos)). however, negative counts can lead a percentile calculation
        # that is not valid
        # TODO is this valid?
        sorted_hist_truepos_cumsum = np.cumsum(sorted_hist_truepos)
        percentiles = sorted_hist_truepos_cumsum / sorted_hist_truepos_cumsum[-1]
        # distances to (0,1) in roc-curve
        distances = np.sqrt((sorted_recalibrated_errors / sorted_recalibrated_errors.max())**2
                            + (1 - percentiles)**2)

        # Find the index of the first point where the cumulative sum is greater than 0.95
        # and take that as the search tolerance
        tol_idx = np.where(
            sorted_hist_truepos_cumsum >= sorted_hist_truepos_cumsum[-1] * 0.95)[0][0]
        tolerance = sorted_recalibrated_errors[tol_idx]

        # plotting
        if plot and plot_output_dir:
            df_all = pd.DataFrame(arr_errors)

            plot = (
                p9.ggplot(df_all, p9.aes(x='error', fill='is_decoy'))
                + p9.geom_histogram(
                    stat=p9.stat_bin(bins=50),
                    position='dodge'
                )
                + p9.scale_fill_manual(values={True: '#db5f57', False: '#57d3db'})
                + p9.ggtitle(f'{plot_label} error distribution')
                + p9.xlab(f'{plot_label} error [ppm]')
                + p9.ylab('# of identifications')
            )
            fig = plot.draw()
            ymax = fig.axes[0].get_ylim()[1]
            mode_win_left = bin_edges[left_window_idx]
            mode_win_right = bin_edges[right_window_idx]
            df_medtol = pd.DataFrame({
                'l': [round(median, 2), f'-{round(tolerance, 2)}', f'+{round(tolerance, 2)}',
                      f'[{round(mode_win_left, 2)}', f'{round(mode_win_right, 2)}]'],
                'x': [median, median-tolerance, median+tolerance, mode_win_left, mode_win_right],
                'y': [ymax] * 5,
                'value': ['error', 'tol', 'tol', 'mode win', 'mode win']
            })
            plot += p9.geom_text(p9.aes(label='l', x='x', y='y'), size=7, data=df_medtol,
                                 inherit_aes=False)
            plot += p9.geom_vline(p9.aes(xintercept='x', linetype='value'), data=df_medtol,
                                  inherit_aes=False)
            plot += p9.scale_linetype_manual(
                # error, mode win, tol
                values=['solid', 'dotted', 'dashed'])
            plot.save(os.path.join(plot_output_dir, f'{prefix}_{plot_label}_hist.svg'),
                      verbose=False)

            df_window_sums = pd.DataFrame(
                {'count': window_sums,
                 'error': midpoints})
            plot = (
                p9.ggplot(df_window_sums, p9.aes(x='error', y='count'))
                + p9.geom_col(
                    fill='#1f77b4',
                    stat='identity',
                    position='dodge',
                    na_rm=True
                )
                + p9.geom_vline(xintercept=median, data=pd.DataFrame(), inherit_aes=False)
                + p9.ggtitle(f'{plot_label} error distribution')
                + p9.xlab(f'{plot_label} error [ppm]')
                + p9.ylab('# true positive identifications in window of '
                          f'{window_size*bin_width} ppm')
            )
            fig = plot.draw()
            ymax = fig.axes[0].get_ylim()[1]
            plot += p9.geom_text(p9.aes(label=round(median, 2), x=median, y=ymax),
                                 data=pd.DataFrame(), inherit_aes=False)
            plot.save(os.path.join(plot_output_dir, f'{prefix}_{plot_label}_wind.svg'),
                      verbose=False)

            df_hist_truepos = pd.DataFrame(
                {'abs_mid_recalibrated': sorted_recalibrated_errors,
                 'percentile': percentiles,
                 'dist_to_01': distances})

            plot = (
                p9.ggplot(df_hist_truepos, p9.aes(x='abs_mid_recalibrated', y='percentile',
                          color='dist_to_01'))
                + p9.geom_point()
                + p9.geom_vline(xintercept=tolerance, linetype='dashed', data=pd.DataFrame(),
                                inherit_aes=False)
                + p9.geom_text(p9.aes(label=round(tolerance, 2), x=tolerance, y=1),
                               data=pd.DataFrame(), inherit_aes=False)
                + p9.ggtitle(f'{plot_label} tolerance optimisation curve')
                + p9.xlab(f'Absolute {plot_label} error [ppm] shifted by {-round(median, 2)}')
                + p9.ylab('Percentile of true positive identifications')
            )
            plot.save(os.path.join(plot_output_dir, f'{prefix}_{plot_label}_tol.svg'),
                      verbose=False)

            cumsum_truepos = np.cumsum(hist_truepos)
            df_cumsum_truepos = pd.DataFrame(
                {'error': bin_edges[:-1],
                 'cumsum': cumsum_truepos})
            df_medtol = pd.DataFrame({
                'l': [round(median, 2), f'-{round(tolerance, 2)}', f'+{round(tolerance, 2)}',
                      f'[{round(mode_win_left, 2)}', f'{round(mode_win_right, 2)}]'],
                'x': [median, median-tolerance, median+tolerance, mode_win_left, mode_win_right],
                'y': [cumsum_truepos.max()] * 5,
                'value': ['error', 'tol', 'tol', 'mode win', 'mode win']
            })
            plot = (
                p9.ggplot(df_cumsum_truepos, p9.aes(x='error', y='cumsum'))
                + p9.geom_point()
                + p9.geom_text(p9.aes(label='l', x='x', y='y'), size=7, data=df_medtol,
                               inherit_aes=False)
                + p9.geom_vline(p9.aes(xintercept='x', linetype='value'), data=df_medtol,
                                inherit_aes=False)
                + p9.scale_linetype_manual(values=['solid', 'dotted', 'dashed'])
                + p9.ggtitle(f'{plot_label} tolerance optimisation curve')
                + p9.xlab(f'{plot_label} error [ppm]')
                + p9.ylab('Cum. sum of true positive identifications')
            )
            plot.save(os.path.join(plot_output_dir, f'{prefix}_{plot_label}_cumsum.svg'),
                      verbose=False)

        return (median, tolerance)

    @staticmethod
    def _kfoldcrossvalidation_worker(arr_errors, args):
        """Worker function for multiprocessing."""
        # default values
        kwargs = {
            'bin_width': 0.01,
            'window_size_init': 100,
            'plot': False,
            'plot_output_dir': None,
            'prefix': '',
            'plot_label': None
        }
        # parse args
        for i in range(len(args)):
            if args[i] is not None:
                kwargs[list(kwargs)[i]] = args[i]
            if i == 5:
                kwargs['plot_label'] = f'{kwargs["plot_label"]}{time.time()}'

        # concatenate the subset arrays
        kwargs['arr_errors'] = np.concatenate(arr_errors)

        return RecaliResultWriter.median_in_mode_interval(**kwargs)[0]

    def _kfoldcrossvalidation(self, arr_errors, k_splits=10, *args):
        """k-fold crossvalidation of error recalibration"""
        # create views of target and decoy data
        arr_target = arr_errors[~arr_errors['is_decoy']]
        arr_decoy = arr_errors[arr_errors['is_decoy']]

        # shuffle views, seed is set to 0 to ensure reproducibility
        rng = np.random.default_rng(0)
        rng.shuffle(arr_target)
        rng.shuffle(arr_decoy)

        # create splits (also views) containing 1/k_splits of the data
        target_splits = np.array_split(arr_target, k_splits)
        decoy_splits = np.array_split(arr_decoy, k_splits)

        # create subsets of 1-(1/k_splits) of the data, the subset is a list of views. when
        # concatenating the views, the data contains all but the k-th split. the concatenating
        # is done by the worker to reduce the time of high memory usage.
        list_subsets = []
        for k in range(k_splits):
            list_subsets.append(
                [target_splits[i] for i in range(k_splits) if i != k]
                + [decoy_splits[i] for i in range(k_splits) if i != k]
            )

        # use multiprocessing to process subsets
        process_count = self.context.config.threads
        if process_count <= 0:
            process_count += mp.cpu_count()

        # number of processes are adjusted to data length but max k_splits / max user input and
        # at least 1. 1000000 is arbitrary, but seemed to work well in testing
        # TODO: not sure if we should do multiprocessing at all because memory usage
        process_count = min(
            max(
                int(len(arr_target) / 1000000),
                1),
            process_count)

        if process_count == 1:
            list_subset_medians = []
            for subset in list_subsets:
                list_subset_medians.append(
                    self._kfoldcrossvalidation_worker(subset, args))
        else:
            with mp.Pool(min(k_splits, process_count)) as pool:
                list_subset_medians = pool.starmap(
                    self._kfoldcrossvalidation_worker, zip(list_subsets, repeat(args)))

        # TODO: is this a good condition?
        return max(list_subset_medians) * min(list_subset_medians) > 0, list_subset_medians

    def _plot(self, data, plot_label='', decoy_adj=1):
        """
        Plot the error distribution (KDE) for the given data.
        """
        data_target = data[~data['is_decoy']]
        data_decoy = data[data['is_decoy']]

        # skip if not enough values for KDE
        if len(data_target) < 3:
            log('Not enough data for KDE plot.')
            return

        for variable in self._plot_variables:
            # extract error values
            target_err_values = data_target['error']
            decoy_err_values = data_decoy['error']

            # Skip if variable is not having meaningfull values in data
            if data[variable].max() - data[variable].min() == 0 or \
                    np.all(np.isnan(data[variable])):
                # for missing retention time try to plot scan_number or scan_index instead
                if variable == 'retention_time':
                    self._plot_variables.append('scan_number')
                elif variable == 'scan_number':
                    self._plot_variables.append('scan_index')
                continue

            # extract variable values
            if variable == 'intensity':
                variable = f'log2({variable})'
                non_zero_values_target = data_target['intensity'] > 0
                non_zero_values_decoy = data_decoy['intensity'] > 0
                target_var_values = np.emath.logn(2,
                                                  data_target['intensity'][non_zero_values_target])
                decoy_var_values = np.emath.logn(2,
                                                 data_decoy['intensity'][non_zero_values_decoy])

                # filter out infinite values
                target_err_values = target_err_values[non_zero_values_target]
                decoy_err_values = decoy_err_values[non_zero_values_decoy]

                # set min and max values for the grid
                if len(decoy_var_values) > 0:
                    min_var_value = min(target_var_values.min(), decoy_var_values.min())
                    max_var_value = max(target_var_values.max(), decoy_var_values.max())
                else:
                    min_var_value = target_var_values.min()
                    max_var_value = target_var_values.max()
            else:
                target_var_values = data_target[variable]
                decoy_var_values = data_decoy[variable]

                min_var_value = data[variable].min()
                max_var_value = data[variable].max()

            # ### plotting 2D KDE
            # Create a grid for the density estimation
            x_grid = np.linspace(min_var_value, max_var_value, 100)
            y_grid = np.linspace(data['error'].min(), data['error'].max(), 100)
            X, Y = np.meshgrid(x_grid, y_grid)
            positions = np.vstack([X.ravel(), Y.ravel()])

            # Compute KDE for targets
            try:
                kde_target = gaussian_kde(np.vstack([target_var_values, target_err_values]))
            except LinAlgError:
                # coould be to little data or to little variance in the data
                log('Not enough data for target KDE plot.')
                continue
            except ValueError:
                log("somthing odd here")
                raise
            Z_target = np.reshape(kde_target(positions), X.shape) * len(data_target)

            # Compute KDE for decoys
            try:
                kde_decoy = gaussian_kde(np.vstack([decoy_var_values, decoy_err_values]))
                Z_decoy = np.reshape(kde_decoy(positions), X.shape) * len(data_decoy)
            except (LinAlgError, ValueError):
                if (len(data_decoy) < len(data_target) / 100):
                    # probably not enough decoys for KDE but decoys are anyway less then
                    # 1% of targets, so just assume zero
                    log('Not enough data for decoy KDE calculation. assume zero')
                    Z_decoy = np.zeros_like(Z_target)
                else:
                    # we should have enough data but kde calculation failed
                    # so just skip the plot
                    log(f'gaussian_kde for decoys failed will skip plot for {variable}')
                    continue

            # Subtract the KDEs (to get "true positives")
            Z_difference = Z_target - Z_decoy * decoy_adj

            Z_diff_norm = np.apply_along_axis(lambda x: x / (x.max() - x.min()), 0, Z_difference)

            norm = CenteredNorm(vcenter=0)

            fig, axes = plt.subplots(
                2, 2, figsize=(12, 8),
                gridspec_kw={'height_ratios': [1, 4], 'width_ratios': [1, 6]},
                sharex='col', sharey='row', layout='constrained')

            # Top Left Plot: Empty
            ax0 = axes[0, 0]
            ax0.axis('off')

            # Top Right Plot: 1D-KDE
            ax1 = axes[0, 1]
            ax1.plot(x_grid, Z_target.sum(axis=0), label='Targets', color='#1f77b4')
            # ax1.set_xlabel('')
            ax1.set_ylabel('KDE True Positives')
            ax1.tick_params(axis='x', which='both', bottom=True, labelbottom=False)
            ax1.tick_params(axis='y', which='both', left=True, labelleft=True)
            ax1.spines[['right', 'top']].set_visible(False)

            # Bottom Right Plot: KDE Plot True Positive Counts
            ax2 = axes[1, 1]
            cs = ax2.contourf(X, Y, Z_diff_norm, cmap='PRGn', levels=100, norm=norm)
            fig.colorbar(cs, ax=ax2,
                         label=f'KDE True Positives norm. by range in {variable} bin')
            ax2.set_xlabel(variable)
            ax2.tick_params(axis='y', which='both', left=True, labelleft=False)
            ax2.spines[['right', 'top']].set_visible(False)

            # Bottom Left Plot: 1D-KDE
            ax3 = axes[1, 0]
            ax3.plot(Z_target.sum(axis=1), y_grid, label='Targets', color='#1f77b4')
            ax3.set_xlabel('KDE True Positives')
            ax3.set_ylabel('Error')
            ax3.invert_xaxis()
            ax3.spines[['right', 'top']].set_visible(False)

            plt.savefig(
                os.path.join(self.recali_output_dir, f'{self.identifier}_{plot_label}_kde_'
                                                     f'{variable}_relerror.svg'))
            plt.close()


class DummyResultWriter(ResultWriter):
    """Take results and do nothing."""

    def __init__(self, context):
        """Initialise the dummy writer."""
        super().__init__(context)

    def write(self, result):
        """Do nothing."""
        pass

    def close(self):
        """Do nothing."""
        pass


def convert_to_xispec(in_df, config):
    """
    Convert a result dataframe to xiSPEC csv format.

    :param in_df: (DataFrame) search result dataframe
    :param config: (Config) Search config (for ms2 tolerance and fragment ion types)
    :return: (DataFrame) results in xiSPEC csv format
    """
    col_mapping = {
        "sequence_p1": "PepSeq1",
        "sequence_p2": "PepSeq2",
        "link_pos_p1": "LinkPos1",
        "link_pos_p2": "LinkPos2",
        "protein_p1": "Protein1",
        "protein_p2": "Protein2",
        "decoy_p1": "Decoy1",
        "decoy_p2": "Decoy2",
        "match_score": "Score",
        "precursor_charge": "Charge",
        "crosslinker_mass": "CrossLinkerModMass",
        "precursor_mz": "ExpMz",
        "calc_mz": "CalcMz",
        "scan_index": "ScanId",
        "peaklist_file": "PeakListFileName",
    }
    # top ranking only
    out_df = in_df[in_df["top_ranking"]]
    # subset to necessary columns and rename
    out_df = out_df[col_mapping.keys()].rename(columns=col_mapping)

    # Decoy columns expect True/False
    out_df["Decoy1"] = out_df["Decoy1"].astype(bool)
    out_df["Decoy2"] = out_df["Decoy2"].astype(bool)

    # add fragment tolerance and ion types columns from config
    frag_tol = re.search(r"^([0-9.]+)\s?(ppm|Da)$", config.ms2_tol).groups()
    out_df["FragmentTolerance"] = f"{frag_tol[0]} {frag_tol[1]}"

    ion_types = ";".join(
        config.fragmentation.nterm_ions + config.fragmentation.cterm_ions
    )
    if config.fragmentation.add_precursor:
        ion_types += ";peptide"
    out_df["IonTypes"] = ion_types

    return out_df
