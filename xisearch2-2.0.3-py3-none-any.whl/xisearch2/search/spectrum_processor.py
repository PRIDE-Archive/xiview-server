"""The actual processor of the spectra, with a given SearchContext."""
import numpy as np
from xisearch2 import spectra_reader, candidates, crosslink, const
from xisearch2.cython import isin_set_long
from xisearch2.search.spectrum_result import SpectrumResult
import xisearch2.dtypes as dtypes


class SpectrumProcessor:
    """Class for processing and searching of mass spectra."""

    def __init__(self, context):
        """
        Initialise the SpectrumProcessor class.

        :param context: (SearchContext) search context
        """
        self.context = context

    def process_spectrum(self, spectrum, result_queue):
        """
        Process a single spectrum during a xiSEARCH and push the results to the result queue.

        :param spectrum: (Spectrum) a MS2 spectrum object
        :param result_queue: (Queue) queue to which the results can be pushed
        """
        context = self.context
        ximpa_prec_masses = spectrum.precursor_mass - \
            np.arange(0, context.config.isotope_error_ximpa + 1) * const.C12C13_MASS_DIFF

        # Generate spectra for scoring:
        # 1. full match spectrum (used for link site detection incl. full annotation)
        # detect isotope clusters
        full_match_spectrum = context.detector.process(spectrum)

        # prepare candidate scoring spectra by removing loss clusters from the full_match_spectrum
        base_candidate_spectrum = context.loss_cluster_filter.process(full_match_spectrum)

        # 2. alpha candidate spectrum (charge reduced, linearised, de-noised)
        alpha_spectrum = candidates.get_alpha_spectrum(base_candidate_spectrum, context)

        # 3. alpha-beta candidate spectrum
        # Charge reduce to singly charged peaks and denoise the base_candidate_spectrum
        charge_reduced = context.charge_filter.process(base_candidate_spectrum)
        alpha_beta_spectrum = context.alpha_beta_denoise_filter.process(charge_reduced)

        # get all alpha candidates (unsorted)
        all_alphas = candidates.get_alpha_candidates(alpha_spectrum, context)

        # get all peptides that match as linear peptide
        mass_match_linear = context.peptide_db.lookup(
            ximpa_prec_masses,
            relative_tolerance=context.get_ms1_rtol(spectrum.source_path),
            absolute_tolerance=context.get_ms1_atol(spectrum.source_path)
        )

        # filter alpha candidates to hard cap of max_alpha_candidates
        hard_capped_alphas = candidates.hard_cap_candidates(
            all_alphas, 'peptide_score', context.config.max_alpha_candidates)
        # re-score the alpha candidate scores based on their aa base sequence
        # Note: These base scores are only used for ranking and don't overwrite the alpha scores
        #   This means a match can have alpha rank 1 and also a negative alpha_delta_score!
        alpha_base_scores = candidates.base_sequence_rescore_alphas(hard_capped_alphas, context)

        # filter to top_n alphas (top_n unique scores)
        top_alpha_indices, top_alpha_ranks = candidates.top_n_unique_scores(
            alpha_base_scores, top_n=context.config.top_n_alpha_scores)
        top_alphas = hard_capped_alphas[top_alpha_indices]

        # everything that comes through among the top_alphas we don't need by mass alone as linear
        if mass_match_linear.size > 0:
            # remove all peptides found via peaks
            mass_match_linear = mass_match_linear["id"][~isin_set_long(mass_match_linear["id"],
                                                        top_alphas["peptide_index"])]

            if mass_match_linear.size > 0:
                next_rank = top_alpha_ranks[-1] + 1 if top_alpha_ranks.size > 0 else 1
                # create the ranks as highest plus 1
                linear_alphas_rank = np.full(mass_match_linear.size, next_rank,
                                             dtype=top_alpha_ranks.dtype)

                # and the index score array
                linear_alphas = np.zeros(mass_match_linear.size, dtype=top_alphas.dtype)
                # fill up the indices
                linear_alphas['peptide_index'] = mass_match_linear

                top_alphas = np.concatenate([top_alphas, linear_alphas])
                top_alpha_ranks = np.concatenate([top_alpha_ranks, linear_alphas_rank])

        # abort if no alpha candidates were found
        if top_alphas.size == 0:
            return

        # basic dtype of the result table
        # fixed dtypes come from dtypes.scores_table_dtype but some can only be defined at runtime
        scores_table_dtype = dtypes.scores_table_dtype + [
            ('aa_len_p1', context.modified_peptides_aa_lengths.dtype),  # number of amino acids p1
            ('aa_len_p2', context.modified_peptides_aa_lengths.dtype),  # number of amino acids p2
        ]

        all_ab_candidates = []
        subtables = []
        previous_alphas = set()
        for alpha_i, (alpha_pep_index, alpha_score) in enumerate(top_alphas):

            ab_candidates = candidates.get_ab_candidates(ximpa_prec_masses,
                                                         alpha_pep_index,
                                                         context=context,
                                                         source_path=spectrum.source_path)

            # filter out alpha-beta combinations that were already scored
            beta_filter_mask = ~np.array([p in previous_alphas
                                          for p in ab_candidates["beta_pep_index"]],
                                         dtype=bool)
            ab_candidates = ab_candidates[beta_filter_mask]
            previous_alphas.add(alpha_pep_index)

            # if there are no beta sequences matched continue to the next alpha
            if len(ab_candidates) == 0:
                continue

            ln_mask = (ab_candidates['beta_pep_index'] == -1)

            subtable = np.empty(ab_candidates.size, dtype=scores_table_dtype)

            _, count_index, beta_counts = np.unique(
                ab_candidates["isotope_index"], return_counts=True, return_inverse=True)

            subtable['beta_count'][ln_mask] = 0
            subtable['beta_count_inverse'][ln_mask] = np.nan
            subtable['beta_count'][~ln_mask] = beta_counts[count_index]
            subtable['beta_count_inverse'][~ln_mask] = 1.0 / beta_counts[count_index]
            subtable['beta_count_total'][~ln_mask] = ab_candidates.size
            subtable['beta_count_inverse_total'][~ln_mask] = 1.0 / ab_candidates.size

            # fill fields that are the same, independent of beta candidate
            subtable['linear'] = ln_mask
            subtable['alpha_index'] = alpha_pep_index
            subtable['alpha_score'] = alpha_score
            subtable['alpha_rank'] = top_alpha_ranks[alpha_i]

            all_ab_candidates.append(ab_candidates)
            subtables.append(subtable)

        # if there are no subtables then there is no need to continue
        if len(subtables) == 0:
            return

        all_ab_candidates = np.concatenate(all_ab_candidates)

        # stack all subtables together to get the result table
        result_table = np.hstack(subtables)

        # calculate alpha_beta_score
        result_table['alpha_beta_score'] = candidates.ab_candidate_score(
            alpha_beta_spectrum, all_ab_candidates, context)

        # remove non-linkable alpha-beta candidates
        linkable_mask = ~np.isnan(result_table['alpha_beta_score'])
        all_ab_candidates = all_ab_candidates[linkable_mask]
        result_table = result_table[linkable_mask]

        # abort if there are no candidates left
        if result_table.size == 0:
            return

        # calculate the beta scores
        context.beta_score.calculate(result_table, all_ab_candidates['beta_pep_index'],
                                     all_alphas)

        # fill in precursor related fields
        result_table['precursor_charge'] = spectrum.precursor_charge  # ToDo: Xi-290
        result_table['precursor_mass'] = \
            spectrum.precursor_mass - all_ab_candidates['isotope_index'] * const.C12C13_MASS_DIFF
        result_table['precursor_mz'] = \
            result_table['precursor_mass'] / result_table['precursor_charge'] + const.PROTON_MASS

        result_table['beta_index'] = all_ab_candidates['beta_pep_index']
        result_table['precursor_missing_isotope_peak'] = all_ab_candidates['isotope_index']
        result_table['crosslinker_index'] = all_ab_candidates['crosslinker_index']

        # filter to top_n alpha beta candidates (top n unique scores)
        result_table_indices, result_ranks = candidates.top_n_unique_scores(
            result_table['alpha_beta_score'], context.config.top_n_alpha_beta_scores)
        result_table = result_table[result_table_indices]
        result_table['alpha_beta_rank'] = result_ranks

        # Loop over top alpha_beta candidates for annotation
        annotations = []
        prot_link_sites = []
        pep_link_scores = []
        for i, entry in enumerate(result_table):

            alpha_pep_index = entry['alpha_index']
            beta_pep_index = entry['beta_index']
            xl_id = entry['crosslinker_index']
            basic_frags = candidates.ab_candidate_fragments(alpha_pep_index, beta_pep_index,
                                                            xl_id, context)

            linear_match = entry['linear']

            # get link sites and annotations for alpha beta match
            link_sites = crosslink.find_link_site(i, full_match_spectrum, alpha_pep_index,
                                                  beta_pep_index, xl_id, context, basic_frags)

            # get the fragment annotations of the best link site combination
            best_link_site_annotations = link_sites[0]['annotation']
            # set the candidate id
            best_link_site_annotations['alpha_beta_index'] = i
            # save the annotations
            annotations.append(best_link_site_annotations)

            result_table['alpha_beta_index'][i] = i

            # order the pep_ids so that p1 is the better explained peptide
            peptide_pair_indices = [alpha_pep_index, beta_pep_index]
            if linear_match:
                pep_order = [1, 2]
            else:
                pep_order = spectra_reader.order_peptide_ids(best_link_site_annotations, n_peps=2)

            # set the pep_id of the alpha and the beta peptide
            result_table['alpha_id'][i] = pep_order[0]
            result_table['beta_id'][i] = pep_order[1]

            # reorder link sites for link score array
            link_score_arr = np.empty(link_sites.size, dtype=dtypes.link_score)
            link_score_arr['alpha_beta_index'] = link_sites['alpha_beta_index']
            link_score_arr['link_p1'] = link_sites[f'link{pep_order[0]}']
            link_score_arr['link_p2'] = link_sites[f'link{pep_order[1]}']
            link_score_arr['score'] = link_sites['score']
            pep_link_scores.append(link_score_arr)

            # set the best link position to the result table
            p1_link_pos = link_score_arr['link_p1'][0]
            p2_link_pos = link_score_arr['link_p2'][0]
            result_table['link_pos_p1'][i] = p1_link_pos
            result_table['link_pos_p2'][i] = p2_link_pos

            p1_pep_index = peptide_pair_indices[pep_order[0] - 1]
            p2_pep_index = peptide_pair_indices[pep_order[1] - 1]

            # assign p1/2 index, mass, sequence and aa length
            result_table['p1_index'][i] = p1_pep_index
            result_table['mass_p1'][i] = context.peptide_db.peptide_mass(p1_pep_index)
            result_table['aa_len_p1'][i] = context.modified_peptides_aa_lengths[p1_pep_index]
            base_seq_p1 = context.peptide_db.unmod_pep_sequence(p1_pep_index)
            p1_sites = context.get_sites_for_mod_pep_index(p1_pep_index)

            # write pep decoy info (if all proteins the peptide could come from are decoy proteins)
            result_table['decoy_p1'][i] = all([
                context.proteins[p1_site['protein_id']]['decoy'] for p1_site in p1_sites])

            result_table['p2_index'][i] = p2_pep_index
            if linear_match:
                result_table['aa_len_p2'][i] = 0
                result_table['mass_p2'][i] = 0
                result_table['linked_aa_p1'][i] = ''
                result_table['linked_aa_p2'][i] = ''
                result_table['decoy_p2'][i] = False
                protein_link_positions = [
                    (i,  # candidate_id
                     p1_link_site['protein_id'],  # prot1
                     -1,  # prot2
                     p1_link_site['start'],  # pep_pos1
                     -1,  # pep_pos2
                     -1,  # link_pos1
                     -1)  # link_pos2
                    for p1_link_site in p1_sites
                ]
            # non-linear cases
            else:
                result_table['mass_p2'][i] = context.peptide_db.peptide_mass(p2_pep_index)
                result_table['aa_len_p2'][i] = context.modified_peptides_aa_lengths[p2_pep_index]
                base_seq_p2 = context.peptide_db.unmod_pep_sequence(p2_pep_index)
                p2_sites = context.get_sites_for_mod_pep_index(p2_pep_index)
                result_table['decoy_p2'][i] = all([
                    context.proteins[p2_site['protein_id']]['decoy'] for p2_site in p2_sites])
                # noncovalent
                if xl_id == -1:
                    result_table['linked_aa_p1'][i] = ''
                    result_table['linked_aa_p2'][i] = ''
                    protein_link_positions = [
                        (i,  # candidate_id
                         p1_link_site['protein_id'],  # prot1
                         p2_link_site['protein_id'],  # prot2
                         p1_link_site['start'],  # pep_pos1
                         p2_link_site['start'],  # pep_pos2
                         -1,  # link_pos1
                         -1)  # link_pos2
                        for p2_link_site in p2_sites
                        for p1_link_site in p1_sites
                    ]
                # crosslink
                else:
                    result_table['linked_aa_p1'][i] = chr(base_seq_p1[p1_link_pos])
                    result_table['linked_aa_p2'][i] = chr(base_seq_p2[p2_link_pos])
                    crosslinker = context.config.crosslinker[xl_id]
                    protein_link_positions = [
                        (i,  # candidate_id
                         p1_link_site['protein_id'],  # prot1
                         p2_link_site['protein_id'],  # prot2
                         p1_link_site['start'],  # pep_pos1
                         p2_link_site['start'],  # pep_pos2
                         p1_link_site['start'] + p1_link_pos,  # link_pos1
                         p2_link_site['start'] + p2_link_pos)  # link_pos2
                        for p2_link_site in p2_sites
                        for p1_link_site in p1_sites
                        if is_protein_linkable(p1_pep_index, p1_link_pos, p1_link_site,
                                               p2_pep_index, p2_link_pos, p2_link_site,
                                               crosslinker, context)
                    ]

            prot_link_sites.append(np.array(protein_link_positions,
                                            dtype=dtypes.prot_link_sites))

        # run the ScorePipeline
        result_table = context.score_pipeline.run(
            result_table, spectrum=full_match_spectrum, all_annotations=annotations
        )

        # prioritize linear over consecutive crosslinked for same number of fragments matched
        result_table = prioritize_linear_over_consecutive_cl(result_table, context)

        # filter result data
        result_table = filter_results(result_table, context)
        if len(result_table) == 0:
            return

        # combine link-site scores
        pep_link_scores = np.concatenate(pep_link_scores)
        # some matches might be filtered out, then we don't need to forward the link-site infos
        pep_link_scores = pep_link_scores[np.isin(pep_link_scores['alpha_beta_index'],
                                                  result_table['alpha_beta_index'])]

        # write protein sites
        prot_link_sites = np.concatenate(prot_link_sites)
        # some matches might be filtered out, then we don't need to forward the link-site infos
        prot_link_sites = prot_link_sites[isin_set_long(prot_link_sites['alpha_beta_index'],
                                                        result_table['alpha_beta_index'])]

        # filter the annotations to only the ones that belong to the writen out results
        # (based on i above)
        annotations = [annotations[abid] for abid in result_table['alpha_beta_index']]
        # write results
        result_queue.put(SpectrumResult(spectrum, result_table, prot_link_sites, pep_link_scores,
                                        annotations))


def is_protein_linkable(pep1_index, link1_pos, pep1_site, pep2_index, link2_pos, pep2_site,
                        crosslinker, context):
    """
    Check terminal linkability of a peptide is linkable on the protein.

    The function assumes that the input peptides have already been checked for peptide-level
    linkability.
    :param pep1_index: index for modified_peptides of peptide 1
    :param link1_pos: aa link position peptide 1
    :param pep1_site: site (on protein) from sites_db for peptide 1
    :param pep2_index: index for modified_peptides of peptide 2
    :param link2_pos: aa link position on peptide 2
    :param pep2_site: site (on protein) from sites_db for peptide 2
    :param crosslinker: the cross-linker involved
    :param context: Searcher
    :returns: boolean
    :rtype: bool
    """
    # if these are -1, we're dealing with a linear case
    if link1_pos == -1 or link2_pos == -1:
        return False

    aa_spec = crosslinker.ord_aa_specificity
    mod_spec = crosslinker.mod_specificity
    mod_names = [''] + [mod.name for mod in context.config.modification.modifications]
    mod_codes = [[mod_names.index(mod) for mod in end] for end in mod_spec]

    def check_terminal_link(pep_index, link_pos, pep_site, crosslinker_side):
        """
        Check if a terminal link is possible for this peptide on this protein.

        :param pep_index: index for modified_peptides of the peptide
        :param link_pos: aa link position peptide 1
        :param pep_site: site (on protein) from sites_db for the peptide
        :param crosslinker_side: index for the crosslinker specificity
        :return: (bool) linkable or not
        """
        pep_cterm_index = context.modified_peptides_aa_lengths[pep_index] - 1

        # if the link is not on the first or last amino acid it's ok
        # (was checked already by get_possible_link_sites)
        if 0 < link_pos < pep_cterm_index:
            return True

        # check if if the term aa's are blocked (by the digestion) for this position
        if pep_site['nterm_aa_block'] and link_pos == 0 or \
                pep_site['cterm_aa_block'] and link_pos == pep_cterm_index:
            return False

        link_site_aa = context.peptide_db.unmod_pep_sequence(pep_index)[link_pos]
        mod_pep = context.modified_peptides[pep_index]
        # check nterm - ToDo: modified term not linkable for now
        if pep_site['nterm'] and crosslinker.nterm[crosslinker_side] and link_pos == 0 \
                and mod_pep['modifications'][0] == 0:
            return True
        # check cterm
        if pep_site['cterm'] and crosslinker.cterm[crosslinker_side] \
                and link_pos == pep_cterm_index and mod_pep['modifications'][1] == 0:
            return True
        else:
            # check amino acid
            try:
                aa_index = aa_spec[crosslinker_side].index(link_site_aa)
            except ValueError:
                return False
            # check modification
            return mod_pep['modifications'][link_pos + 2] == mod_codes[crosslinker_side][aa_index]

    # cl side 0
    # 88 is X (wildcard) amino acid
    if 88 in aa_spec[0]:
        spec1_link1_ok = spec1_link2_ok = True
    else:
        spec1_link1_ok = check_terminal_link(pep1_index, link1_pos, pep1_site, 0)
        spec1_link2_ok = check_terminal_link(pep2_index, link2_pos, pep2_site, 0)
    if crosslinker.homobifunctional:
        return spec1_link1_ok and spec1_link2_ok
    else:
        # cl side 1
        if 88 in aa_spec[1]:
            spec2_link1_ok = spec2_link2_ok = True
        else:
            spec2_link1_ok = check_terminal_link(pep1_index, link1_pos, pep1_site, 1)
            spec2_link2_ok = check_terminal_link(pep2_index, link2_pos, pep2_site, 1)
        if spec1_link1_ok and spec1_link2_ok:
            return spec2_link1_ok or spec2_link2_ok
        elif spec1_link1_ok:
            return spec2_link2_ok
        elif spec1_link2_ok:
            return spec2_link1_ok

    return False


def is_consecutive(pep1_sites, pep2_sites):
    """
    Check if two peptides occur consecutively.

    :param pep1_sites: site (on protein) from sites_db for peptide 1
    :param pep2_sites: site (on protein) from sites_db for peptide 2
    :return: (bool) True if the peptides occur as consecutive sequence else False
    """
    protein_matches = np.equal(pep1_sites['protein_id'], pep2_sites['protein_id'].reshape(-1, 1))
    consec_matches = np.equal(pep1_sites['end'], pep2_sites['start'].reshape(-1, 1))

    # protein ids have to match AND start-end positions
    matches = np.logical_and(protein_matches, consec_matches)

    return np.any(matches)


def prioritize_linear_over_consecutive_cl(score_table, context):
    """
    Prioritize linear peptide vs. crosslinked version under certain circumstances.

    If:
    1. A top ranking alpha-beta candidate consists of two consecutive peptide sequences
    2. The linear version of these two peptides is also among the alpha-beta candidates
    3. The linear version has at least the same `unique_peak_primary_fragsites_pp` score

    Then:
    The linear version with the highest match_score gets re-ranked to be the top ranking result.

    :param score_table: (struct ndarray) Alpha-beta candidate score table
    :param context: (Searcher) Search context
    :return: Re-ranked alpha-beta candidate score table
    """
    lin_candidates = score_table[score_table['p2_index'] == -1]
    # abort if there are no linear matches
    if lin_candidates.size == 0:
        return score_table

    matches = []
    # get top ranking crosslinked matches
    top_candidates = score_table[score_table['top_ranking'] & (score_table['p2_index'] != -1)]
    # there is an off chance that it's more than one
    for top_candidate in top_candidates:
        # filter for equal or higher 'unique_peak_primary_fragsites_pp' score on linears
        score = 'unique_peak_primary_fragsites_pp'
        lin_candidates = lin_candidates[lin_candidates[score] >= top_candidate[score]]
        # continue if no linears left
        if lin_candidates.size == 0:
            continue

        # get the base sequences
        lin_candidates_base = context.peptide_db.unmod_pep_sequence(lin_candidates['p1_index'])

        # get sites
        p1_sites = context.get_sites_for_mod_pep_index(top_candidate['p1_index'])
        p2_sites = context.get_sites_for_mod_pep_index(top_candidate['p2_index'])

        # get unmodified pep sequence ids
        base_seq_p1 = context.peptide_db.unmod_pep_sequence(top_candidate['p1_index'])
        base_seq_p2 = context.peptide_db.unmod_pep_sequence(top_candidate['p2_index'])

        # check for consecutive peptides and create linearised versions
        linearised = []
        if is_consecutive(p1_sites, p2_sites):
            linearised.append(base_seq_p1 + base_seq_p2)
        if is_consecutive(p2_sites, p1_sites):
            linearised.append(base_seq_p2 + base_seq_p1)

        # continue if this top_candidate is not made of consecutive peptides
        if len(linearised) == 0:
            continue

        # search for linearised versions in other results
        linearised = np.array(linearised)

        # find base sequence matches in the linear candidates
        base_seq_matches = np.char.find(linearised.reshape(-1, 1), lin_candidates_base) == 0

        # get the top ranking match
        match_indices = np.where(np.any(base_seq_matches, 0))[0]
        matches.append(lin_candidates[match_indices])

    if len(matches) == 0:
        return score_table

    matches = np.concatenate(matches)

    if len(matches) == 0:
        return score_table

    # get the alpha_beta_index of the matches with the highest match_score
    top_matches = matches[matches['match_score'] == matches['match_score'].max()]

    # Set top scoring matches to new top_ranking
    score_table['top_ranking'] = isin_set_long(score_table['alpha_beta_index'],
                                               top_matches['alpha_beta_index'])

    return score_table


def filter_results(result_table, context):
    """
    Filter out the most meaningless data as defined in the config.reporting_requirements.

    :param result_table: (struct ndarray) table containing the fully scored results
    :param context: (Searcher) Search context
    :return: returns a copy of the result_table minus the filtered out rows
    """
    mask_min_frag = \
        result_table["unique_peak_primary_fragsites_pp"] >= \
        context.config.reporting_requirements.minimum_observed_fragment_sites

    if context.config.reporting_requirements.report_top_ranking_only:
        result_table = result_table[result_table['top_ranking'] & mask_min_frag]
        return result_table

    mask_top_2 = (result_table["delta"] >= 0) | result_table['top_ranking']

    min_coverage = context.config.reporting_requirements.minimum_spectrum_coverage

    mask_min_spectrum_intensity = result_table["intensity_coverage"] >= min_coverage

    mask_min_spectrum_peaks = result_table["total_peak_coverage"] >= min_coverage

    mask_secondary = mask_min_spectrum_intensity & mask_min_spectrum_peaks

    if context.config.reporting_requirements.delta_score_filter:
        mask_secondary &= result_table["match_score"] > (- result_table["delta"])

    mask_all = mask_min_frag & (mask_top_2 | mask_secondary)

    return result_table[mask_all]
