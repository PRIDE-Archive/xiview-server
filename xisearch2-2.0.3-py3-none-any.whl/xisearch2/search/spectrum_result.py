
class SpectrumResult:
    """Class that collects all results for a single spectrum"""

    score_columns = []
    """ names of all score columns """

    def __init__(self, spectrum, matches, prot_link_sites, peptide_link_sites, annotations):
        """
      Initialise the SpectrumResult.

        :param spectrum: (spectrum) the matched spectrum
        :param matches: (ndarray) matches
        :param protein_link_sites: (ndarray) array that maps the matched peptides to the originating
                                             proteins and the actual linked residue in the protein
                                             dtype is :py:const:xisearch2.dtypes.prot_link_sites
        :param peptide_link_sites: (ndarray) array with links
        :param annotations: (ndarray) array with peak annotations
        """

        """the original spectrum that got matched"""
        self.spectrum = spectrum
        """list of all matches (one per line)"""
        self.matches = matches
        """links the peptide ids to context.proteins"""
        self.protein_link_sites = prot_link_sites
        """contains the possible link-sites, the scores and matched annotations for each
        link-site pair"""
        self.peptide_link_sites_info = peptide_link_sites
        self.annotations = annotations
