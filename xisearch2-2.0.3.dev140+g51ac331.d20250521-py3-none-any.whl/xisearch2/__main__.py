import multiprocessing as mp
import queue as Q
import argparse
import tempfile
import sys
import os
import traceback
import setuptools_scm
from .search import SearchContext, SpectrumProcessor
from .result_writer import TsvResultWriter, DummyResultWriter, ParguetResultWriter
from .load_test import LoadTest, load_test_config, RealDataLoadTest
from .xi_logging import log_enable, progress_enable, log, ProgressBar, log_file
from .config import Config, ConfigReader
from .cache import Cache
from .spectra_reader import PeakListWrapper


# From python 3.14, spawning will be the default.
# Windows does not support forking. When working on windows compatiblity, use 'spawn' method.
# For spawning, all objects that are used in the new process need to be importable/initialisable
# from __main__. The XiSearch class might help with this.
# As for now, the code only works with 'fork' method, because there are some global variables
# that cannot be imported as they are dependend on user options.
mp.set_start_method('fork', force=True)


class OptionParser(argparse.ArgumentParser):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.add_argument(
            "-f",
            "--fasta",
            dest="fasta",
            action="append",
            help="FASTA file with proteins to search against",
            metavar="DB",
        )
        self.add_argument(
            "-b",
            "--no-bar",
            dest="progress_bar",
            default=True,
            action="store_false",
            help="Show progress bar",
        )
        self.add_argument(
            "-c", "--config",
            dest="config",
            help="JSON configuration file",
            metavar="JSON"
        )
        self.add_argument(
            "-i",
            "--input",
            dest="mgf",
            action="append",
            help="Path to file with spectra to search (MGF, mzML, Thermo RAW)",
            metavar="MGF",
        )
        self.add_argument(
            "-o",
            "--output",
            dest="tsv",
            help="TSV file to output search results",
            metavar="TSV",
        )
        self.add_argument(
            "-q",
            "--parquet-output",
            dest="parquet",
            help="parquet file to output search results",
            metavar="parquet",
        )
        self.add_argument(
            "--parquet-buffer-size",
            dest="parquet-buffer",
            default=1000,
            help="parquet file are written in batches of [parquet-buffer-size] matches",
            metavar="parquet",
        )
        self.add_argument(
            "-C",
            "--cache",
            dest="cache",
            help="Cache directory (default is system temp dir)",
            metavar="DIR",
        )
        self.add_argument(
            "-s",
            "--setup-only",
            dest="setup_only",
            default=False,
            action="store_true",
            help="Run setup only",
        )
        self.add_argument(
            "-l",
            "--load-test",
            dest="load_test",
            help="Run load test with N synthetic spectra",
            metavar="N",
            type=int,
        )
        self.add_argument(
            "-L",
            "--load-test-real",
            dest="load_test_real",
            help="Run load test with real data. Valid options: "
            + ", ".join(RealDataLoadTest.test_cases),
            metavar="TYPE",
        )
        self.add_argument(
            "-w",
            "--write-test",
            dest="write_test",
            action="store_const",
            const=tempfile.gettempdir(),
            help="Write out load test results to system temp dir",
        )
        self.add_argument(
            "-p",
            "--profile",
            dest="profile",
            default=False,
            action="store_true",
            help="Profile application code only",
        )
        self.add_argument(
            "-P",
            "--profile-all",
            dest="profile_all",
            default=False,
            action="store_true",
            help="Profile entire code stack",
        )
        self.add_argument(
            "-S",
            "--profile-statistic",
            dest="profile_statistic",
            default=False,
            action="store_true",
            help="Profile entire code stack",
        )
        self.add_argument(
            "--log",
            dest="log_file",
            help="Write logging output to file",
            metavar="TYPE",
        )
        self.add_argument(
            "-O",
            "--config-option",
            dest="additional_config_options",
            default=[],
            action="append",
            help="additional config-option to be evaluated",
        )
        self.add_argument(
            "--pg",
            action="store_true",
            dest="pg_sql",
            default=False,
            help="Enable writing output to PostgreSQL",
        )
        self.add_argument(
            '-n',
            '--pg-search-name',
            dest='result_name',
            help='Name for the new result set to write',
            metavar='NAME',
            default='',
        )
        self.add_argument(
            '-N',
            '--pg-search-note',
            dest='result_note',
            help='Note for the new result set to write',
            metavar='NOTE',
            default='',
        )
        self.add_argument(
            "--pg-hostname",
            dest="pg_hostname",
            default=None,
            help="Hostname of PostgreSQL server to connect to",
        )
        self.add_argument(
            "--pg-port",
            dest="pg_port",
            default=5432,
            help="TCP port to use for connecting to PostgreSQL",
        )
        self.add_argument(
            "--pg-username",
            dest="pg_username",
            default=None,
            help="Username to use for connecting to PostgreSQL",
        )
        self.add_argument(
            "--pg-password",
            dest="pg_password",
            default=None,
            help="Password to use for connecting to PostgreSQL",
        )
        self.add_argument(
            "--pg-database",
            dest="pg_database",
            default=None,
            help="Database to use after connecting to PostgreSQL",
        )
        self.add_argument(
            "--pg-uuid",
            dest="pg_uuid",
            default=None,
            help="search UUID - if not given a new one is generated",
        )
        self.add_argument(
            "--pg-uuid-output",
            dest="pg_uuid_output",
            default=None,
            help="File to write the resulting search UUID",
        )
        self.add_argument(
            "-t", "--task",
            dest="cluster_task",
            default=0, type=int, metavar="N",
            help="defines that this is the nth task of all tasks (zero based)"
        )
        self.add_argument(
            "-T", "--total-tasks",
            dest="cluster_all_tasks",
            default=1, type=int, metavar="N",
            help="in how many tasks is the search split up"
        )
        self.add_argument(
            "--version",
            dest="print_version",
            default=False,
            action="store_true",
            help="print the xisearch2 version"
        )


def get_version():
    # Try to get version from version file
    try:
        from ._version import __version__
        return __version__
    except Exception:
        pass
    # Try to get version from workdir
    try:
        return setuptools_scm.get_version()
    except Exception:
        pass
    # No version found
    return "unkown"


def fail(message):
    print(message)
    log(message)
    sys.exit(1)


def validate_options(options):
    '''
    Validate the user options/command line arguments.
    '''
    message = ''

    if options.pg_sql:
        if not options.pg_hostname:
            message = 'PG hostname is required with PG result writer'
        if not options.pg_username:
            message = 'PG username is required with PG result writer'
        if not options.pg_database:
            message = 'PG database is required with PG result writer'
        if (not options.pg_uuid_output) and options.pg_uuid is None:
            message = 'PG UUID Output is required with PG result writer'

    if options.load_test and options.load_test_real:
        message = 'Choose either synthetic data or real data load test'

    if options.load_test or options.load_test_real:
        if options.mgf:
            message = 'Load test is mutually exclusive with MGF file_name'
        if options.tsv:
            message = 'TSV output is not supported for load test'
        if options.parquet:
            message = 'Parquet output is not supported for load test'
    else:
        if options.write_test:
            message = 'write-test requires load-test option'
        if not options.mgf:
            message = 'MGF spectra file_name is required'
        if not options.pg_sql and not (options.tsv or options.parquet):
            message = 'TSV or parquet output file_name is required when not using PG result writer'

    # check if we have valid settings for split processing
    if options.cluster_task is not None:
        if options.cluster_task >= options.cluster_all_tasks:
            message = '"task" (-t) has to be smaller then "all tasks" (-T)'
    if message != '':
        fail(message)


def write_queue(queue, keep_writing, writing_finished):
    while keep_writing.value:
        try:
            s = queue.get(True, 1)
            while len(s.matches) > 0:
                for rw in result_writer:
                    rw.write(s)
                s = queue.get(False)
        except Q.Empty:
            ...
    for rw in result_writer:
        rw.close()
    writing_finished.value = True


if __name__ == "__main__":
    parser = OptionParser()
    options = parser.parse_args()

    if options.profile_all:
        options.profile = True
    if options.profile_statistic:
        options.profile = True

    log_enable(True)
    if options.log_file:
        log_file(options.log_file)

    if options.print_version:
        print(get_version())
        sys.exit(0)

    log(f'Running xisearch2 version {get_version()}')

    progress_enable(options.progress_bar)

    if not options.fasta and not options.load_test_real:
        fail("FASTA protein database file_name is required")

    # Select cache
    if options.cache:
        cache_directory = options.cache
    else:
        cache_directory = os.path.join(tempfile.gettempdir(), "xisearch2", "cache")

    log("Cache directory used: " + cache_directory)

    # Create cache directory if it does not exist yet
    if not os.path.exists(cache_directory):
        os.makedirs(cache_directory)

    cache = Cache(cache_directory)

    if options.load_test:
        test = LoadTest(cache, n_spectra=options.load_test)
        config = load_test_config
    elif options.load_test_real:
        test = RealDataLoadTest(options.load_test_real)
        options.fasta = test.fasta
        config = test.config
    elif options.config:
        config = ConfigReader.load_file(options.config)
    else:
        config = Config()

    for o in options.additional_config_options:
        exec("config." + o)

    context = SearchContext(options.fasta, config, cache, search_uuid=options.pg_uuid,
                            this_task=options.cluster_task, all_tasks=options.cluster_all_tasks)
    processor = SpectrumProcessor(context)

    # define function to process each spectra
    if options.progress_bar:

        def main(spectrum):
            try:
                processor.process_spectrum(spectrum, result_queue)
                bar_queue.put(True)
            except Exception:
                traceback.print_exc()
                return False
            return True

    else:

        def main(spectrum):
            try:
                processor.process_spectrum(spectrum, result_queue)
            except Exception:
                traceback.print_exc()
                return False
            return True

    # Validate argument combinations
    result_writer = []
    validate_options(options)
    # Setup search
    if options.load_test or options.load_test_real:
        test.setup(context)
        if options.setup_only:
            sys.exit(0)

        options.mgf = test.mgf
        if options.write_test:
            out_file = os.path.join(options.write_test, "load_test.tsv")
            result_writer.append(TsvResultWriter(out_file, context))
        else:
            result_writer.append(DummyResultWriter(context))

    else:
        if options.setup_only:
            sys.exit(0)

        if options.pg_sql:
            from .pg_result_writer import PGResultWriter
            json_config = open(options.config, "r").read()
            result_writer.append(PGResultWriter(
                options.pg_hostname,
                options.pg_port,
                options.pg_username,
                options.pg_password,
                options.pg_database,
                options.pg_uuid_output,
                json_config,
                context,
                options.result_name,
                options.result_note,
            ))

        if options.tsv:
            result_writer.append(TsvResultWriter(options.tsv, context))

        if options.parquet:
            result_writer.append(ParguetResultWriter(options.parquet, context,
                                                     cache_size=options.parquet_buffer))

    # The multiprocessing queue that we use to get data to the writer. The Spectrum
    # Processors will be writing to this and the queue_writer reads from it.
    result_queue = mp.Queue()
    # This is a shared value to be used with the writer process: it allows us to let
    # the writer know that we are done processing and the writer can close itself.
    keep_writing = mp.Value("b", True)
    # Shared value to get feedback from the writer when it is done writing out.
    writing_finished = mp.Value("b", False)
    # Setting 'daemon=True' below means that if the main process dies (eg, because of
    # an error) the writer will die as well. This means, however, that we must take
    # care to deal with the writer carefully or we could lose data. That is why we
    # call writer_process.join() at the end of this method.
    writer_process = mp.Process(
        target=write_queue,
        args=(result_queue, keep_writing, writing_finished),
        daemon=True,
    )
    writer_process.start()

    log("Loading spectra")
    spectra_wrapper = PeakListWrapper(context)
    spectra_wrapper.load(options.mgf)
    num_spectra = spectra_wrapper.count_spectra()
    log("Loaded %d spectra, starting search" % num_spectra)

    if options.progress_bar:
        bar_queue = mp.Queue()
        bar = ProgressBar("Processing spectra", num_spectra)

        def bar_updater(queue):
            while True:
                s = queue.get()
                if s:
                    bar.next()
                else:
                    return

        bar_process = mp.Process(target=bar_updater, args=(bar_queue,), daemon=True)
        bar_process.start()

    if options.profile:
        if options.profile_statistic:
            try:
                from pprofile import StatisticalProfile
            except ImportError:
                print("The StatisticalProfile module could not be imported - run pipenv -d "
                      "install")
                exit()
            profile = StatisticalProfile()
        else:
            try:
                from pprofile import Profile
            except ImportError:
                print("The Profile module could not be imported - run pipenv -d "
                      "install")
                exit()
            profile = Profile()

        with profile():
            for spectrum in spectra_wrapper.spectra:
                main(spectrum)
        if options.profile_all:
            filenames = profile.getFilenameSet()
        else:
            filenames = {
                f
                for f in profile.getFilenameSet()
                if f.startswith(os.path.dirname(__file__))
            }
        with open("callgrind.out", "w+") as f:
            profile.callgrind(f, commandline=" ".join(sys.argv), filename=filenames)

    else:
        thread_count = config.threads
        if thread_count == 0:
            thread_count = None  # multithreading doesn't like 0 as a value
        elif thread_count < 0:
            thread_count = mp.cpu_count() + thread_count
        if thread_count == 1:
            for s in spectra_wrapper.spectra:
                main(s)
        else:
            thread_pool = mp.Pool(thread_count)
            # process spectra across threads
            for r in thread_pool.imap_unordered(main, spectra_wrapper.spectra, 10):
                if not r:
                    raise Exception(
                        "Exception occurred during main search! See stack trace above for details."
                    )

            # https://pytest-cov.readthedocs.io/en/latest/subprocess-support.html#if-you-use-multiprocessing-pool
            thread_pool.close()  # Marks the pool as closed.
            thread_pool.join()  # Waits for workers to exit.

    # end progress bar
    if options.progress_bar:
        bar.finish()
        bar_queue.put(None)
        bar_queue.close()
        bar_queue.join_thread()
        bar_process.join()

    # tell the writer we're done and wait for it to stop
    keep_writing.value = False
    # Not sure why we need the next 5 lines, just a `writer_process.join()` should be
    # enough. But for some reason, the writer_process doesn't always die, and then the
    # `join` doesn't return.
    log("Search finished, waiting for result writer to complete...")
    result_queue.close()
    result_queue.join_thread()
    writer_process.join(1)
    write_wait_time = 0
    while not writing_finished.value:
        log("Writing not finished. Still waiting...")
        writer_process.join(30)
        write_wait_time += 30
        if write_wait_time >= 1800:
            write_time_out_msg = (
                "Writing timeout! Writing did not finish in 30 minutes."
            )
            log(write_time_out_msg)
            raise Exception(write_time_out_msg)

    log("Finished search!")
    log(False)
