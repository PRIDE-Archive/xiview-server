from .base_annotation import BaseAnnotationScore


class AutoValidationScore(BaseAnnotationScore):
    """
    Automatic validation based on random tree evaluation (ported from xiSEARCH1).

    Uses two sets of trees
    """

    dtype = [
        ('auto_validation', bool),
    ]

    def __init__(self, _):
        """Initialise the score."""
        pass

    def calculate_single(self, index, table, annotations, **_):
        """
        Calculate auto validation status.

        :param index: (int) index into the score table to write
        :param table: (ndarray) score table
        :param annotations: not used for this score
        """
        if table[index]['linear']:
            table[index]['auto_validation'] = False

        # first set of trees (rand_tree)
        rand_tree_results = [
            self._rand_tree1(table[index]),
            self._rand_tree2(table[index]),
            self._rand_tree3(table[index]),
            self._rand_tree4(table[index]),
            self._rand_tree5(table[index]),
            self._rand_tree6(table[index]),
            self._rand_tree7(table[index]),
            self._rand_tree8(table[index]),
            self._rand_tree9(table[index]),
            self._rand_tree10(table[index]),
        ]
        # second set of trees (rep_tree)
        rep_tree_results = [
            self._rep_tree1(table[index]),
            self._rep_tree2(table[index]),
            self._rep_tree3(table[index]),
            self._rep_tree4(table[index]),
            self._rep_tree5(table[index]),
            self._rep_tree6(table[index]),
            self._rep_tree7(table[index]),
            self._rep_tree8(table[index]),
            self._rep_tree9(table[index]),
            self._rep_tree10(table[index]),
        ]

        if sum(rand_tree_results) <= 3 and sum(rep_tree_results) <= 3:
            table[index]['auto_validation'] = True
        else:
            table[index]['auto_validation'] = False

    @staticmethod
    def _rand_tree1(table):
        if table['unique_peak_conservative_fragsites_pp'] < 13.5:
            if table['sequence_tag_coverage_p2'] < 0.17:
                if table['precursor_mass'] < 2751.37:
                    return 1
                else:
                    if table['primary_fragsites_pp'] < 15.5:
                        return 1
                    else:
                        if table['alpha_score'] < 85.17:
                            if table['precursor_mz'] < 750.16:
                                return 0
                            else:
                                return 1
                        else:
                            return 0
            else:
                if table['conservative_fragsites_pp'] < 10.5:
                    if table['top100_peak_coverage'] < 0.25:
                        return 1
                    else:
                        return 0
                else:
                    if table['alpha_delta_score'] < 24.07:
                        if table['intensity_coverage'] < 0.32:
                            return 1
                        else:
                            if table['sequence_tag_coverage_pp'] < 0.33:
                                return 1
                            else:
                                return 0
                    else:
                        if table['fragment_error_normalized_mean'] < 0.22:
                            if table['conservative_intensity_coverage'] < 0.22:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
        else:
            if table['primary_fragsites_p2'] < 4.5:
                if table['unique_peak_primary_fragsites_p2'] < 3.5:
                    if table['precursor_mass'] < 4846.54:
                        if table['unique_peak_fragsites_p2'] < 5.5:
                            return 1
                        else:
                            if table['single_peak_coverage'] < 0.12:
                                return 0
                            else:
                                return 1
                    else:
                        return 1
                else:
                    if table['conservative_coverage_p2'] < 0.27:
                        if table['primary_intensity_coverage'] < 0.51:
                            return 1
                        else:
                            if table['precursor_error_1-normalized'] < 0.81:
                                return 1
                            else:
                                return 0
                    else:
                        if table['intensity_coverage'] < 0.38:
                            return 1
                        else:
                            if table['precursor_error_1-normalized'] < 0.81:
                                return 1
                            else:
                                return 0
            else:
                if table['conservative_fragsites_p2'] < 6.5:
                    if table['spectrum_quality_score'] < 0.46:
                        if table['precursor_error_1-normalized'] < 0.85:
                            return 1
                        else:
                            if table['sequence_tag_coverage_pp'] < 0.31:
                                return 1
                            else:
                                return 0
                    else:
                        return 0
                else:
                    if table['primary_intensity_coverage'] < 0.27:
                        if table['p2_score'] < 0.35:
                            return 1
                        else:
                            return 0
                    else:
                        return 0

    @staticmethod
    def _rand_tree2(table):
        if table['primary_fragsites_pp'] < 13.5:
            if table['unique_peak_primary_coverage_pp'] < 0.45:
                if table['top40_peak_coverage'] < 0.34:
                    if table['top100_peak_coverage'] < 0.25:
                        if table['beta_score'] < 30.63:
                            return 1
                        else:
                            if table['fragment_error_ppm_mean_square'] < 10.46:
                                return 0
                            else:
                                return 1
                    else:
                        if table['conservative_coverage_p2'] < 0.31:
                            return 1
                        else:
                            if table['precursor_error_1-normalized'] < 0.91:
                                return 1
                            else:
                                return 0
                else:
                    if table['sequence_tag_coverage_pp'] < 0.28:
                        if table['precursor_mz'] < 901.07:
                            return 1
                        else:
                            if table['precursor_mass'] < 2979.12:
                                return 0
                            else:
                                return 1
                    else:
                        return 0
            else:
                if table['precursor_mass'] < 2373.72:
                    if table['sequence_tag_coverage_p2'] < 0.23:
                        if table['fragment_library_score_exponential'] < 1:
                            return 1
                        else:
                            if table['alpha_beta_score'] < 192.46:
                                return 1
                            else:
                                return 0
                    else:
                        if table['fragment_library_score_log'] < 18.45:
                            if table['spectrum_quality_score'] < 0.38:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                else:
                    if table['precursor_mass'] < 2603.28:
                        if table['precursor_mass'] < 2586.79:
                            return 1
                        else:
                            return 0
                    else:
                        return 0
        else:
            if table['unique_peak_primary_coverage_p2'] < 0.34:
                if table['primary_fragsites_p2'] < 5.5:
                    if table['fragment_library_score_log'] < 56.32:
                        return 1
                    else:
                        if table['unique_peak_conservative_coverage_p2'] < 0.17:
                            if table['total_peak_coverage'] < 0.57:
                                return 1
                            else:
                                return 0
                        else:
                            if table['conservative_fragsites_p2'] < 3.5:
                                return 1
                            else:
                                return 0
                else:
                    if table['intensity_coverage'] < 0.42:
                        if table['precursor_error_1-normalized'] < 0.86:
                            return 1
                        else:
                            if table['alpha_delta_score'] < 32.36:
                                return 1
                            else:
                                return 0
                    else:
                        return 0
            else:
                if table['primary_fragsites_p2'] < 4.5:
                    if table['conservative_coverage_p2'] < 0.39:
                        if table['precursor_mass'] < 4126.15:
                            return 1
                        else:
                            return 0
                    else:
                        return 1
                else:
                    if table['alpha_beta_delta_score'] < 0.68:
                        if table['spectrum_quality_score'] < 0.47:
                            if table['fragment_error_ppm_mean_square'] < 33.82:
                                return 0
                            else:
                                return 1
                        else:
                            return 0
                    else:
                        return 0

    @staticmethod
    def _rand_tree3(table):
        if table['primary_fragments_pp'] < 15.5:
            if table['conservative_fragsites_pp'] < 10.5:
                if table['precursor_mass'] < 2458.24:
                    if table['conservative_multi_fragsites_pp'] < 0.07:
                        if table['precursor_mass'] < 1974.07:
                            return 1
                        else:
                            if table['precursor_mass'] < 1974.55:
                                return 0
                            else:
                                return 1
                    else:
                        return 1
                else:
                    if table['precursor_mass'] < 2793.46:
                        if table['precursor_mz'] < 493.18:
                            if table['precursor_mz'] < 478.89:
                                return 1
                            else:
                                return 0
                        else:
                            if table['precursor_mass'] < 2458.43:
                                return 0
                            else:
                                return 1
                    else:
                        if table['precursor_mass'] < 2793.99:
                            return 0
                        else:
                            return 1
            else:
                if table['alpha_beta_delta_score'] < 6.26:
                    if table['unique_peak_conservative_coverage_p1'] < 0.56:
                        if table['conservative_multi_fragsites_pp'] < 0.11:
                            return 1
                        else:
                            if table['beta_score'] < 30.71:
                                return 1
                            else:
                                return 0
                    else:
                        if table['primary_coverage_p2'] < 0.39:
                            if table['precursor_mass'] < 2749.02:
                                return 1
                            else:
                                return 0
                        else:
                            if table['sequence_tag_coverage_pp'] < 0.48:
                                return 1
                            else:
                                return 0
                else:
                    if table['unique_peak_primary_coverage_p2'] < 0.35:
                        return 1
                    else:
                        if table['beta_score'] < 9.5:
                            return 1
                        else:
                            if table['conservative_intensity_coverage'] < 0.32:
                                return 1
                            else:
                                return 0
        else:
            if table['spectrum_quality_score'] < 0.48:
                if table['unique_peak_conservative_fragsites_p2'] < 4.5:
                    if table['all_coverage_p1'] < 0.53:
                        if table['all_fragsites_p2'] < 11.5:
                            return 1
                        else:
                            return 0
                    else:
                        if table['unique_peak_loss_fragsites_p2'] < 9.5:
                            return 1
                        else:
                            return 0
                else:
                    if table['unique_peak_primary_coverage_p1'] < 0.36:
                        if table['primary_coverage_p2'] < 0.37:
                            return 1
                        else:
                            return 0
                    else:
                        if table['sequence_tag_coverage_pp'] < 0.29:
                            if table['fragment_library_score_log'] < 56.03:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
            else:
                if table['primary_fragsites_p2'] < 4.5:
                    if table['precursor_error_1-normalized'] < 0.82:
                        return 1
                    else:
                        if table['unique_peak_primary_fragsites_p2'] < 3.5:
                            return 1
                        else:
                            return 0
                else:
                    return 0

    @staticmethod
    def _rand_tree4(table):
        if table['conservative_fragsites_p2'] < 4.5:
            if table['precursor_mass'] < 2362.17:
                if table['primary_coverage_pp'] < 0.46:
                    if table['intensity_coverage'] < 0.57:
                        return 1
                    else:
                        if table['unique_peak_primary_fragsites_p2'] < 3.5:
                            if table['precursor_mass'] < 2285.17:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                else:
                    if table['alpha_delta_score'] < 8.55:
                        if table['precursor_mz'] < 407.32:
                            return 1
                        else:
                            if table['single_peak_coverage'] < 0.49:
                                return 1
                            else:
                                return 0
                    else:
                        if table['alpha_delta_score'] < 34.57:
                            return 1
                        else:
                            if table['top40_peak_coverage'] < 0.19:
                                return 1
                            else:
                                return 0
            else:
                if table['precursor_mass'] < 2793.51:
                    if table['conservative_coverage_pp'] < 0.45:
                        if table['alpha_beta_score'] < 126.46:
                            return 1
                        else:
                            if table['fragment_library_score_log'] < 53.96:
                                return 1
                            else:
                                return 0
                    else:
                        if table['alpha_beta_delta_score'] < 8.17:
                            return 1
                        else:
                            if table['fragment_error_ppm_abs_mean'] < 3.45:
                                return 0
                            else:
                                return 1
                else:
                    if table['primary_fragments_pp'] < 19.5:
                        if table['fragment_library_score_log'] < 49.69:
                            return 1
                        else:
                            if table['loss_coverage_p1'] < 0.33:
                                return 1
                            else:
                                return 0
                    else:
                        return 1
        else:
            if table['fragment_library_score'] < 1:
                if table['unique_peak_primary_coverage_pp'] < 0.41:
                    if table['unique_peak_fragsites_p2'] < 0.5:
                        return 0
                    else:
                        if table['intensity_coverage'] < 0.4:
                            return 1
                        else:
                            if table['loss_fragsites_p1'] < 5.5:
                                return 0
                            else:
                                return 1
                else:
                    if table['alpha_beta_score'] < 71.71:
                        if table['unique_peak_primary_fragsites_pp'] < 13.5:
                            if table['precursor_mass'] < 2350.25:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        if table['fragment_error_ppm_mean_square'] < 35.27:
                            return 0
                        else:
                            if table['total_peak_coverage'] < 0.26:
                                return 1
                            else:
                                return 0
            else:
                if table['p2_score'] < 0.3:
                    if table['primary_fragsites_pp'] < 18.5:
                        return 1
                    else:
                        if table['beta_score'] < 47.37:
                            return 1
                        else:
                            return 0
                else:
                    return 0

    @staticmethod
    def _rand_tree5(table):
        if table['sequence_tag_coverage_p2'] < 0.1:
            if table['all_fragsites_p1'] < 11.5:
                if table['spectrum_quality_score'] < 0.44:
                    if table['conservative_coverage_pp'] < 0.44:
                        if table['loss_fragsites_pp'] < 12.5:
                            return 1
                        else:
                            if table['fragment_error_ppm_mean_square'] < 29.73:
                                return 0
                            else:
                                return 1
                    else:
                        if table['precursor_mass'] < 2603.28:
                            return 1
                        else:
                            return 0
                else:
                    if table['precursor_mass'] < 2316.66:
                        if table['unique_peak_conservative_coverage_pp'] < 0.43:
                            if table['loss_fragsites_p2'] < 8:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                    else:
                        if table['conservative_coverage_pp'] < 0.45:
                            return 1
                        else:
                            return 0
            else:
                if table['alpha_beta_score'] < 177.6:
                    if table['primary_fragsites_p2'] < 3.5:
                        return 1
                    else:
                        if table['beta_count'] < 74.5:
                            return 1
                        else:
                            if table['conservative_fragsites_pp'] < 26.5:
                                return 1
                            else:
                                return 0
                else:
                    if table['primary_fragsites_pp'] < 22.5:
                        if table['alpha_beta_rank'] < 0.5:
                            if table['loss_fragsites_p2'] < 5.5:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                    else:
                        if table['primary_fragsites_p2'] < 3.5:
                            return 1
                        else:
                            if table['fragment_error_ppm_mean_square_root'] < 5.79:
                                return 0
                            else:
                                return 1
        else:
            if table['spectrum_quality_score'] < 0.41:
                if table['conservative_fragsites_pp'] < 13.5:
                    if table['unique_peak_conservative_fragsites_pp'] < 9.5:
                        return 1
                    else:
                        if table['unique_peak_loss_coverage_pp'] < 0.28:
                            if table['precursor_mz'] < 468.31:
                                return 0
                            else:
                                return 1
                        else:
                            return 1
                else:
                    if table['all_coverage_p1'] < 0.41:
                        if table['primary_fragsites_p2'] < 6.5:
                            return 1
                        else:
                            if table['fragment_error_ppm_abs_mean'] < 4.73:
                                return 0
                            else:
                                return 1
                    else:
                        if table['conservative_intensity_coverage'] < 0.19:
                            if table['alpha_beta_score'] < 144.16:
                                return 1
                            else:
                                return 0
                        else:
                            if table['alpha_score'] < 97.03:
                                return 0
                            else:
                                return 1
            else:
                if table['unique_peak_fragsites_p2'] < 4.5:
                    if table['primary_fragsites_p2'] < 4.5:
                        if table['unique_peak_conservative_fragsites_p2'] < 2.5:
                            return 1
                        else:
                            if table['primary_coverage_p1'] < 0.38:
                                return 1
                            else:
                                return 0
                    else:
                        if table['unique_peak_loss_coverage_p2'] < 0.41:
                            if table['alpha_beta_delta_score'] < 0.43:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                else:
                    if table['unique_peak_primary_fragsites_p2'] < 4.5:
                        if table['loss_coverage_p2'] < 0.21:
                            if table['primary_fragments_pp'] < 27:
                                return 1
                            else:
                                return 0
                        else:
                            if table['precursor_mass'] < 2689.94:
                                return 1
                            else:
                                return 0
                    else:
                        return 0

    @staticmethod
    def _rand_tree6(table):
        if table['conservative_fragsites_pp'] < 13.5:
            if table['alpha_delta_score'] < 22.24:
                if table['precursor_mz'] < 699.37:
                    return 1
                else:
                    if table['p2_score'] < 0.43:
                        if table['precursor_charge'] < 3.5:
                            return 1
                        else:
                            if table['precursor_mass'] < 2793.6:
                                return 0
                            else:
                                return 1
                    else:
                        if table['primary_fragsites_p2'] < 5.5:
                            if table['precursor_mz'] < 699.55:
                                return 0
                            else:
                                return 1
                        else:
                            if table['conservative_coverage_p2'] < 0.39:
                                return 0
                            else:
                                return 1
            else:
                if table['primary_coverage_pp'] < 0.45:
                    if table['conservative_coverage_pp'] < 0.38:
                        return 1
                    else:
                        if table['precursor_error_1-normalized'] < 0.92:
                            return 1
                        else:
                            if table['conservative_fragsites_p1'] < 4.5:
                                return 1
                            else:
                                return 0
                else:
                    if table['intensity_coverage'] < 0.24:
                        if table['precursor_mz'] < 763.85:
                            if table['precursor_charge'] < 4.5:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        return 0
        else:
            if table['unique_peak_primary_fragsites_p2'] < 4.5:
                if table['all_coverage_pp'] < 0.42:
                    if table['precursor_mass'] < 2919.44:
                        if table['loss_coverage_p1'] < 0.08:
                            if table['unique_peak_conservative_fragsites_p1'] < 12.5:
                                return 1
                            else:
                                return 0
                        else:
                            if table['precursor_mass'] < 2336.28:
                                return 0
                            else:
                                return 1
                    else:
                        if table['conservative_intensity_coverage'] < 0.59:
                            return 1
                        else:
                            if table['conservative_intensity_coverage'] < 0.59:
                                return 0
                            else:
                                return 1
                else:
                    if table['unique_peak_conservative_fragsites_p2'] < 2.5:
                        if table['precursor_charge'] < 4.5:
                            return 1
                        else:
                            if table['single_peak_coverage'] < 0.48:
                                return 1
                            else:
                                return 0
                    else:
                        if table['sequence_tag_coverage_p2'] < 0.2:
                            return 1
                        else:
                            if table['alpha_beta_delta_score'] < 7.07:
                                return 1
                            else:
                                return 0
            else:
                if table['unique_peak_primary_coverage_p2'] < 0.28:
                    if table['unique_peak_primary_fragsites_p2'] < 6.5:
                        if table['alpha_delta_score'] < 32.58:
                            return 1
                        else:
                            if table['top100_peak_coverage'] < 0.27:
                                return 1
                            else:
                                return 0
                    else:
                        if table['isotope_intensity_matched_fraction'] < 0.51:
                            if table['unique_peak_primary_coverage_p2'] < 0.26:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                else:
                    if table['fragment_library_score'] < 1:
                        if table['intensity_coverage'] < 0.43:
                            if table['unique_peak_primary_coverage_pp'] < 0.44:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        return 0

    @staticmethod
    def _rand_tree7(table):
        if table['beta_score'] < 29.95:
            if table['spectrum_quality_score'] < 0.45:
                if table['conservative_coverage_pp'] < 0.43:
                    if table['alpha_beta_score'] < 180.22:
                        return 1
                    else:
                        if table['conservative_multi_fragsites_p1'] < 0.24:
                            if table['conservative_coverage_p1'] < 0.47:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                else:
                    if table['unique_peak_conservative_fragsites_p2'] < 3.5:
                        if table['precursor_mz'] < 698.63:
                            return 1
                        else:
                            if table['precursor_mz'] < 932.1:
                                return 1
                            else:
                                return 0
                    else:
                        if table['sequence_tag_coverage_pp'] < 0.23:
                            return 1
                        else:
                            return 0
            else:
                if table['unique_peak_primary_fragsites_p2'] < 4.5:
                    if table['loss_fragments_pp'] < 13.5:
                        if table['unique_peak_conservative_fragsites_pp'] < 18.5:
                            return 1
                        else:
                            if table['sequence_tag_coverage_p2'] < 0.28:
                                return 1
                            else:
                                return 0
                    else:
                        if table['conservative_coverage_p2'] < 0.39:
                            if table['spectrum_quality_score'] < 0.81:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                else:
                    if table['sequence_tag_coverage_pp'] < 0.23:
                        return 1
                    else:
                        if table['precursor_error_1-normalized'] < 0.82:
                            if table['unique_peak_primary_coverage_pp'] < 0.38:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
        else:
            if table['unique_peak_primary_coverage_p2'] < 0.31:
                if table['unique_peak_conservative_fragsites_pp'] < 14.5:
                    if table['p1_score'] < 0.45:
                        if table['precursor_charge'] < 3.5:
                            if table['precursor_mz'] < 1129.58:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                    else:
                        if table['spectrum_quality_score'] < 0.6:
                            return 1
                        else:
                            return 0
                else:
                    if table['unique_peak_conservative_fragsites_p2'] < 4.5:
                        if table['spectrum_quality_score'] < 0.48:
                            return 1
                        else:
                            if table['fragment_error_ppm_mean_square_root'] < 4.3:
                                return 0
                            else:
                                return 1
                    else:
                        if table['alpha_delta_score'] < 37:
                            if table['spectrum_quality_score'] < 0.45:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
            else:
                if table['spectrum_quality_score'] < 0.4:
                    if table['total_peak_coverage'] < 0.22:
                        if table['unique_peak_loss_coverage_pp'] < 0.4:
                            if table['unique_peak_conservative_coverage_pp'] < 0.43:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                    else:
                        if table['fragment_error_ppm_mean_square'] < 52.95:
                            if table['unique_peak_conservative_fragsites_p1'] < 13.5:
                                return 0
                            else:
                                return 1
                        else:
                            return 0
                else:
                    if table['all_fragsites_p2'] < 4.5:
                        if table['alpha_beta_delta_score'] < 9.82:
                            return 1
                        else:
                            return 0
                    else:
                        return 0

    @staticmethod
    def _rand_tree8(table):
        if table['top100_peak_coverage'] < 0.23:
            if table['primary_fragments_pp'] < 15.5:
                if table['primary_fragsites_pp'] < 10.5:
                    if table['precursor_mz'] < 684.09:
                        return 1
                    else:
                        if table['precursor_mass'] < 2782.47:
                            return 1
                        else:
                            if table['precursor_mass'] < 2793.61:
                                return 0
                            else:
                                return 1
                else:
                    if table['conservative_coverage_p2'] < 0.4:
                        if table['sequence_tag_coverage_p2'] < 0.22:
                            return 1
                        else:
                            if table['beta_score'] < 49.62:
                                return 1
                            else:
                                return 0
                    else:
                        if table['alpha_beta_delta_score'] < 5:
                            return 1
                        else:
                            if table['isotope_intensity_matched_fraction'] < 0.43:
                                return 1
                            else:
                                return 0
            else:
                if table['unique_peak_primary_coverage_pp'] < 0.44:
                    if table['all_fragsites_p2'] < 11.5:
                        if table['precursor_error_1-normalized'] < 0.99:
                            return 1
                        else:
                            return 0
                    else:
                        if table['precursor_error_1-normalized'] < 0.88:
                            return 1
                        else:
                            return 0
                else:
                    if table['unique_peak_primary_fragsites_p2'] < 4.5:
                        if table['conservative_coverage_p2'] < 0.39:
                            if table['single_peak_coverage'] < 0.39:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                    else:
                        if table['conservative_intensity_coverage'] < 0.4:
                            if table['precursor_error_1-normalized'] < 0.82:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
        else:
            if table['unique_peak_primary_coverage_p2'] < 0.26:
                if table['p2_score'] < 0.23:
                    if table['primary_fragments_pp'] < 18.5:
                        return 1
                    else:
                        if table['unique_peak_loss_coverage_p1'] < 0.05:
                            if table['beta_score'] < 43.94:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                else:
                    if table['beta_score'] < 49.15:
                        return 1
                    else:
                        return 0
            else:
                if table['primary_intensity_coverage'] < 0.34:
                    if table['conservative_fragsites_pp'] < 12.5:
                        if table['primary_fragsites_p2'] < 4.5:
                            return 1
                        else:
                            if table['precursor_mass'] < 2166.13:
                                return 0
                            else:
                                return 1
                    else:
                        if table['alpha_delta_score'] < 27.75:
                            if table['all_fragsites_p2'] < 4.5:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                else:
                    if table['alpha_beta_delta_score'] < 7.98:
                        if table['primary_fragsites_pp'] < 19.5:
                            if table['loss_fragsites_p2'] < 3.5:
                                return 1
                            else:
                                return 0
                        else:
                            if table['conservative_fragsites_p2'] < 4.5:
                                return 1
                            else:
                                return 0
                    else:
                        return 0

    @staticmethod
    def _rand_tree9(table):
        if table['primary_fragments_pp'] < 15.5:
            if table['conservative_coverage_p2'] < 0.39:
                if table['precursor_mass'] < 2390.24:
                    if table['alpha_beta_delta_score'] < 8.51:
                        if table['precursor_mass'] < 1901.89:
                            return 1
                        else:
                            if table['precursor_mass'] < 1902.01:
                                return 0
                            else:
                                return 1
                    else:
                        if table['total_peak_coverage'] < 0.21:
                            return 1
                        else:
                            if table['unique_peak_conservative_fragsites_p2'] < 2.5:
                                return 1
                            else:
                                return 0
                else:
                    if table['primary_coverage_pp'] < 0.37:
                        return 1
                    else:
                        if table['precursor_mass'] < 3168.68:
                            return 1
                        else:
                            return 0
            else:
                if table['primary_fragments_pp'] < 12.5:
                    if table['single_peak_coverage'] < 0.36:
                        if table['precursor_charge'] < 3.5:
                            if table['sequence_tag_coverage_p1'] < 0.47:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                    else:
                        if table['conservative_coverage_p1'] < 0.41:
                            return 1
                        else:
                            if table['fragment_library_score'] < 1:
                                return 1
                            else:
                                return 0
                else:
                    if table['alpha_beta_delta_score'] < 5.97:
                        return 1
                    else:
                        if table['total_peak_coverage'] < 0.22:
                            if table['unique_peak_fragsites_p1'] < 7.5:
                                return 0
                            else:
                                return 1
                        else:
                            return 0
        else:
            if table['unique_peak_conservative_fragsites_p2'] < 4.5:
                if table['all_fragsites_p2'] < 3.5:
                    if table['beta_score'] < 31.41:
                        if table['precursor_charge'] < 5.5:
                            return 1
                        else:
                            if table['precursor_mass'] < 2752.44:
                                return 0
                            else:
                                return 1
                    else:
                        return 1
                else:
                    if table['conservative_intensity_coverage'] < 0.42:
                        if table['unique_peak_conservative_fragsites_p2'] < 0.5:
                            if table['beta_score'] < 28.09:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                    else:
                        if table['alpha_beta_delta_score'] < 7.14:
                            return 1
                        else:
                            if table['conservative_coverage_p2'] < 0.28:
                                return 1
                            else:
                                return 0
            else:
                if table['conservative_coverage_p2'] < 0.27:
                    if table['alpha_beta_delta_score'] < -0.02:
                        if table['sequence_tag_coverage_p2'] < 0.19:
                            return 1
                        else:
                            return 0
                    else:
                        return 0
                else:
                    return 0

    @staticmethod
    def _rand_tree10(table):
        if table['unique_peak_primary_fragsites_pp'] < 13.5:
            if table['sequence_tag_coverage_pp'] < 0.34:
                if table['precursor_mass'] < 2458.24:
                    if table['unique_peak_conservative_fragsites_pp'] < 9.5:
                        if table['all_fragsites_p2'] < 5.5:
                            return 1
                        else:
                            if table['conservative_intensity_coverage'] < 0.51:
                                return 1
                            else:
                                return 0
                    else:
                        if table['unique_peak_conservative_fragsites_p2'] < 3.5:
                            return 1
                        else:
                            if table['unique_peak_loss_fragsites_pp'] < 13.5:
                                return 1
                            else:
                                return 0
                else:
                    if table['unique_peak_primary_fragsites_p2'] < 6.5:
                        return 1
                    else:
                        if table['single_peak_coverage'] < 0.38:
                            if table['conservative_coverage_pp'] < 0.36:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
            else:
                if table['primary_coverage_p2'] < 0.34:
                    if table['precursor_mass'] < 2791:
                        return 1
                    else:
                        return 0
                else:
                    if table['loss_fragsites_p2'] < 3.5:
                        if table['precursor_charge'] < 4.5:
                            return 1
                        else:
                            return 0
                    else:
                        return 0
        else:
            if table['conservative_fragsites_p2'] < 4.5:
                if table['unique_peak_primary_coverage_p2'] < 0.27:
                    if table['alpha_delta_score'] < 26.14:
                        if table['beta_score'] < 40.58:
                            if table['primary_intensity_coverage'] < 0.67:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        if table['conservative_fragsites_p1'] < 15.5:
                            if table['sequence_tag_coverage_p2'] < 0.21:
                                return 1
                            else:
                                return 0
                        else:
                            if table['top40_peak_coverage'] < 0.24:
                                return 1
                            else:
                                return 0
                else:
                    if table['primary_fragsites_p2'] < 3.5:
                        return 1
                    else:
                        if table['primary_coverage_p2'] < 0.45:
                            if table['alpha_beta_delta_score'] < 7.76:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
            else:
                if table['alpha_delta_score'] < 29.93:
                    if table['unique_peak_conservative_coverage_pp'] < 0.37:
                        if table['precursor_error_1-normalized'] < 0.86:
                            return 1
                        else:
                            if table['sequence_tag_coverage_p2'] < 0.22:
                                return 1
                            else:
                                return 0
                    else:
                        if table['beta_score'] < 19.76:
                            if table['primary_coverage_pp'] < 0.47:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                else:
                    if table['unique_peak_primary_coverage_p2'] < 0.18:
                        if table['primary_fragsites_pp'] < 21:
                            if table['precursor_mz'] < 1037.68:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        return 0

    @staticmethod
    def _rep_tree1(table):
        if table['sequence_tag_coverage_p2'] < 0.09:
            if table['precursor_mass'] < 2269.16:
                if table['precursor_mass'] < 1974.06:
                    if table['aa_len_p1'] <= 5:
                        return 1
                    else:
                        if table['primary_fragsites_p2'] < 4.5:
                            return 1
                        else:
                            if table['spectrum_quality_score'] < 0.51:
                                return 1
                            else:
                                return 0
                else:
                    if table['sequence_tag_coverage_p1'] < 0.6:
                        return 1
                    else:
                        if table['primary_fragsites_p2'] < 3.5:
                            return 1
                        else:
                            if table['alpha_beta_delta_score'] < 4.8:
                                return 1
                            else:
                                return 0
            else:
                if table['precursor_mass'] < 2793.51:
                    return 1
                else:
                    if table['precursor_mass'] < 2793.6:
                        return 0
                    else:
                        return 1
        else:
            if table['spectrum_quality_score'] < 0.41:
                if table['sequence_tag_coverage_pp'] < 0.3:
                    if table['precursor_mass'] < 2360.73:
                        return 1
                    else:
                        if table['alpha_beta_delta_score'] < 23.58:
                            if table['primary_fragsites_p2'] < 9.5:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                else:
                    if table['primary_fragsites_p2'] < 4.5:
                        return 1
                    else:
                        if table['precursor_error_1-normalized'] < 0.85:
                            return 1
                        else:
                            if table['alpha_beta_sum'] < 62.82:
                                return 1
                            else:
                                return 0
            else:
                if table['primary_fragsites_p2'] < 4.5:
                    if table['precursor_error_1-normalized'] < 0.85:
                        return 1
                    else:
                        if table['alpha_beta_delta_score'] < 7.05:
                            return 1
                        else:
                            return 0
                else:
                    if table['alpha_beta_delta_score'] < 0.68:
                        if table['precursor_error_1-normalized'] < 0.78:
                            if table['alpha_delta_score'] < 41.08:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        return 0

    @staticmethod
    def _rep_tree2(table):
        if table['sequence_tag_coverage_p2'] < 0.11:
            if table['precursor_mass'] < 2362.17:
                if table['precursor_mass'] < 1898.09:
                    return 1
                else:
                    if table['conservative_fragsites_pp'] < 13.5:
                        if table['beta_score'] < 41.26:
                            return 1
                        else:
                            return 0
                    else:
                        if table['conservative_fragsites_p2'] < 4.5:
                            return 1
                        else:
                            return 0
            else:
                if table['precursor_mass'] < 2793.51:
                    if table['precursor_mass'] < 2362.64:
                        return 0
                    else:
                        return 1
                else:
                    if table['precursor_mass'] < 2793.6:
                        return 0
                    else:
                        if table['primary_fragments_pp'] < 19.5:
                            return 1
                        else:
                            if table['alpha_delta_score'] < 31.36:
                                return 1
                            else:
                                return 0
        else:
            if table['primary_fragments_pp'] < 15.5:
                if table['primary_coverage_pp'] < 0.42:
                    if table['beta_score'] < 54.66:
                        if table['precursor_mass'] < 2743.94:
                            if table['single_peak_coverage'] < 0.41:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                    else:
                        return 0
                else:
                    if table['top100_peak_coverage'] < 0.21:
                        if table['unique_peak_fragsites_p2'] < 6.5:
                            return 1
                        else:
                            if table['alpha_beta_delta_score'] < 3.57:
                                return 1
                            else:
                                return 0
                    else:
                        if table['alpha_beta_delta_score'] < 5.87:
                            if table['sequence_tag_coverage_p2'] < 0.39:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
            else:
                if table['precursor_error_normalized'] < 0.24:
                    if table['conservative_fragsites_p2'] < 5.5:
                        if table['alpha_beta_delta_score'] < 6.96:
                            if table['top100_peak_coverage'] < 0.29:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        return 0
                else:
                    if table['beta_score'] < 36.99:
                        if table['alpha_beta_delta_score'] < 0.5:
                            return 1
                        else:
                            if table['primary_coverage_pp'] < 0.47:
                                return 1
                            else:
                                return 0
                    else:
                        return 0

    @staticmethod
    def _rep_tree3(table):
        if table['unique_peak_conservative_fragsites_p2'] < 4.5:
            if table['aa_len_p2'] < 5.5:
                return 1
            else:
                if table['sequence_tag_coverage_p2'] < 0.3:
                    if table['precursor_mass'] < 2384.2:
                        if table['primary_coverage_pp'] < 0.47:
                            return 1
                        else:
                            if table['top100_peak_coverage'] < 0.24:
                                return 1
                            else:
                                return 0
                    else:
                        if table['precursor_mass'] < 4766.05:
                            return 1
                        else:
                            return 1
                else:
                    if table['intensity_coverage'] < 0.27:
                        if table['aa_len_p2'] < 7.5:
                            return 1
                        else:
                            return 0
                    else:
                        if table['precursor_error_1-normalized'] < 0.7:
                            return 1
                        else:
                            return 0
        else:
            if table['intensity_coverage'] < 0.38:
                if table['primary_coverage_pp'] < 0.43:
                    if table['beta_score'] < 48.27:
                        if table['alpha_beta_delta_score'] < 20.59:
                            if table['aa_len_p2'] < 13.5:
                                return 1
                            else:
                                return 1
                        else:
                            if table['alpha_beta_score'] < 155.01:
                                return 1
                            else:
                                return 0
                    else:
                        return 0
                else:
                    if table['precursor_error_1-normalized'] < 0.76:
                        if table['alpha_beta_delta_score'] < 18.4:
                            return 1
                        else:
                            return 0
                    else:
                        if table['single_peak_coverage'] < 0.18:
                            if table['beta_score'] < 27.44:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
            else:
                if table['sequence_tag_coverage_p2'] < 0.11:
                    if table['precursor_error_1-normalized'] < 0.78:
                        return 1
                    else:
                        if table['alpha_beta_delta_score'] < 4.51:
                            if table['beta_score'] < 50.44:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                else:
                    if table['precursor_error_1-normalized'] < 0.72:
                        if table['alpha_beta_delta_score'] < -0.19:
                            return 1
                        else:
                            return 0
                    else:
                        return 0

    @staticmethod
    def _rep_tree4(table):
        if table['unique_peak_conservative_fragsites_p2'] < 4.5:
            if table['precursor_mass'] < 2381.32:
                if table['sequence_tag_coverage_pp'] < 0.36:
                    return 1
                else:
                    if table['primary_fragsites_p2'] < 3.5:
                        return 1
                    else:
                        if table['isotope_intensity_matched_fraction'] < 0.41:
                            return 1
                        else:
                            if table['unique_peak_conservative_coverage_p2'] < 0.45:
                                return 0
                            else:
                                return 1
            else:
                if table['primary_fragsites_p2'] < 4.5:
                    if table['precursor_mass'] < 2793.51:
                        return 1
                    else:
                        if table['precursor_mass'] < 2793.6:
                            return 0
                        else:
                            if table['aa_len_p1'] < 11.5:
                                return 1
                            else:
                                return 1
                else:
                    if table['sequence_tag_coverage_pp'] < 0.3:
                        if table['all_coverage_pp'] < 0.56:
                            if table['primary_fragsites_p2'] < 9:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        if table['precursor_error_1-normalized'] < 0.76:
                            return 1
                        else:
                            return 0
        else:
            if table['sequence_tag_coverage_pp'] < 0.2:
                if table['top100_peak_coverage'] < 0.3:
                    if table['aa_len_p1'] < 9.5:
                        return 1
                    else:
                        if table['alpha_beta_sum'] < 114.73:
                            return 1
                        else:
                            if table['unique_peak_conservative_coverage_p2'] < 0.32:
                                return 1
                            else:
                                return 0
                else:
                    if table['precursor_error_1-normalized'] < 0.83:
                        return 1
                    else:
                        return 0
            else:
                if table['precursor_error_1-normalized'] < 0.73:
                    if table['primary_intensity_coverage'] < 0.39:
                        if table['unique_peak_conservative_fragsites_p2'] < 7.5:
                            return 1
                        else:
                            return 0
                    else:
                        return 0
                else:
                    if table['p2_score'] < 0.34:
                        if table['top100_peak_coverage'] < 0.27:
                            if table['alpha_beta_sum'] < 115.82:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        return 0

    @staticmethod
    def _rep_tree5(table):
        if table['sequence_tag_coverage_p2'] < 0.11:
            if table['precursor_mz'] < 601.34:
                if table['precursor_mz'] < 394.02:
                    return 1
                else:
                    if table['conservative_fragsites_p2'] < 4.5:
                        return 1
                    else:
                        if table['sequence_tag_coverage_pp'] < 0.2:
                            return 1
                        else:
                            if table['beta_score'] < 27.04:
                                return 1
                            else:
                                return 0
            else:
                if table['beta_score'] < 47.92:
                    if table['precursor_mz'] < 699.39:
                        return 1
                    else:
                        if table['precursor_mz'] < 699.41:
                            return 0
                        else:
                            return 1
                else:
                    if table['conservative_fragsites_p2'] < 5.5:
                        if table['unique_peak_loss_coverage_p2'] < 0.21:
                            return 1
                        else:
                            return 0
                    else:
                        return 0
        else:
            if table['spectrum_quality_score'] < 0.43:
                if table['alpha_beta_score'] < 115.88:
                    if table['sequence_tag_coverage_pp'] < 0.34:
                        return 1
                    else:
                        if table['beta_score'] < 18.4:
                            return 1
                        else:
                            return 0
                else:
                    if table['beta_score'] < 29.87:
                        if table['unique_peak_primary_coverage_pp'] < 0.44:
                            return 1
                        else:
                            return 0
                    else:
                        if table['alpha_beta_delta_score'] < 9.78:
                            if table['primary_intensity_coverage'] < 0.17:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
            else:
                if table['primary_fragsites_p2'] < 4.5:
                    if table['alpha_beta_delta_score'] < 7.97:
                        if table['primary_fragsites_p2'] < 3.5:
                            return 1
                        else:
                            if table['top100_peak_coverage'] < 0.28:
                                return 1
                            else:
                                return 0
                    else:
                        return 0
                else:
                    return 0

    @staticmethod
    def _rep_tree6(table):
        if table['primary_fragsites_p2'] < 4.5:
            if table['aa_len_p1'] < 11.5:
                if table['aa_len_p1'] < 7.5:
                    return 1
                else:
                    if table['precursor_charge'] < 3.5:
                        return 1
                    else:
                        if table['precursor_mz'] < 689.1:
                            return 1
                        else:
                            if table['precursor_mz'] < 699.65:
                                return 0
                            else:
                                return 1
            else:
                return 1
        else:
            if table['primary_intensity_coverage'] < 0.3:
                if table['unique_peak_primary_coverage_pp'] < 0.41:
                    if table['primary_fragsites_p2'] < 9.5:
                        return 1
                    else:
                        return 0
                else:
                    if table['precursor_error_ppm_abs'] < 1.88:
                        if table['fragment_library_score_exponential'] < 0.98:
                            return 1
                        else:
                            return 0
                    else:
                        if table['primary_fragsites_p2'] < 8.5:
                            return 1
                        else:
                            return 0
            else:
                if table['precursor_error_ppm_abs'] < 1.08:
                    if table['conservative_coverage_p2'] < 0.23:
                        if table['primary_intensity_coverage'] < 0.5:
                            if table['precursor_error_ppm'] < 0.5:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        return 0
                else:
                    if table['alpha_beta_rank'] < 1.5:
                        if table['all_coverage_p2'] < 0.42:
                            if table['alpha_beta_score'] < 146.38:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        if table['unique_peak_loss_coverage_pp'] < 0.29:
                            return 1
                        else:
                            if table['primary_fragsites_p2'] < 6.5:
                                return 1
                            else:
                                return 0

    @staticmethod
    def _rep_tree7(table):
        if table['sequence_tag_coverage_p2'] < 0.11:
            if table['aa_len_p2'] < 6.5:
                if table['aa_len_p2'] < 5.5:
                    return 1
                else:
                    if table['conservative_fragsites_p2'] < 4.5:
                        return 1
                    else:
                        if table['alpha_beta_delta_score'] < 4.36:
                            if table['top100_peak_coverage'] < 0.28:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
            else:
                if table['precursor_charge'] < 3.5:
                    return 1
                else:
                    if table['precursor_mz'] < 580.76:
                        return 1
                    else:
                        if table['aa_len_p2'] < 14.5:
                            return 1
                        else:
                            if table['loss_fragsites_pp'] < 22:
                                return 1
                            else:
                                return 0
        else:
            if table['conservative_intensity_coverage'] < 0.32:
                if table['unique_peak_conservative_coverage_pp'] < 0.42:
                    if table['alpha_beta_delta_score'] < 23.35:
                        if table['loss_fragsites_p2'] < 10.5:
                            return 1
                        else:
                            return 0
                    else:
                        if table['primary_fragsites_pp'] < 10.5:
                            return 1
                        else:
                            return 0
                else:
                    if table['all_fragsites_p2'] < 5.5:
                        if table['alpha_beta_delta_score'] < 13.88:
                            return 1
                        else:
                            return 0
                    else:
                        return 0
            else:
                if table['unique_peak_conservative_fragsites_p2'] < 4.5:
                    if table['alpha_beta_delta_score'] < 8.23:
                        if table['aa_len_p2'] < 5.5:
                            return 1
                        else:
                            if table['sequence_tag_coverage_p2'] < 0.32:
                                return 1
                            else:
                                return 0
                    else:
                        if table['unique_peak_primary_coverage_pp'] < 0.36:
                            return 1
                        else:
                            return 0
                else:
                    if table['alpha_beta_rank'] < 0.5:
                        if table['fragment_library_score_log'] < 15.99:
                            if table['top100_peak_coverage'] < 0.21:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        return 0

    @staticmethod
    def _rep_tree8(table):
        if table['sequence_tag_coverage_p2'] < 0.09:
            if table['precursor_mass'] < 2269.16:
                if table['precursor_mass'] < 1611.36:
                    return 1
                else:
                    if table['conservative_intensity_coverage'] < 0.48:
                        return 1
                    else:
                        if table['unique_peak_primary_fragsites_p2'] < 4.5:
                            return 1
                        else:
                            return 0
            else:
                if table['precursor_mass'] < 2793.51:
                    return 1
                else:
                    if table['precursor_mass'] < 2793.61:
                        return 0
                    else:
                        return 1
        else:
            if table['conservative_intensity_coverage'] < 0.32:
                if table['conservative_intensity_coverage'] < 0.25:
                    return 1
                else:
                    if table['unique_peak_primary_fragsites_p2'] < 6.5:
                        if table['sequence_tag_coverage_pp'] < 0.3:
                            return 1
                        else:
                            if table['all_fragsites_p2'] < 5.5:
                                return 1
                            else:
                                return 0
                    else:
                        if table['precursor_error_1-normalized'] < 0.84:
                            if table['top100_peak_coverage'] < 0.18:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
            else:
                if table['unique_peak_primary_fragsites_p2'] < 4.5:
                    if table['precursor_error_1-normalized'] < 0.82:
                        if table['fragment_library_score_log'] < 58.46:
                            return 1
                        else:
                            if table['all_coverage_p1'] < 0.52:
                                return 1
                            else:
                                return 0
                    else:
                        if table['top100_peak_coverage'] < 0.3:
                            return 1
                        else:
                            return 0
                else:
                    if table['precursor_error_1-normalized'] < 0.74:
                        if table['sequence_tag_coverage_p2'] < 0.34:
                            if table['alpha_delta_score'] < 23.87:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        return 0

    @staticmethod
    def _rep_tree9(table):
        if table['unique_peak_conservative_fragsites_p2'] < 4.5:
            if table['precursor_mass'] < 2283.27:
                if table['spectrum_quality_score'] < 0.45:
                    return 1
                else:
                    if table['conservative_fragsites_p2'] < 3.5:
                        if table['isotope_intensity_matched_fraction'] < 0.38:
                            return 0
                        else:
                            return 1
                    else:
                        if table['precursor_error_1-normalized'] < 0.73:
                            return 1
                        else:
                            return 0
            else:
                if table['conservative_fragsites_pp'] < 16.5:
                    if table['precursor_mass'] < 2793.51:
                        if table['precursor_mz'] < 509.38:
                            if table['precursor_mz'] < 508.87:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                    else:
                        if table['precursor_mass'] < 2793.6:
                            return 0
                        else:
                            return 1
                else:
                    if table['conservative_fragsites_p2'] < 3.5:
                        if table['aa_len_p1'] < 19.5:
                            if table['aa_len_p1'] < 11.5:
                                return 0
                            else:
                                return 1
                        else:
                            return 1
                    else:
                        if table['precursor_error_1-normalized'] < 0.73:
                            return 1
                        else:
                            if table['p2_score'] < 0.31:
                                return 1
                            else:
                                return 0
        else:
            if table['spectrum_quality_score'] < 0.42:
                if table['unique_peak_conservative_coverage_pp'] < 0.41:
                    if table['conservative_fragsites_p2'] < 9.5:
                        return 1
                    else:
                        return 0
                else:
                    if table['precursor_error_1-normalized'] < 0.71:
                        return 1
                    else:
                        return 0
            else:
                if table['unique_peak_primary_coverage_p2'] < 0.26:
                    if table['total_peak_coverage'] < 0.45:
                        if table['precursor_error_ppm_abs'] < 1.37:
                            return 0
                        else:
                            return 1
                    else:
                        return 0
                else:
                    if table['precursor_error_ppm_abs'] < 1.68:
                        return 0
                    else:
                        if table['spectrum_quality_score'] < 0.49:
                            if table['unique_peak_conservative_fragsites_p2'] < 7.5:
                                return 1
                            else:
                                return 0
                        else:
                            return 0

    @staticmethod
    def _rep_tree10(table):
        if table['sequence_tag_coverage_p2'] < 0.09:
            if table['aa_len_p2'] < 6.5:
                return 1
            else:
                if table['aa_len_p1'] < 8.5:
                    return 1
                else:
                    if table['aa_len_p1'] < 14.5:
                        if table['precursor_mz'] < 702.36:
                            if table['precursor_mz'] < 699.37:
                                return 1
                            else:
                                return 0
                        else:
                            return 1
                    else:
                        return 1
        else:
            if table['spectrum_quality_score'] < 0.43:
                if table['primary_fragments_pp'] < 14.5:
                    return 1
                else:
                    if table['precursor_error_normalized'] < 0.17:
                        if table['alpha_beta_delta_score'] < 6.56:
                            if table['sequence_tag_coverage_p1'] < 0.27:
                                return 1
                            else:
                                return 0
                        else:
                            return 0
                    else:
                        if table['alpha_beta_delta_score'] < 22.37:
                            return 1
                        else:
                            return 0
            else:
                if table['primary_fragsites_p2'] < 4.5:
                    if table['precursor_error_normalized'] < 0.21:
                        if table['aa_len_p2'] < 5.5:
                            return 1
                        else:
                            return 0
                    else:
                        return 1
                else:
                    if table['precursor_error_normalized'] < 0.31:
                        return 0
                    else:
                        if table['alpha_beta_delta_score'] < -0.19:
                            return 1
                        else:
                            return 0
