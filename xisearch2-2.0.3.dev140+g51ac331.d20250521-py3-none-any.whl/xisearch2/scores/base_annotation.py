"""Module containing the base class for all annotation related scores."""
import abc


class BaseAnnotationScore(abc.ABC):
    """Base class for all annotation related scores."""

    def calculate(self, table, all_annotations, **kwargs):
        """
        Calculate and writes a annotation based score.

        Calls calculate_single once per candidate annotation (row).
        :param table: (ndarray) score table
        :param all_annotations: (list) list of all alpha_beta fragment annotations
        """
        for index, entry in enumerate(table):
            annotations = all_annotations[entry['alpha_beta_index']]
            self.calculate_single(index, table, annotations, **kwargs)

    @abc.abstractmethod
    def calculate_single(self, index, table, annotations, spectrum):
        """Calculate and write the score for a single annotation at index."""
        pass
