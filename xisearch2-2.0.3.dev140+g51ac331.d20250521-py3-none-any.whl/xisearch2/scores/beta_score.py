"""Module containing the score for the beta peptide."""
import numpy as np


class BetaScore:
    """Score the beta peptide by looking up the beta peptide sequence in the alpha score list."""

    dtype = [('beta_score', np.float32)]

    def __init__(self, context):
        """
        Initialise the BetaScore.

        :param context: (Searcher) Search context
        """
        self.database = context.peptide_db

    def calculate(self, table, beta_pep_indices, all_alphas, **_):
        """
        Calculate and write the score for the beta peptide by looking up the alpha score for it.

        :param table: (ndarray) score table
        :param beta_pep_indices: (ndarray) indices of the beta peptides into the peptide DB
        :param all_alphas: (ndarray) table of all alpha peptides and their scores
        """
        alpha_indices = np.searchsorted(all_alphas['peptide_index'], beta_pep_indices)
        found = np.nonzero(alpha_indices - len(all_alphas))[0]
        found_alphas = all_alphas[alpha_indices[found]]
        valid_mask = (found_alphas['peptide_index'] == beta_pep_indices[found])
        table['beta_score'][found[valid_mask]] = found_alphas['peptide_score'][valid_mask]
