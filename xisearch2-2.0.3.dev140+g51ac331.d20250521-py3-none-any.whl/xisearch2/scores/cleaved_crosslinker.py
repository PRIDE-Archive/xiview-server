import numpy as np
from .base_annotation import BaseAnnotationScore


class CleavedCrosslinkerPeptideFragmentScore(BaseAnnotationScore):
    """
    Calculate the scores related to cleaved crosslinker peptide fragments.

    cc_pep_frag: is there at least 1 cc peptide stub fragment
    cc_pep_frag_min_error_ppm: smallest cc peptide stub fragment ppm error
    cc_pep_frag_count: # of cc peptide stub fragments
    # cc_pep_frag_int
    """

    base_scores = [
        ('cc_pep_frag', bool),
        ('cc_pep_frag_min_error_ppm', np.float32),
        ('cc_pep_frag_count', np.uint16),
        # ('cc_pep_frag_int', np.float32)   # not used in xi1 atm
    ]

    dtype = [(f'{s}_p{pep}', d) for s, d in base_scores for pep in [1, 2, 'p']]

    def __init__(self, _):
        """Initialise the score."""

    def calculate_single(self, index, table, annotations, **_):
        """
        Calculate and write the scores.

        :param index: (int) index into the score table to write
        :param table: (ndarray) score table
        :param annotations: (ndarray) Structured numpy array with fragment annotations
        """
        for pep in [1, 2, 'p']:
            scores = self.score_cc_pep_fragments(annotations, pep)
            for score in scores.dtype.names:
                table[score][index] = scores[score]

    def score_cc_pep_fragments(self, annotations, pep_id):
        """
        Calculate the cc pep fragment scores.

        :param annotations: (ndarray) Structured numpy array with fragment annotations
        :param pep_id: (mixed) either the peptide id or 'p' for the pair
        :return: (ndarray) cc pep fragment scores
        """
        # create return table
        score_table = np.empty(1, self.base_scores)

        if pep_id == 'p':
            pep_mask = np.repeat(True, annotations.size)
        else:
            pep_mask = (annotations['pep_id'] == pep_id)

        cc_pep_annotations = annotations[pep_mask
                                         & (annotations['ion_type'] == b'P')
                                         & (annotations['stub'] != b'')
                                         & (annotations['nlosses'] == 0)]

        score_table['cc_pep_frag'] = True if cc_pep_annotations.size > 0 else False

        if cc_pep_annotations.size > 0:
            score_table['cc_pep_frag_min_error_ppm'] = cc_pep_annotations['rel_error'].min()
        else:
            score_table['cc_pep_frag_min_error_ppm'] = np.nan

        score_table['cc_pep_frag_count'] = cc_pep_annotations.size

        # append peptide id to score names
        score_table.dtype.names = [f'{name}_p{pep_id}' for name in score_table.dtype.names]

        return score_table
