import numpy as np


class CombinedScores:
    """
    Preliminary combination of subscores.

    p1/2_score: weighted combination of sub-scores pertaining to peptide1/2
    spectrum_quality_score: weighted combination of sub-scores pertaining to the spectrum
    """

    dtype = [
        ('p1_score', np.float64),
        ('p2_score', np.float64),
        ('spectrum_quality_score', np.float64)
    ]

    # subscore (name,  weight)
    pep_subscores = [
        ('conservative_coverage', 2),
        ('all_coverage', 2),
        ('loss_coverage', 0.5),
        ('primary_coverage', 2)
    ]

    spec_quality_subscores = [
        ('conservative_intensity_coverage', 2),
        ('isotope_intensity_matched_fraction', 1.5),
        ('single_peak_coverage', 0.5),
        ('isotope_intensity_coverage', 1)
    ]

    def __init__(self, _):
        """Initialise the score."""
        pass

    def calculate(self, table, **_):
        """
        Calculate and write the score results.

        :param table: (ndarray) score table
        """
        # peptide scores
        for p in (1, 2):
            # sum weighted scores
            weighted_sum = sum([table[f'{s}_p{p}'] * w for s, w in self.pep_subscores])
            # divide by sum of weights
            table[f'p{p}_score'] = weighted_sum / sum([w for _, w in self.pep_subscores])

        # spectrum quality score
        weighted_sum = sum([table[s] * w for s, w in self.spec_quality_subscores])
        table['spectrum_quality_score'] = \
            weighted_sum / sum([w for _, w in self.spec_quality_subscores])
