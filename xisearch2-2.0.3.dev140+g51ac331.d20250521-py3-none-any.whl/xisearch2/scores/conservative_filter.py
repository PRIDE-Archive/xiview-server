import numpy as np


def conservative(annotations, n_losses):
    """
    Filter the annotations to `conservative` annotations.

    Conservative annotations are:
    - Primary fragments (fragments that have no neutral losses)
    - Primary supported fragments (neutral loss fragments that are also seen as primary)
    - Multi-loss fragments (neutral loss fragments that are seen with at least n distinct losses)
    :param annotations: (ndarray) Structured numpy array with fragment annotations
    :param n_losses: (int) number of neutral loss fragments needed to fulfill the multi-loss
                           requirement
    :return: (ndarray) conservative annotations array
    """
    # Primary fragments
    primary_mask = annotations['nlosses'] == 0
    primary_frags = annotations[primary_mask]

    # Neutral loss fragments
    loss_frags = annotations[~primary_mask]
    # mask to compare fragments
    frag_compare_mask = ['frag_charge', 'idx', 'pep_id', 'ion_type', 'stub']

    # create mask for primary supported fragments
    primary_support_mask = np.isin(loss_frags[frag_compare_mask], primary_frags[frag_compare_mask])

    # Multi-loss fragments
    #
    # The following np.unique call does two things in one step. The results are:
    #
    # - unique_losses contains all unique frag_compare loss fragments
    #
    # - multi_loss_counts contains, for each entry in unique_losses the number of times it was found
    #
    unique_losses, multi_loss_counts = np.unique(loss_frags[frag_compare_mask], return_counts=True)

    # filter the unique_losses to those that have more than n losses
    ml_compare_frags = unique_losses[multi_loss_counts >= n_losses]

    # create mask for all loss fragments that have more than n losses
    multi_loss_mask = np.isin(loss_frags[frag_compare_mask], ml_compare_frags)

    # create the conservative mask by using primary mask...
    conservative_mask = primary_mask
    # + primary_support or multi-loss fragments on non-primary (neutral-loss)
    conservative_mask[~primary_mask] = primary_support_mask | multi_loss_mask

    return annotations[conservative_mask]
