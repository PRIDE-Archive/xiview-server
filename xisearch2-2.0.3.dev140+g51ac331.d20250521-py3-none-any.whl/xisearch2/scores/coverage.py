import numpy as np


class CoverageScore():
    """Calculate the fragment coverage scores from fragment counts."""

    coverage_score_names = ('all', 'primary', 'loss', 'conservative', 'conservative_multi',
                            'unique_peak', 'unique_peak_primary', 'unique_peak_loss',
                            'unique_peak_conservative', 'sequence_tag')
    dtype = [(f'{s}_coverage_p{p}', np.float32)
             for s in coverage_score_names
             for p in ('1', '2', 'p')]

    def __init__(self, _):
        """Initialise the Score."""
        pass

    def calculate(self, score_table, **_):
        """
        Add the coverage scores to the score table.

        # '_coverage' scores are ratios between matched and possible fragmentation sites
        #     all_coverage
        #     primary_coverage
        #     loss_coverage
        #     conservative_coverage
        #     conservative_multi_coverage
        #     unique_peak_coverage
        #     unique_peak_primary_coverage
        #     unique_peak_loss_coverage
        #     unique_peak_conservative_coverage
        #     sequence_tag_coverage
        :param score_table: (ndarray) score table with fragment occurrence counts
        :return: (ndarray) score table with added fragment coverage scores
        """
        aa_len = {'p1': score_table['aa_len_p1'],
                  'p2': score_table['aa_len_p2'],
                  'pp': score_table['aa_len_p1'] + score_table['aa_len_p2'] - 1}

        # adjust aa lengths of linear matches
        aa_len['pp'][aa_len['p2'] == 0] += 1

        for pep in ['p1', 'p2', 'pp']:
            for score_name in self.coverage_score_names:
                score_table[f'{score_name}_coverage_{pep}'] = frag_coverage(
                    n_frag=score_table[f'{score_name}_fragsites_{pep}'], pep_length=aa_len[pep],
                    termini=2)


def frag_coverage(n_frag, pep_length, termini=1):
    """
    Convert a fragment count into a coverage for a given peptide.

    Inputs can be either single values or numpy arrays.
    :param n_frag: (int) number of fragments
    :param pep_length: (int) amino acid length of the peptide
    :param termini: (int) number of termini to consider for number of possible fragments.
        (e.g. 1 for just n or c terminus or 2 for both).
    :return: (float) coverage
    """
    possible_fragments = (pep_length - 1) * termini

    return n_frag / possible_fragments
