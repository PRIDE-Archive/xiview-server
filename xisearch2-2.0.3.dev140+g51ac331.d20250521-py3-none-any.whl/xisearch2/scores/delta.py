import numpy as np


class DeltaScore():
    """
    Calculate the delta scores.

    Delta scores are score differences to the second highest unique score.
    """

    dtype = [('alpha_delta_score', np.float32), ('alpha_beta_delta_score', np.float32)]

    def __init__(self, _):
        """Initialise the score."""
        pass

    def calculate(self, table, **_):
        """
        Calculate the score.

        :param table: (ndarray) score table
        :return: (ndarray) score table with added delta scores
        """
        table['alpha_delta_score'] = second_best_delta(table['alpha_score'])
        table['alpha_beta_delta_score'] = second_best_delta(table['alpha_beta_score'])


def second_best_delta(scores_arr):
    """
    Calculate the second best delta score.

    For a given array of scores it returns an array with delta values to the second highest unique
    score.
    :param scores_arr: (ndarray) list of scores
    :return: (ndarray) list of delta scores
    """
    unique_arr = np.unique(scores_arr)
    if unique_arr.size < 2:
        return scores_arr

    # do a partial sort to get the second best score
    part_sorted = np.partition(-unique_arr, 1)
    second_best = -part_sorted[1]

    alpha_beta_delta_scores = scores_arr - second_best

    return alpha_beta_delta_scores
