import numpy as np
from .base_annotation import BaseAnnotationScore


class FragmentChargeScore(BaseAnnotationScore):
    """
    Calculate the fragment charge scores.

    frag_max_charge: maximal observed charge of all fragments
    frag_mean_charge: average observed charge of all fragments
    rel_frag_max_charge: frag_max_charge/precursor charge
    rel_frag_mean_charge: frag_mean_charge/precursor charge
    """

    dtype = [
        ('frag_max_charge', np.uint8),
        ('frag_mean_charge', np.float32),
        ('rel_frag_max_charge', np.float32),
        ('rel_frag_mean_charge', np.float32)
    ]

    def __init__(self, _):
        """Initialise the score."""
        pass

    def calculate_single(self, index, table, annotations, spectrum, **_):
        """
        Calculate the score.

        :param index: (int) Index into the score table to write
        :param table: (ndarray) Score table
        :param annotations: (ndarray) Structured numpy array with fragment annotations
        :param spectrum: (Spectrum) spectrum to get the precursor charge from
        """
        precursor_charge = spectrum.precursor['charge']
        if annotations.size > 0:
            frag_max_charge = annotations['frag_charge'].max()
            table['frag_max_charge'][index] = frag_max_charge
            table['rel_frag_max_charge'][index] = frag_max_charge / precursor_charge

            frag_mean_charge = annotations['frag_charge'].mean()
            table['frag_mean_charge'][index] = frag_mean_charge
            table['rel_frag_mean_charge'][index] = frag_mean_charge / precursor_charge
