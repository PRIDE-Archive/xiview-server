import numpy as np
from xisearch2.scores import sequence_tag_count, conservative, unique_peak
from .base_annotation import BaseAnnotationScore


class FragmentOccurrenceCount(BaseAnnotationScore):
    """
    Calculate the fragment occurrence counts.

    fragments scores count the number of fragments matched (all charge states, types):
     total_fragments: Number of all fragment matches
     primary_fragments: Number of primary (non-neutral loss) fragment matches
     loss_fragments: Number of neutral-loss fragment matches

    fragsites scores count the number of fragmentation sites matched (same term, idx, pep_id):
     all_fragsites: Number of all matched fragsites
     primary_fragsites: Number of primary (non-neutral loss) fragsites
     loss_fragsites: Number of neutral loss fragsites
     conservative_fragsites: Number of conservative fragsites (see conservative_filter.py)
     conservative_multi_fragsites: Number of conservative fragsites that are seen in multiple
        charge states
     unique_peak_fragsites: Number of total fragsites after applying the unique peak filter (see
        unique_peak_filter.py)
     unique_peak_primary_fragsites: Number of unique peak primary (non-neutral loss) fragsites
     unique_peak_loss_fragsites: Number of unique peak neutral loss fragsites
     unique_peak_conservative_fragsites: Number of unique peak conservative fragsites
     sequence_tag_fragsites: Number of sequence tag fragsites (consecutive fragsites, see
        sequence_tag_count.py)
     unique_peak_primary_crosslink_fragsites: Number of unique peak primary
     (non-neutral loss) that contain parts of both peptides
     unique_peak_conservative_crosslink_fragsites: Number of unique peak conservative
      fragsites (see conservative_filter.py) that contain parts of both peptides
    """

    score_names = ('total_fragments', 'primary_fragments', 'loss_fragments', 'all_fragsites',
                   'primary_fragsites', 'loss_fragsites', 'conservative_fragsites',
                   'conservative_multi_fragsites', 'unique_peak_fragsites',
                   'unique_peak_primary_fragsites', 'unique_peak_loss_fragsites',
                   'unique_peak_conservative_fragsites', 'sequence_tag_fragsites',
                   'unique_peak_primary_crosslink_fragsites',
                   'unique_peak_conservative_crosslink_fragsites')

    dtype = [(f'{s}_p{p}', np.uint16) for s in score_names for p in [1, 2]]

    def __init__(self, context):
        """
        Initialise the score.

        :param context: (Searcher) search context
        """
        self.config = context.config

    def calculate_single(self, index, table, annotations, **_):
        """
        Calculate and write the counts by summing up the relevant fragments.

        :param index: (int) index into the score table to write
        :param table: (ndarray) score table
        :param annotations: (ndarray) Structured numpy array with fragment annotations
        """
        for pep in [1, 2]:
            scores = self.count_peptide_fragments(annotations, pep)
            for score in scores.dtype.names:
                table[score][index] = scores[score]

    def count_peptide_fragments(self, annotations, pep_id):
        """
        Calculate the counts for a single peptide.

        :param annotations: (ndarray) Structured numpy array with fragment annotations
        :param pep_id: (int) id of the peptide to get counts for
        :return: (ndarray) fragment occurrence counts
        """
        # ToDo: loss_fragsites and unique_peak_loss_fragsites are not really meaningful and could be
        #  left out in the future. Will leave them in for now for comparison to xi1

        table_dtype = [(s, np.uint16) for s in self.score_names]

        # get fragments from single peptide
        pep_annotations = annotations[annotations['pep_id'] == pep_id]

        # Filter out cleavable crosslinker Peptide and Precursor fragments
        pep_seq_frags = pep_annotations[pep_annotations['term'] != b'P']

        # create return table
        score_table = np.empty(1, table_dtype)

        # total_fragments
        score_table['total_fragments'] = pep_seq_frags.size

        # primary_fragments
        primary_mask = pep_seq_frags['nlosses'] == 0
        primary_frags = pep_seq_frags[primary_mask]
        score_table['primary_fragments'] = primary_frags.size

        # loss_fragments
        loss_frags = pep_seq_frags[~primary_mask]
        score_table['loss_fragments'] = loss_frags.size

        # frag sites mask: sites are defined by term and idx (pep_id is already filtered)
        fragsites_mask = ['term', 'idx']

        # fragsites
        fragsites = np.unique(pep_seq_frags[fragsites_mask])
        score_table['all_fragsites'] = fragsites.size

        # primary_fragsites
        primary_fs = np.unique(primary_frags[fragsites_mask])
        score_table['primary_fragsites'] = primary_fs.size

        # loss_fragsites
        loss_fs = np.unique(loss_frags[fragsites_mask])
        score_table['loss_fragsites'] = loss_fs.size

        # conservative_fragsites
        conservative_frags = conservative(pep_seq_frags, self.config.conservative_n_multi_loss)
        conservative_fs, conservative_fs_counts = np.unique(conservative_frags[fragsites_mask],
                                                            return_counts=True)
        score_table['conservative_fragsites'] = conservative_fs.size

        # conservative_multi_fragsites
        c_multi = np.unique(conservative_frags[fragsites_mask + ['frag_charge']])
        _, multi_counts = np.unique(c_multi[fragsites_mask], return_counts=True)
        score_table['conservative_multi_fragsites'] = np.count_nonzero(multi_counts > 1)

        # unique_peak_fragsites
        unique_peak_fragments = unique_peak(pep_seq_frags)
        unique_peak_fragsites = np.unique(unique_peak_fragments[fragsites_mask])
        score_table['unique_peak_fragsites'] = unique_peak_fragsites.size

        # unique_peak_primary_fragsites
        unique_peak_primary_mask = unique_peak_fragments['nlosses'] == 0
        unique_peak_primary_frags = unique_peak_fragments[unique_peak_primary_mask]
        unique_peak_primary_fs = np.unique(unique_peak_primary_frags[fragsites_mask])
        score_table['unique_peak_primary_fragsites'] = unique_peak_primary_fs.size

        # unique_peak_loss_fragsites
        unique_peak_loss_frags = unique_peak_fragments[~unique_peak_primary_mask]
        unique_peak_loss_fs = np.unique(unique_peak_loss_frags[fragsites_mask])
        score_table['unique_peak_loss_fragsites'] = unique_peak_loss_fs.size

        # unique_peak_conservative_fragsites
        unique_peak_conservative_frags = conservative(unique_peak_fragments,
                                                      self.config.conservative_n_multi_loss)
        unique_peak_conservative_fs = np.unique(unique_peak_conservative_frags[fragsites_mask])
        score_table['unique_peak_conservative_fragsites'] = unique_peak_conservative_fs.size

        # what are fragments that contain both peptides
        xl_frag_mask = \
            (unique_peak_fragments['ranges'][:, 0] != (0, 0)).any(axis=1) & \
            (unique_peak_fragments['ranges'][:, 1] != (0, 0)).any(axis=1)
        # unique_peak_primary_crosslink_fragsites
        unique_peak_primary_xl_frags = \
            unique_peak_fragments[unique_peak_primary_mask & xl_frag_mask]
        unique_peak_primary_xl_fs = np.unique(unique_peak_primary_xl_frags[fragsites_mask])
        score_table['unique_peak_primary_crosslink_fragsites'] = unique_peak_primary_xl_fs.size

        # unique_peak_conservative_crosslink_fragsites
        xl_cons_frag_mask = \
            ((unique_peak_conservative_frags['ranges'][:, 0, 0]
              != unique_peak_conservative_frags['ranges'][:, 0, 1])
             & (unique_peak_conservative_frags['ranges'][:, 1, 0]
                != unique_peak_conservative_frags['ranges'][:, 1, 1]))
        unique_peak_conservative_crosslink_frags = unique_peak_conservative_frags[xl_cons_frag_mask]
        unique_peak_conservative_crosslink_fs = \
            np.unique(unique_peak_conservative_crosslink_frags[fragsites_mask])
        score_table['unique_peak_conservative_crosslink_fragsites'] = \
            unique_peak_conservative_crosslink_fs.size

        # sequence_tag_fragsites
        n_seq_tag_count = sequence_tag_count(pep_seq_frags, pep_id, b'n')
        c_seq_tag_count = sequence_tag_count(pep_seq_frags, pep_id, b'c')
        seq_tag_count = n_seq_tag_count + c_seq_tag_count
        score_table['sequence_tag_fragsites'] = seq_tag_count

        # append peptide id to score names
        score_table.dtype.names = [f'{name}_p{pep_id}' for name in score_table.dtype.names]

        return score_table
