import numpy as np
from xisearch2 import const


class FragmentLibraryScore():
    """
    Scores the "full" matched spectrum against the fragment-database.

    It scores the likelihood that all matched peaks are random. Currently losses are ignored.
    Three version of the score are provided:
    - fragment_library_score (1-likelihood) - a simple higher is better conversion
    - fragment_library_score_exponential (np.exp(-1000 * likelihood)) - reasoning is lost in time
        simply for backward compatibility
    - fragment_library_score_log (-np.log(likelihood)) - standard way to turn a p-like value into
        a higher is better - probably the only sensible representation.
    """

    score = "fragment_library_score"
    exp_score = "fragment_library_score_exponential"
    log_score = "fragment_library_score_log"

    score_names = (score, exp_score, log_score)

    dtype = [(f'{s}', np.float64) for s in score_names]

    def __init__(self, context):
        """
        Initialise the score.

        Codes is mostly a copy of the ab-candidate score

        :param context: (Searcher) search context
        """
        self.context = context

        self.cl_cleavage_stubs = [[{'name': s.name.encode('ascii'), 'mass': s.mass}
                                   for s in c.cleavage_stubs]
                                  for c in self.context.config.crosslinker] + [[]]
        self.crosslinker_masses = np.array([xl.mass for xl in self.context.config.crosslinker]
                                           + [np.nan])

    def calculate(self, table, all_annotations, spectrum, **kwargs):
        """
        Calculate the candidate score for alpha-beta candidates.

        Takes all matched fragments and looks up how many fragments re in the
        fragment_db that have (within defined tolerance) the same mass.
        Prior scoring crosslinked fragments get linearised and stub fragments "de-stubbed".
        The actual score is calculated using fragment_db.candidate_scores.

        :param table: (ndarray) score table
        :param all_annotations: (list) list of all alpha_beta fragment annotations
        """
        alpha_indices = table['alpha_index']
        beta_indices = table['beta_index']
        xl_indices = table['crosslinker_index']

        alpha_masses = self.context.peptide_db.peptide_mass(alpha_indices)
        beta_masses = self.context.peptide_db.peptide_mass(beta_indices)

        # calculate linearisation masses - we use the the matched precursor - as that would be
        # the more accurate mass - assuming the candidate is correct
        neutral_precursor_masses = alpha_masses + beta_masses + self.crosslinker_masses[xl_indices]
        linearisation_masses = neutral_precursor_masses + 2 * const.PROTON_MASS

        fragment_mass_arrays = []
        linear_arrays = []

        # get fragment masses and linearities for each candidate
        for i, (annotation, trow, xl_id) in enumerate(zip(all_annotations, table, xl_indices)):
            # ignore losses and precursor
            include_mask = (annotation['nlosses'] == 0) & (annotation['ion_type'] != b'P')
            # get the masses
            masses = (annotation['frag_mz'][include_mask] - const.PROTON_MASS) * annotation[
                'frag_charge'][include_mask] + const.PROTON_MASS

            # modify the masses for stub fragments
            # the fragment db has no stub fragments - so we just reduce the masses for these by
            # the stub mass
            stubs = annotation['stub'][include_mask]
            for s in self.cl_cleavage_stubs[xl_id]:
                masses[stubs == s['name']] -= s['mass']

            # add to global list
            fragment_mass_arrays.append(masses)
            linear_arrays.append(annotation['LN'][include_mask])

        # combine results into linear arrays
        candidate_fragment_counts = np.array([len(a) for a in fragment_mass_arrays])
        candidate_ids = np.repeat(np.arange(len(table)), candidate_fragment_counts)
        fragment_masses = np.concatenate(fragment_mass_arrays)
        linear_mask = np.concatenate(linear_arrays)

        # linearise crosslinker containing fragments
        xl_mask = (xl_indices != -1)
        linearise_mask = xl_mask[candidate_ids] & ~linear_mask
        fragment_masses[linearise_mask] *= -1
        fragment_masses[linearise_mask] += linearisation_masses[candidate_ids[linearise_mask]]

        # Score candidates
        scores = self.context.fragment_db.candidate_scores(
            len(table),
            fragment_masses, candidate_ids,
            self.context.get_ms2_atol(spectrum.source_path),
            self.context.get_ms2_rtol(spectrum.source_path)
        )

        # to protect against producing numbers to small to be representable by float the scores are
        # calculated as -log(score) - but here we also need the non-loged score. So we translate
        # it back
        base_scores = np.exp(-scores)

        # turn the "probability" to be a random match into a "probability" not to be a random
        # match (to make higher = better)
        table[self.score] = 1-base_scores
        # don't ask me for the logic of this...
        table[self.exp_score] = np.exp(-1000 * base_scores)
        # here we directly report the log score from candidate_scores
        table[self.log_score] = scores
