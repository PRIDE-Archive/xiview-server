import numpy as np
from .base_annotation import BaseAnnotationScore
from xisearch2 import const
import warnings


class Ms1MassErrorScore:
    """Calculate the MS1 mass errors."""

    dtype = [
        ('calc_mass', np.float64),  # calculated neutral mass of the matched peptide
        ('calc_mz', np.float64),  # calculated m/z of the matched peptide
        ('precursor_error', np.float64),
        ('precursor_error_ppm', np.float64),
        ('precursor_error_ppm_abs', np.float64),
        ('precursor_error_normalized', np.float64),
        ('precursor_error_1-normalized', np.float64),
    ]

    higher_is_better = [
        False,
        False,
        False,
        False,
        False,
        False,
        True,
    ]

    def __init__(self, context):
        """
        Initialise the score.

        :param context: (Searcher) Search context
        """
        self.context = context
        self.database = context.peptide_db
        self.crosslinker_masses = np.array(
            [xl.mass for xl in self.context.config.crosslinker] + [0])

    def calculate(self, table, spectrum, **_):
        """
        Calculate the precursor mass errors of a match to a spectrum.

        :param spectrum: (Spectrum) Only needed to get the precursor mz value really.
        :param table: (ndarray) Score table. Uses the peptide ids to get the masses.
        :return: (ndarray) Score table with added precursor mass error values.
        """
        # calculate theoretical precursor mass and m/z
        p1_masses = self.database.peptide_mass(table['p1_index'])
        p2_masses = self.database.peptide_mass(table['p2_index'])
        crosslinker_mass = self.crosslinker_masses[table['crosslinker_index']]
        # correct linear masses
        linear_mask = table['p2_index'] == -1
        p2_masses[linear_mask] = 0
        crosslinker_mass[linear_mask] = 0
        precursor_calc_mass = (p1_masses + p2_masses + crosslinker_mass)
        table['calc_mass'] = precursor_calc_mass
        table['calc_mz'] = precursor_calc_mass / spectrum.precursor_charge + const.PROTON_MASS

        max_error = spectrum.precursor_mz * self.context.get_ms1_rtol(spectrum.source_path) + \
            self.context.get_ms1_atol(spectrum.source_path)

        error = table['precursor_mz'] - table['calc_mz']
        error_ppm = error / table['calc_mz'] * 1e6

        error_normalized = np.abs(error) / max_error

        table['precursor_error'] = error
        table['precursor_error_ppm'] = error_ppm
        table['precursor_error_ppm_abs'] = np.abs(error_ppm)
        table['precursor_error_normalized'] = error_normalized
        table['precursor_error_1-normalized'] = 1 - error_normalized


class Ms2MassErrorScore(BaseAnnotationScore):
    """Calculate the MS2 mass errors."""

    dtype = [
        ('fragment_error_ppm_mean', np.float64),
        ('fragment_error_ppm_abs_mean', np.float64),
        ('fragment_error_ppm_abs_lin_p1_mean', np.float64),
        ('fragment_error_ppm_abs_lin_p2_mean', np.float64),
        ('fragment_error_ppm_abs_cl_mean', np.float64),
        ('fragment_error_ppm_mean_square', np.float64),
        ('fragment_error_ppm_mean_square_root', np.float64),
        ('fragment_error_normalized_mean', np.float64),
        ('fragment_error_1-normalized_mean', np.float64)
    ]

    def __init__(self, context):
        """
        Initialise the score.

        :param context: (Searcher) Search context
        """
        self.context = context

    def calculate_single(self, index, table, annotations, spectrum, **_):
        """
        Calculate the fragment mass errors for a given annotations table.

        :param index: (int) Index into the score table to write
        :param table: (ndarray) Score table
        :param annotations: (ndarray) Structured numpy array with fragment annotations
        """
        # create annotation masks
        lin_mask = annotations['LN']
        p1_mask = annotations['pep_id'] == 1
        p2_mask = annotations['pep_id'] == 2

        # calculate max_error based on relative and absolute ms2 tolerances for each match
        max_error = annotations['frag_mz'] * self.context.get_ms2_rtol(spectrum.source_path) + \
            self.context.get_ms2_atol(spectrum.source_path)

        # normalize match errors by max_error
        error_normalized = np.abs(annotations['abs_error']) / max_error

        with warnings.catch_warnings():
            warnings.simplefilter('ignore', category=RuntimeWarning)
            rel_error_mean = annotations['rel_error'].mean()
            abs_error_mean = np.abs(annotations['rel_error']).mean()
            error_normalized_mean = error_normalized.mean()
            error_ppm_mean_square = np.square(annotations['rel_error'] * 1e6).mean()
            error_lin_p1_mean = np.abs(annotations[lin_mask & p1_mask]['rel_error']).mean()
            error_lin_p2_mean = np.abs(annotations[lin_mask & p2_mask]['rel_error']).mean()
            error_cl_mean = np.abs(annotations[~lin_mask]['rel_error']).mean()

        table[index]['fragment_error_ppm_mean'] = rel_error_mean * 1e6
        table[index]['fragment_error_ppm_abs_mean'] = abs_error_mean * 1e6
        table[index]['fragment_error_ppm_abs_lin_p1_mean'] = error_lin_p1_mean * 1e6
        table[index]['fragment_error_ppm_abs_lin_p2_mean'] = error_lin_p2_mean * 1e6
        table[index]['fragment_error_ppm_abs_cl_mean'] = error_cl_mean * 1e6
        table[index]['fragment_error_ppm_mean_square'] = error_ppm_mean_square
        table[index]['fragment_error_ppm_mean_square_root'] = np.sqrt(error_ppm_mean_square)
        table[index]['fragment_error_normalized_mean'] = error_normalized_mean
        table[index]['fragment_error_1-normalized_mean'] = 1 - error_normalized_mean
