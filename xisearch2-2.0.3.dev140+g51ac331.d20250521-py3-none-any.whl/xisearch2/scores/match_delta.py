import numpy as np


class MatchDeltaScore:
    """
    Calculate the delta scores.

    The `delta_mod` score gives the match_score difference with the
    second ranking match.  For example, if we have three matches with
    match_scores [1, 5, 8], the corresponding delta scores will be
    [-4, 0, 3].

    The `delta` score does the same, but in picking the second ranking
    match, peptides that have the same unmodified peptide sequence as
    the top ranking match are ignored.  Eg, if the 3 top ranking
    matches all have the same unmodified peptide sequence, the delta
    would be based on the 4th ranking peptide.

    `delta_combined` gives the average of the `delta` and the
    `match_score`

    Delta scores are score differences to the second highest unique
    score.
    """

    dtype = [('delta', np.float32),
             ('delta_mod', np.float32),
             ('delta_combined', np.float32)]

    def __init__(self, context):
        """Initialise the score."""
        self.context = context

    def calculate(self, table, **_):
        """
        Calculate the score and write it to the score table.

        :param table: (ndarray) score table
        """
        match_scores = table['match_score']
        if table.size == 1:
            table['delta'] = match_scores
            table['delta_mod'] = match_scores
            table['delta_combined'] = match_scores
            return

        top_ranking_mask = (table['top_ranking'] == True)  # noqa: E712

        # secondScore from old Xi
        second_best_match_score = np.max(match_scores[~top_ranking_mask], initial=0)

        seq_indices = self.context.modified_peptides['sequence_index']

        # Using poor mans sets here through sorting the inner arrays
        all_seq_index_sets = np.sort(
            np.vstack([seq_indices[table['p1_index']], seq_indices[table['p2_index']]]).T
        )
        top_ranking_seq_index_sets = all_seq_index_sets[top_ranking_mask]

        # find matching sets
        # np.any checks that a given match matches on or more top ranking
        same_nomod_as_top_rank_mask = np.any(
            # np.all checks that both p1 and p2 match a top ranking one
            np.all(
                all_seq_index_sets == top_ranking_seq_index_sets[:, np.newaxis, :], axis=2
            ), axis=0
        )
        second_best_nomod_match_score = np.max(match_scores[~same_nomod_as_top_rank_mask],
                                               initial=0)

        table['delta'] = table['match_score'] - second_best_nomod_match_score
        table['delta_mod'] = table['match_score'] - second_best_match_score
        table['delta_combined'] = (table['delta'] + table['match_score']) / 2
