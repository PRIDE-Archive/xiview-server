import numpy as np
import os


class MatchScore:
    """
    Combine several subscores into the final match score.

    For this it will normalize each sub score and then do an weighted average over all scores.
    """

    score_name = 'match_score'
    rank_name = 'top_ranking'

    dtype = [(score_name, np.float32), (rank_name, bool)]

    # the final score is multiplied by 7 to scale the score to expectation
    score_factor = 7

    # dictionary of all scores that should be considered
    scores = {}

    linear_scores = []

    def __init__(self, _):
        """Initialise the score."""
        # cross-linked scores
        self.subscore_names = []
        self.weight_sum = 0

        self.linear_subscore_names = []
        self.linear_weight_sum = 0

        self.factors_generated = False

        self.weight = np.array([], dtype=np.float32)
        self.divisor = np.array([], dtype=np.float32)
        self.subtrahend = np.array([], dtype=np.float32)

        self.linear_weight = np.array([], dtype=np.float32)
        self.linear_divisor = np.array([], dtype=np.float32)
        self.linear_subtrahend = np.array([], dtype=np.float32)

        self.score_csv = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                      "XiScore_Normalization_Weight.tsv")

        self.read_from_csv(self.score_csv)

    def read_from_csv(self, path=None, delimiter='\t'):
        if path is None:
            path = self.score_csv

        csvdata = np.genfromtxt(path, delimiter=delimiter, names=True, dtype=None,
                                encoding='UTF-8')
        self.scores = {}
        for row in csvdata:
            if row['xi2Column'] != '':
                self.scores[row['xi2Column']] = [row["Subtrahend"], row["Divisor"], row["Weight"]]

        self.linear_scores = csvdata[csvdata['Linear'] == 1]['xi2Column'].tolist()

    def get_factor_array(self, table):
        """
        Fill the the following variable for combining scores of cross-linked matches
        self.weight
        self.divisor
        self.subtrahend

        and for linear matches:
        self.linear_weight
        self.linear_divisor
        self.linear_subtrahend

        these will only be filled on the first call

        :param table: (ndarray) the table containing all the subscores
        """
        if self.factors_generated:
            return

        # we transfer the information from the self.scores into arrays that fit to the data we
        # actually see in the result table
        subtrahend = []
        divisor = []
        weight = []

        # the same we do but for a subset of scores we assume to have values in a linear case
        linear_subtrahend = []
        linear_divisor = []
        linear_weight = []

        # for each columns in the result table
        for col in table.dtype.names:

            # we check if it should be considered for the 'match_score'
            if col not in self.scores:
                continue

            # yes this score is to be considered
            self.subscore_names.append(col)
            # add the subtrahend
            subtrahend.append(self.scores[col][0])
            # add divisor
            divisor.append(self.scores[col][1])
            # add weight
            weight.append(self.scores[col][2])

            self.weight_sum += self.scores[col][2]

            if (col in self.linear_scores):
                self.linear_subscore_names.append(col)
                # add the subtrahend
                linear_subtrahend.append(self.scores[col][0])
                # add divisor
                linear_divisor.append(self.scores[col][1])
                # add weight
                linear_weight.append(self.scores[col][2])

                self.linear_weight_sum += self.scores[col][2]

        self.weight = np.array(weight)
        self.divisor = np.array(divisor)
        self.subtrahend = np.array(subtrahend)

        self.linear_weight = np.array(linear_weight)
        self.linear_divisor = np.array(linear_divisor)
        self.linear_subtrahend = np.array(linear_subtrahend)

        self.factors_generated = True

    def calculate(self, table, **_):
        """
        Calculate the overall score for spectrum-matches and flags the best scoring match.

        :param table: (ndarray) Score table. Uses the peptide ids to get the masses.
        """
        # get the fitting score_factor table
        self.get_factor_array(table)
        linear_mask = table['linear']

        if np.any(~linear_mask):
            crosslinked_table = table[~linear_mask]

            # convert into a non-structured array
            xldata = np.array(crosslinked_table[self.subscore_names].tolist(), dtype=np.float32)

            # shift
            np.subtract(xldata, self.subtrahend, out=xldata)

            # normalize spread
            np.divide(xldata, self.divisor, out=xldata)

            # apply weight
            np.multiply(xldata, self.weight, out=xldata)

            # weighted average as score
            table[self.score_name][~linear_mask] = np.divide(np.nansum(xldata, axis=1),
                                                             self.weight_sum) * self.score_factor

        if np.any(linear_mask):
            linear_table = table[linear_mask]

            # convert into a non-structured array
            lin_data = np.array(linear_table[self.linear_subscore_names].tolist(), dtype=np.float32)

            # shift
            np.subtract(lin_data, self.linear_subtrahend, out=lin_data)

            # normalize spread
            np.divide(lin_data, self.linear_divisor, out=lin_data)

            # apply weight
            np.multiply(lin_data, self.linear_weight, out=lin_data)

            # weighted average as score
            table[self.score_name][linear_mask] = \
                np.divide(np.nansum(lin_data, axis=1),
                          self.linear_weight_sum) * self.score_factor

        # prioritize auto validated matches
        if table['auto_validation'].any():
            top_mask = table[self.score_name] == np.max(
                table[table['auto_validation']][self.score_name])
        else:
            top_mask = table[self.score_name] == np.max(table[self.score_name])
        # and flag them as top-ranking
        table[self.rank_name][top_mask] = True
        table[self.rank_name][~top_mask] = False
