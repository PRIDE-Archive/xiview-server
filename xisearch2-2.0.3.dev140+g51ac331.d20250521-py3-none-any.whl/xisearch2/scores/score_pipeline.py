import numpy as np
from numpy.lib import recfunctions


class ScorePipeline:
    """Pipeline to calculate the scores. Called once for every spectrum."""

    # score that gets flaged as the main dcore in teh database
    main_score = 'match_score'

    def __init__(self, context, *klasses):
        """
        Initialise the pipeline.

        :param context: (Searcher) Search context
        :param klasses: (Score Classes) Scores that will be run by the pipeline
        """
        # list of scores - most scores go through the score pipeline and will be added from there
        # Initialised with scores that are not generated this way
        # can be used to define what to write into the score-arrays into the database
        self.score_columns = [
            ('alpha_rank', False),  # rank of the alpha peptide (alpha candidates are re-ranked
            # based on base seq)
            ('alpha_score', True),  # score of the alpha peptide
            ('beta_score', True),  # score of the beta peptide
            ('beta_count', False),  # number of beta peptides found for this alpha peptide
            ('beta_count_inverse', True),  # inverse of beta_count
            ('alpha_beta_rank', False),  # rank of the alpha beta candidate
            ('alpha_beta_score', True),  # score of the alpha beta candidate
        ]
        self.klasses = klasses
        # create a list of all score columns
        self.new_columns = [column for klass in self.klasses for column in klass.dtype]

        # get directionality - if it is not provided, assume all scores as higher is better
        self.new_columns_direction = [higher_is_better for klass in self.klasses
                                      for higher_is_better in
                                      (klass.higher_is_better
                                       if hasattr(klass, 'higher_is_better')
                                       else [True] * len(klass.dtype))]

        self.new_names = [c[0] for c in self.new_columns]
        self.new_types = [c[1] for c in self.new_columns]

        self.signed_int_columns = [i for i, t in enumerate(self.new_types)
                                   if np.issubdtype(t, np.signedinteger)]
        self.float_columns = [i for i, t in enumerate(self.new_types)
                              if np.issubdtype(t, np.floating)]

        # define defaults: -1 for signed ints, nan for floats and everything else 0
        self.new_defaults = np.zeros(len(self.new_columns))
        self.new_defaults[self.signed_int_columns] = -1
        self.new_defaults[self.float_columns] = np.nan
        # change from a 1d to a 2d array
        self.new_defaults = np.reshape(self.new_defaults, (len(self.new_defaults), 1))

        max_len = len(max(self.new_names + [x[0] for x in self.score_columns], key=len)) + 1
        # add the list of scores that go through this pipeline to the overall list
        score_set = set([x[0] for x in self.score_columns])
        self.score_columns.extend([s for s in zip(self.new_names, self.new_columns_direction) if
                                   s[0] not in score_set])
        self.score_columns = np.array(self.score_columns, dtype=[("column", f"<{str(max_len)}U"),
                                                                 ("higher_is_better", bool)])

        self.instances = [klass(context) for klass in self.klasses]

    def run(self, table, **kwargs):
        """
        Run the score pipeline, filling a row in the score table.

        :param table: (ndarray) alpha-beta score table
        :return: (ndarray) Score table with filled scores
        """
        new_table = self.build_new_table(table)
        for score_instance in self.instances:
            score_instance.calculate(new_table, **kwargs)
        return new_table

    def build_new_table(self, table):
        """
        Build the score table by adding all score fields of scores from the pipeline to the input.

        :param table: (ndarray) alpha-beta score table
        :return: (ndarray) score table with all new score fields (empty)
        """
        blank_data = np.full((len(self.new_columns), len(table)), self.new_defaults)
        new_table = recfunctions.append_fields(
            table,
            data=blank_data,
            names=self.new_names,
            dtypes=self.new_types,
            usemask=False
        )
        return new_table
