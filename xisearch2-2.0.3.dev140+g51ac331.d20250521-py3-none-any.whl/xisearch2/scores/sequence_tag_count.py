import numpy as np


def sequence_tag_count(annotations, pep_id, term):
    """
    Calculate the number of n- or c-terminal fragments that are part of a sequence tag.

    Sequence tags consist of at least 3 consecutive fragments for a peptide.
    Only primary (no neutral-loss) fragments are considered.
    :param annotations: (ndarray) Structured numpy array with fragment annotations
    :param pep_id: (int) Peptide id for which the tag count will be calculated
    :param term: (str) 'n' or 'c' terminus for which the tag count will be calculated
    :return: (int) number of sequence tag fragments
    """
    # create filter masks
    non_lossy_mask = annotations['nlosses'] == 0
    peptide_mask = annotations['pep_id'] == pep_id
    term_mask = annotations['term'] == term

    # filter annotations
    pep_annotations = annotations[peptide_mask & non_lossy_mask & term_mask]

    # use unique fragments
    unique_frags = np.unique(pep_annotations['idx'])

    # split data into consecutive arrays
    consec_frags = np.split(unique_frags, np.where(np.diff(unique_frags) != 1)[0] + 1)

    # filter out consecutive elements with length smaller than 3
    sequence_tag_arrs = [frags for frags in consec_frags if frags.size >= 3]
    if len(sequence_tag_arrs) == 0:
        return 0
    tag_data = np.hstack(sequence_tag_arrs)

    # return the number of sequence tag fragments
    return tag_data.size
