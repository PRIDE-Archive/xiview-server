import numpy as np
from xisearch2.scores.conservative_filter import conservative
from xisearch2.cython import isin_set_long_in_ushort, isin_set_ushort
from .base_annotation import BaseAnnotationScore


class SpectrumCoverageScore(BaseAnnotationScore):
    """
    Calculate the spectrum coverage scores.

    intensity_coverage: fraction of the total intensity that is explained
    primary_intensity_coverage: fraction of total intensity that is explained by primary
        fragments (non-neutral loss)
    conservative_intensity_coverage: fraction of total intensity that is explained by conservative
        fragments
    isotope_intensity_coverage: fraction of total intensity that is contained in isotope clusters
    isotope_intensity_matched_fraction: fraction of isotope cluster intensity that is explained by
        isotope cluster fragments
    isotope_peak_matched_fraction: fraction of all peaks that are explained by matched isotope
        cluster peaks
    single_peak_coverage: fraction of single peaks that are explained
    topN_peak_coverage: fraction of the top N peaks are explained
    topN_peak_coverage_limited: like topN_peak_coverage but the divisor is limited by the total
        number of peaks in the spectrum
    total_peak_coverage: fraction of the total number of peaks are explained
    """

    dtype = [
        ('intensity_coverage', np.float32),
        ('primary_intensity_coverage', np.float32),
        ('conservative_intensity_coverage', np.float32),
        ('isotope_intensity_coverage', np.float32),
        ('isotope_intensity_matched_fraction', np.float32),
        ('isotope_peak_matched_fraction', np.float32),
        ('single_peak_coverage', np.float32),
        ('top10_peak_coverage', np.float32),
        ('top10_peak_coverage_limited', np.float32),
        ('top20_peak_coverage', np.float32),
        ('top20_peak_coverage_limited', np.float32),
        ('top40_peak_coverage', np.float32),
        ('top40_peak_coverage_limited', np.float32),
        ('top100_peak_coverage', np.float32),
        ('top100_peak_coverage_limited', np.float32),
        ('total_peak_coverage', np.float32),
    ]

    def __init__(self, context):
        """
        Initialise the score.

        :param context: (Searcher) Search context
        """
        self.config = context.config

    def calculate_single(self, index, table, annotations, spectrum, **_):
        """
        Calculate and write the spectrum coverage scores into the score table.

        :param index: (int) Index into the score table to write
        :param table: (ndarray) Score table
        :param annotations: (ndarray) Structured numpy array with fragment annotations
        :param spectrum: (Spectrum) Spectrum
        """
        total_int = np.sum(spectrum.int_values)
        total_peaks = spectrum.int_values.size
        # indices of matched cluster peaks
        matched_cluster_peak_idx = np.where(np.isin(spectrum.isotope_cluster_peaks['cluster_id'],
                                                    annotations['cluster_id']))
        # get unique peak ids that are part of clusters that are matched
        matched_peak_ids = spectrum.isotope_cluster_peaks['peak_id'][matched_cluster_peak_idx]
        matched_peak_ids = np.unique(matched_peak_ids)

        # intensity coverage
        explained_int = np.sum(spectrum.int_values[matched_peak_ids])

        table['intensity_coverage'][index] = explained_int / total_int

        # primary intensity coverage
        primary_cluster_peak_idx = np.where(
            isin_set_ushort(spectrum.isotope_cluster_peaks['cluster_id'],
                            annotations['cluster_id'][annotations['nlosses'] == 0]))
        primary_peak_ids = spectrum.isotope_cluster_peaks['peak_id'][primary_cluster_peak_idx]
        primary_peak_ids = np.unique(primary_peak_ids)
        primary_explained_int = np.sum(spectrum.int_values[primary_peak_ids])
        table['primary_intensity_coverage'][index] = primary_explained_int / total_int

        # conservative intensity coverage
        conservative_annotations = conservative(annotations, self.config.conservative_n_multi_loss)

        conservative_cluster_ids = np.unique(conservative_annotations['cluster_id'])
        conservative_cluster_peak_idx = np.where(isin_set_ushort(
            spectrum.isotope_cluster_peaks['cluster_id'], conservative_cluster_ids))[0]
        conservative_peak_ids = spectrum.isotope_cluster_peaks['peak_id'][
            conservative_cluster_peak_idx]
        conservative_peak_ids = np.unique(conservative_peak_ids)
        conservative_explained_int = np.sum(spectrum.int_values[conservative_peak_ids])
        table['conservative_intensity_coverage'][index] = conservative_explained_int / total_int

        # isotope intensity coverage
        isotope_indices = np.where(spectrum.peak_has_cluster)
        isotope_total_int = np.sum(spectrum.int_values[isotope_indices])
        table['isotope_intensity_coverage'][index] = isotope_total_int / total_int

        # isotope intensity matched fraction
        # this compares the peak mz values in the annotations with the spectrum, and returns
        # a mask for the spectrum, True meaning the peak is in the annotation.
        if isotope_total_int == 0:
            table['isotope_intensity_matched_fraction'][index] = 0
            table['isotope_peak_matched_fraction'][index] = 0
        else:
            isotope_peak_in_annotations_ids = np.intersect1d(matched_peak_ids, isotope_indices,
                                                             assume_unique=True)
            isotope_explained_int = np.sum(spectrum.int_values[isotope_peak_in_annotations_ids])
            table['isotope_intensity_matched_fraction'][index] = \
                isotope_explained_int / isotope_total_int
            table['isotope_peak_matched_fraction'][index] = \
                len(isotope_peak_in_annotations_ids) / total_peaks

        # single peak coverage
        single_peak_count = len(spectrum.peak_has_cluster) - np.count_nonzero(
            spectrum.peak_has_cluster)
        if single_peak_count != 0:
            matched_peak_has_cluster = spectrum.peak_has_cluster[matched_peak_ids]

            matched_single_peak_count = len(matched_peak_has_cluster) - np.count_nonzero(
                matched_peak_has_cluster)
            table['single_peak_coverage'][index] = matched_single_peak_count / single_peak_count
        else:
            table['single_peak_coverage'][index] = 1
        # top n peak coverage
        if total_peaks <= 10:
            # if there are 10 or less peaks continue with all peaks
            # argpartition always returns np.int64 - so we keep here the same datatype
            topn_indices = np.arange(total_peaks, dtype=np.int64)
        else:
            # check which steps are necessary for sorting based on total number of peaks
            topn_steps = np.array([x for x in (10, 20, 40, 100) if x < total_peaks],
                                  dtype=matched_peak_ids.dtype)
            # Do a partial sort for the topn_steps most intense peaks
            topn_indices = np.argpartition(-spectrum.int_values, topn_steps)[:100]

        top_n_in_annotations_mask = isin_set_long_in_ushort(topn_indices, matched_peak_ids)

        for top_n in (10, 20, 40, 100):
            top_n_peaks_matched = np.count_nonzero(top_n_in_annotations_mask[:top_n])
            table[f'top{top_n}_peak_coverage'][index] = top_n_peaks_matched / top_n
            try:
                table[f'top{top_n}_peak_coverage_limited'][index] = \
                    top_n_peaks_matched / top_n_in_annotations_mask[:top_n].size
            except ZeroDivisionError:
                table[f'top{top_n}_peak_coverage_limited'][index] = 0

        # total peak coverage
        try:
            total_peak_coverage = matched_peak_ids.size / total_peaks
        except ZeroDivisionError:
            total_peak_coverage = 0
        table['total_peak_coverage'][index] = total_peak_coverage
