import numpy as np


class SumScore():
    """
    Base class for sum scores.

    Sum scores are simply the sum of two or more other scores.
    Using np.nansum, i.e. x + NaN = x
    """

    dtype = []
    sums = {}

    def __init__(self, _):
        """Initialise the score."""
        pass

    def calculate(self, table, **_):
        """
        Calculate and write the scores.

        :param table: (ndarray) score table
        :return: (ndarray) score table with added sum scores
        """
        for sum_score_name, summands in self.sums.items():
            accumulator = table[summands[0]]
            for summand in summands[1:]:
                dstacked = np.dstack([accumulator, table[summand]])
                accumulator = np.nansum(dstacked, 2)
            table[sum_score_name] = accumulator


class AlphaBetaSumScore(SumScore):
    """Calculate the alpha beta sum score."""

    dtype = [('alpha_beta_sum', np.float32)]

    sums = {'alpha_beta_sum': ['alpha_score', 'beta_score']}


class PeptidePairCounts(SumScore):
    """Calculate the peptide pair counts."""

    score_names = (
        'total_fragments', 'primary_fragments', 'loss_fragments', 'all_fragsites',
        'primary_fragsites', 'loss_fragsites', 'conservative_fragsites',
        'conservative_multi_fragsites', 'unique_peak_fragsites',
        'unique_peak_primary_fragsites', 'unique_peak_loss_fragsites',
        'unique_peak_conservative_fragsites', 'sequence_tag_fragsites',
        'unique_peak_primary_crosslink_fragsites', 'unique_peak_conservative_crosslink_fragsites'
    )

    dtype = [(s + '_pp', np.uint16) for s in score_names]

    sums = {f'{s}_pp': [f'{s}_p1', f'{s}_p2'] for s in score_names}
