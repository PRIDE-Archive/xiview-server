import numpy as np


def unique_peak(annotations):
    """
    Filter the annotations to `unique peak` annotations.

    Unique peak annotations means only one fragment per peak. If there is more than one fragment for
     a given peak the associated fragment will be chosen as follows.
        1. Fragment credibility score:
                primary with n neutral-loss fragment support:       50 + n * 2
                primary without neutral-loss support:               50
                neutral-loss fragment with primary support:         5
                neutral-loss fragment with neutral-loss support:    4
                neutral loss fragment without support:              2
                double fragmentation (ToDo: not yet supported):     0
        2. For fragments with same score:
                By lower match error
        3. For fragments with same score and match error (e.g. if both peptides share part of their
           sequence):
                fragment coming from the peptide with more total fragments
    :param annotations: (ndarray) Structured numpy array with fragment annotations
    :return: (ndarray) unique peak annotations array
    """
    # mask to compare fragments
    frag_compare_mask = ['frag_charge', 'term', 'idx', 'pep_id']

    # create separate table for extra fields
    table = np.empty(len(annotations), dtype=[
        ('score', np.uint16), ('n_frags', np.uint16), ('rel_error', np.float64)])

    # ToDo: default value needs to change from 2 to 0 once double fragmentation is integrated
    table['score'] = 2

    # Primary fragments
    primary_mask = annotations['nlosses'] == 0
    primary_frags = annotations[primary_mask]
    table['score'][primary_mask] = 50

    # Support
    #
    # primary with n loss support
    #
    # The following np.unique call does two things in one step. The results are:
    #
    # - unique_frags contains all unique frag_compare fragments
    #
    # - frag_counts contains, for each entry in unique_frags the number of times it was found
    #
    unique_frags, frag_counts = np.unique(annotations[frag_compare_mask], return_counts=True)

    # add 2 for each loss support
    for count in range(1, np.amax(frag_counts, initial=0)):
        n_support_frags = unique_frags[frag_counts > count]
        n_support_mask = np.isin(annotations[frag_compare_mask], n_support_frags)
        table['score'][n_support_mask & primary_mask] += 2

    # loss with primary support
    loss_frags = annotations[~primary_mask]
    primary_support_mask = ~primary_mask
    primary_support_mask[~primary_mask] = np.isin(loss_frags[frag_compare_mask],
                                                  primary_frags[frag_compare_mask])
    table['score'][primary_support_mask] = 5

    # loss with loss support
    #
    # The following np.unique call does two things in one step. The results are:
    #
    # - unique_loss_frags contains all unique frag_compare neutral-loss fragments
    #
    # - loss_frag_counts contains, for each entry in unique_loss_frags the number of times it was
    #   found
    #
    unique_loss_frags, loss_frag_counts = np.unique(loss_frags[frag_compare_mask],
                                                    return_counts=True)
    loss_supported_unique_frags = unique_loss_frags[loss_frag_counts > 1]
    loss_support_mask = ~primary_mask
    loss_support_mask[~primary_mask] = np.isin(loss_frags[frag_compare_mask],
                                               loss_supported_unique_frags)
    table['score'][loss_support_mask] = 4

    # add n_fragments
    for pep_id in np.unique(annotations['pep_id']):
        pep_id_mask = annotations['pep_id'] == pep_id
        table['n_frags'][pep_id_mask] = np.count_nonzero(pep_id_mask)

    # invert score and n_frags, so higher values come first
    table['score'] = -table['score']
    table['n_frags'] = -table['n_frags']

    # copy relative match error to use in sorting
    table['rel_error'] = annotations['rel_error']

    # order by 1. score, 2.second relative match error and 3. number of fragments of the peptide
    order = np.argsort(table, order=['score', 'rel_error', 'n_frags'])
    annotations = annotations[order]

    # create unique peak fragments
    # get the indices of the first fragment of every unique peak_mz value
    unique_peak_mz, unique_peak_frags_indices = np.unique(annotations['peak_mz'], return_index=True)

    # get the best annotation for every unique peak_mz value
    unique_peak_frags = annotations[unique_peak_frags_indices]

    return unique_peak_frags
