import numpy as np


class VarModCount:
    """
    Calculate the variable modification count of peptides.
    """
    dtype = [(f'var_mod_count_p{p}', np.uint8) for p in ('1', '2', 'p')]

    higher_is_better = [False] * len(dtype)

    def __init__(self, context):
        """Initialise the score."""
        self.peptide_db = context.peptide_db

    def calculate(self, table, **_):
        """
        Calculate the score.

        Actually transfers the the pre-calculated modification counts for each peptide from the
        peptide_db and calculates the sum for the overall match.

        :param table: (ndarray) score table
        :return: (ndarray) score table with added delta scores
        """
        for p in ['p1', 'p2']:
            table[f'var_mod_count_{p}'] = self.peptide_db.peptides[
                table[f'{p}_index']]['var_mod_count']

        linear_mask = table['p2_index'] == -1
        table['var_mod_count_p2'][linear_mask] = 0

        # calculate var_mod_count_pp
        table['var_mod_count_pp'] = table['var_mod_count_p1'] + table['var_mod_count_p2']
