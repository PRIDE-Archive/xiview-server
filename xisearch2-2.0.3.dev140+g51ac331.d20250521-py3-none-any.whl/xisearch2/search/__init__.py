"""Module containing the search set up and the actual search."""
from xisearch2.search.search_context import *
from xisearch2.search.spectrum_processor import *
