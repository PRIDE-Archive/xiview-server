"""
The SearchContext sets up the various data structures that are needed to do a search.

The main structures are:
    - Fragment DB
    - Peptide DB
    - sites db
    - fixed_mod_table
"""
import re
import numpy as np
from dirlock import DirLock

from xisearch2 import fasta_reader, const
from xisearch2.digestor import Digestor
from xisearch2.filters import IsotopeDetector, ChargeReducer, \
    ChargeBasedLinearisationFilter, MassBasedLinearisationFilter, DenoiseFilter, LossClusterFilter
from xisearch2.xi_logging import log
from xisearch2.lookup import FragmentDatabase, PeptideDatabase
from xisearch2.modifications import Modifier, modified_peptides_from_fixed_mod_sequences
from xisearch2.scores import ScorePipeline, \
    Ms1MassErrorScore, Ms2MassErrorScore, \
    PeptidePairCounts, CoverageScore, DeltaScore, FragmentOccurrenceCount, FragmentChargeScore, \
    SpectrumCoverageScore, BetaScore, AlphaBetaSumScore, CleavedCrosslinkerPeptideFragmentScore, \
    MatchScore, MatchDeltaScore, CombinedScores, FragmentLibraryScore, AutoValidationScore, \
    VarModCount
from xisearch2.proteindecoy import permutate_decoy_sequence
from xisearch2.utils import boolean_group
from xisearch2 import dtypes
from xisearch2.cython import Fragmentation
from uuid import uuid4


class SearchContext:
    """Search context that holds search related data (config and database)."""

    def __init__(self, fasta_files, config, cache, search_uuid=None,
                 all_tasks=1, this_task=0):
        """
        Initialise the Search Context class.

        :param fasta_files: (str | list of str) path(s) to FASTA file(s) for proteins
        :param config: (Configuration) search configuration
        :param cache: (Cache) Cache to use for prepared search data
        """
        self.config = config

        # set up dictionary of tolerances and errors for easy
        self.set_tolerances_and_errors()

        # create Modifier
        self.modifier = Modifier(self)

        # create Digestor
        self.digestor = Digestor(self)

        # if a search_uuid was given as argument use that one
        if search_uuid is not None:
            self.search_uuid = search_uuid
            self.result_set_uuid = search_uuid
        else:
            # Global search and result set UUID
            self.search_uuid = uuid4()
            # keep the search and the result set uid in sync to make downstream analysis easier
            self.result_set_uuid = self.search_uuid

        # Load target proteins
        log("Loading FASTA file(s)")
        input_fasta = fasta_reader.FastaReader(self.config)
        input_fasta.load_file(fasta_files)

        # reformatting to array
        input_fasta.reformat_to_array()
        log("Loaded %d proteins from FASTA file" % len(input_fasta.arr_fasta))

        # Generate hash for parameters affecting the protein database
        protein_cache_version = 1
        protein_hash = hash((protein_cache_version, input_fasta.hash(), self.config.decoy.hash()))
        proteins_cache = cache.item('proteins', protein_cache_version, protein_hash, '.npy')

        cache_lockdir = f'{proteins_cache.load_filename}.lock'
        cache_lock = DirLock(cache_lockdir)
        cache_lock.acquire()
        if proteins_cache.exists:
            cache_lock.release()
            log("Loading cached protein database (targets & decoys)")
            self.proteins = np.load(proteins_cache.load_filename)
        else:
            log("Create protein database (targets & decoys)")
            # create decoys ToDo: additional decoy generation functions + config option
            input_fasta.add_decoys()
            self.proteins = input_fasta.arr_fasta
            np.save(proteins_cache.save_filename, self.proteins)
            proteins_cache.validate()
            cache_lock.release()

        protein_sequences = self.proteins['sequence']
        self.modified_proteins = self.modifier.apply_protein_fixed_mods(protein_sequences)
        # convert modified proteins to list of modified amino acids
        log("Converting modified protein strings to lists of modified amino acids")
        self.modified_proteins = [const.MODIFIED_AA_PATTERN.findall(p) for p in
                                  self.modified_proteins]

        # Generate hash for parameters affecting peptide sequences with fixed mods
        fixed_mod_peptides_cache_version = 2
        fixed_mod_peptides_hash = hash((fixed_mod_peptides_cache_version,
                                        protein_hash, config.modification.hash(),
                                        config.digestion.hash()))
        fixed_mod_peptides_cache = cache.item(
            'fixed_mod_peptide_sequences', fixed_mod_peptides_cache_version,
            fixed_mod_peptides_hash, '.npy')

        peptide_sites_cache = cache.item(
            'peptide_sites', fixed_mod_peptides_cache_version, fixed_mod_peptides_hash, '.npy')
        permuted_decoy_protein_cache = cache.item(
            'permuted_decoy_proteins', fixed_mod_peptides_cache_version,
            fixed_mod_peptides_hash, '.npy')

        # Get peptides after digestion, including fixed but not variable modifications
        # Locking cache one should suffice
        cache_lockdir = f'{fixed_mod_peptides_cache.load_filename}.lock'
        cache_lock = DirLock(cache_lockdir)
        cache_lock.acquire()
        if fixed_mod_peptides_cache.exists and peptide_sites_cache.exists and \
                permuted_decoy_protein_cache.exists:
            cache_lock.release()
            log("Loading cached peptide sequences with fixed modifications")
            self.fixed_mod_peptide_sequences = \
                np.load(fixed_mod_peptides_cache.load_filename)
            self.sites = np.load(peptide_sites_cache.load_filename)
            # load the permuted proteins and append them to the existing ones
            permuted_proteins = np.load(permuted_decoy_protein_cache.load_filename)
            self.proteins = np.hstack([self.proteins, permuted_proteins])
        else:
            log("Digesting protein sequences in-silico")
            self.fixed_mod_peptide_sequences, self.sites = \
                self.digestor.cleave(self.modified_proteins)

            # permutate decoy sequences that match target sequences
            # Note: This updates self.proteins (adding new proteins for permuted sequences),
            # self.fixed_mod_peptide_sequences and self.sites.
            # The newly created proteins are returned, so we can save them
            log("Checking decoy sequences for overlap with targets")
            permuted_proteins = permutate_decoy_sequence(self)

            # save data
            np.save(permuted_decoy_protein_cache.save_filename, permuted_proteins)
            permuted_decoy_protein_cache.validate()
            np.save(fixed_mod_peptides_cache.save_filename,
                    self.fixed_mod_peptide_sequences)
            fixed_mod_peptides_cache.validate()
            self.sites.sort(axis=0, order='peptide_id')
            np.save(peptide_sites_cache.save_filename, self.sites)
            peptide_sites_cache.validate()
            cache_lock.release()

        log("Found %d unique peptides from %d possible digestion sites" % (
            len(self.fixed_mod_peptide_sequences), len(self.sites)))

        # Get unique unmodified sequences of peptides
        unmodified_peptide_sequences_cache = cache.item(
            'unmodified_peptide_sequences', fixed_mod_peptides_cache_version,
            fixed_mod_peptides_hash, '.npy')
        cache_lockdir = f'{unmodified_peptide_sequences_cache.load_filename}.lock'
        cache_lock = DirLock(cache_lockdir)
        cache_lock.acquire()
        if unmodified_peptide_sequences_cache.exists:
            cache_lock.release()
            log("Loading cached unmodified peptide sequence data")
            self.unmodified_peptide_sequences = \
                np.load(unmodified_peptide_sequences_cache.load_filename)
        else:
            # Extract unique unmodified sequences
            log("Finding unique unmodified sequences")
            self.unmodified_peptide_sequences = np.unique(
                [re.sub(b'[^A-Z]', b'', sequence) for sequence in self.fixed_mod_peptide_sequences])
            # Save unmodified sequences
            np.save(unmodified_peptide_sequences_cache.save_filename,
                    self.unmodified_peptide_sequences)
            unmodified_peptide_sequences_cache.validate()
            cache_lock.release()

        log("Found %d unique unmodified sequences" % len(self.unmodified_peptide_sequences))

        self.unmodified_peptide_sequences.flags.writeable = False
        # Generate hash for parameters affecting modified peptides after variable mods
        modified_peptides_cache_version = 2
        modified_peptides_hash = hash(
            (modified_peptides_cache_version, fixed_mod_peptides_hash, config.modification.hash(),
             config._settings['crosslinker'].hash(config.crosslinker))
        )
        self.modified_peptides_cache = cache.item(
            'modified_peptides', modified_peptides_cache_version,
            modified_peptides_hash, '.npy')
        site_info_table_cache = cache.item('site_info_table', modified_peptides_cache_version,
                                           modified_peptides_hash, '.npy')
        # Get modified peptides, including both fixed and variable modifications
        # Locking cache one should suffice
        cache_lockdir = f'{self.modified_peptides_cache.load_filename}.lock'
        cache_lock = DirLock(cache_lockdir)
        cache_lock.acquire()
        if self.modified_peptides_cache.exists and site_info_table_cache.exists:
            cache_lock.release()
            log("Loading cached modified peptide data")
            self.modified_peptides = np.load(self.modified_peptides_cache.load_filename)
            self.site_info_table = np.load(site_info_table_cache.load_filename)
        else:
            # create table with fixed_mod_peptide_sequences and all corresponding sites.
            # Sites are ordered by pep_id and then first and last index into the ordered sites array
            # is stored
            log("Finding mapping to unique peptide indices from %d digestion sites"
                % len(self.sites))
            unique_sites_pepids, sites_indices, sites_counts = np.unique(
                self.sites['peptide_id'], return_index=True, return_counts=True)
            log("Found mappings to %d unique peptide indices" % (len(unique_sites_pepids)))

            log("Building site index table")
            self.site_info_table = np.empty(self.fixed_mod_peptide_sequences.size,
                                            dtype=dtypes.site_info_table)
            fixed_mod_peptides = modified_peptides_from_fixed_mod_sequences(
                self.unmodified_peptide_sequences, self.fixed_mod_peptide_sequences, config)
            self.site_info_table['sequence_index'] = fixed_mod_peptides['sequence_index']
            self.site_info_table['sites_first_idx'] = sites_indices
            sites_last_indices = sites_indices + sites_counts - 1
            self.site_info_table['sites_last_idx'] = sites_last_indices

            # set flags for whether the peptides occur as nterm or cterm and blocked amino acids
            nterm = boolean_group(self.sites['nterm'], sites_indices, sites_last_indices)
            # conversion to bool equals any()
            self.site_info_table['nterm'] = nterm.astype(bool)

            cterm = boolean_group(self.sites['cterm'], sites_indices, sites_last_indices)
            # conversion to bool equals any()
            self.site_info_table['cterm'] = cterm.astype(bool)

            cterm_block = boolean_group(self.sites['cterm_aa_block'], sites_indices,
                                        sites_last_indices)
            # If all sites for a peptide are True it is blocked (equals an boolean all()).
            self.site_info_table['cterm_aa_block'] = cterm_block == sites_counts

            nterm_block = boolean_group(self.sites['nterm_aa_block'], sites_indices,
                                        sites_last_indices)
            # If all sites for a peptide are True it is blocked (equals an boolean all()).
            self.site_info_table['nterm_aa_block'] = nterm_block == sites_counts

            # apply remaining modifications
            self.modified_peptides = self.modifier.apply_remaining_mods(fixed_mod_peptides,
                                                                        self.site_info_table)

            # Save modified peptides
            np.save(self.modified_peptides_cache.save_filename, self.modified_peptides)
            self.modified_peptides_cache.validate()
            np.save(site_info_table_cache.save_filename, self.site_info_table)
            site_info_table_cache.validate()
            cache_lock.release()

        log("Found %d modified peptides after applying variable modifications" % (
            len(self.modified_peptides)))

        # create amino acid lengths array that corresponds to modified_peptides
        self.peptide_aa_lengths = np.char.str_len(self.unmodified_peptide_sequences)
        self.modified_peptides_aa_lengths = self.peptide_aa_lengths[
            self.modified_peptides['sequence_index']]

        # Build/load peptide DB
        peptide_db_cache = cache.item('peptide_db', modified_peptides_cache_version,
                                      modified_peptides_hash)
        cache_lockdir = f'{peptide_db_cache.load_filename}.lock'
        cache_lock = DirLock(cache_lockdir)
        cache_lock.acquire()
        if peptide_db_cache.exists:
            cache_lock.release()
            log("Loading cached peptide mass database")
            self.peptide_db = PeptideDatabase(self, mode='load',
                                              dirname=peptide_db_cache.load_filename)
        else:
            log("Building peptide mass database")
            self.peptide_db = PeptideDatabase(self, mode='save',
                                              dirname=peptide_db_cache.save_filename)
            peptide_db_cache.validate()
            cache_lock.release()
        log("Peptide database ready, %d entries" % len(self.peptide_db.masses))

        # Generate hash for parameters affecting fragments
        fragment_db_cache_version = 3
        fragments_hash = hash((fragment_db_cache_version, modified_peptides_hash,
                               config.fragmentation.hash()))

        # Build/load fragment DB
        fragment_db_cache = cache.item('fragment_db', fragment_db_cache_version, fragments_hash)
        cache_lockdir = f'{fragment_db_cache.load_filename}.lock'
        cache_lock = DirLock(cache_lockdir)
        cache_lock.acquire()
        if fragment_db_cache.exists:
            cache_lock.release()
            log("Loading cached fragment mass database")
            self.fragment_db = FragmentDatabase(self, mode='load',
                                                dirname=fragment_db_cache.load_filename)
        else:
            log("Building fragment mass database")
            self.fragment_db = FragmentDatabase(self, mode='save',
                                                dirname=fragment_db_cache.save_filename)
            fragment_db_cache.validate()
            cache_lock.release()
        log("Fragment database ready, %d entries" % len(self.fragment_db.masses))

        # initialize isotope detector and reducer
        self.detector = IsotopeDetector(self)
        self.charge_filter = ChargeReducer(self)
        if self.config.linearisation == 'charge':
            self.linearisation_filter = ChargeBasedLinearisationFilter(self)
        elif self.config.linearisation == 'mass':
            self.linearisation_filter = MassBasedLinearisationFilter(self)
        self.alpha_denoise_filter = DenoiseFilter(self, 'denoise_alpha')
        self.alpha_beta_denoise_filter = DenoiseFilter(self, 'denoise_alpha_beta')
        self.loss_cluster_filter = LossClusterFilter(self)
        self.ms2_mass_error_calculator = Ms2MassErrorScore(self)

        # initialize scores
        self.beta_score = BetaScore(self)

        scores = [FragmentOccurrenceCount, Ms2MassErrorScore, FragmentChargeScore,
                  SpectrumCoverageScore, AlphaBetaSumScore, DeltaScore, Ms1MassErrorScore,
                  PeptidePairCounts, CoverageScore, MatchScore, MatchDeltaScore,
                  FragmentLibraryScore, CombinedScores, AutoValidationScore, VarModCount]
        if hasattr(self.config, 'crosslinker') and \
                any([cl.cleavable for cl in self.config.crosslinker]):
            scores.append(CleavedCrosslinkerPeptideFragmentScore)
        self.score_pipeline = ScorePipeline(self, *scores)

        self.links_writer = None

        self.fragmentation = Fragmentation(self)

        self.cluster = {"all_tasks": all_tasks, "this_task": this_task}

    def get_sites_for_mod_pep_index(self, pep_index):
        """
        Return the protein sites for the given modified peptide.

        :param pep_index: (int) index of the modified peptide
        :return: (ndarray) protein sites
        """
        sites_idx = self.modified_peptides[pep_index]['site_info_idx']
        site_info = self.site_info_table[sites_idx]
        return self.sites[site_info['sites_first_idx']:site_info['sites_last_idx']+1]

    def get_site_info_for_mod_pep_index(self, pep_index):
        """
        Return the site info table entry of the modified peptide.

        :param pep_index: (int) index of the modified peptide
        :return: site info table entry
        :rtype: struct ndarray
            sequence_index (intp) index into the base sequence
            sites_first_idx (intp) first index into peptide sites (Searcher.sites)
            sites_last_idx (intp) last index into peptide sites (Searcher.sites)
            nterm (bool_) if the peptide occurs n-terminal (on any protein)
            cterm (bool_) if the peptide occurs c-terminal (on any protein)
            nterm_aa_block (bool_) nterm aa is blocked on all proteins
            cterm_aa_block (bool_) cterm aa is blocked on all proteins
        """
        return self.site_info_table[self.modified_peptides[pep_index]['site_info_idx']]

    def set_tolerances_and_errors(self):
        """Create dictionary with file-specific tolerances from recalibration in config"""
        self._atolerances_ms1 = {}
        self._atolerances_ms2 = {}
        self._rtolerances_ms1 = {}
        self._rtolerances_ms2 = {}
        self._isotope_rtol = {}

        # store default tolerances and errors for fast access
        # the instance variable is about 10 % faster than the instance instance variable
        # 86.98 ms vs 76.13 ms for 1000000 iterations
        # TODO necessary?
        self._default_rtolerances_ms1 = self.config.ms1_rtol
        self._default_rtolerances_ms2 = self.config.ms2_rtol
        self._default_atolerances_ms1 = self.config.ms1_atol
        self._default_atolerances_ms2 = self.config.ms2_atol
        self._default_isotope_rtol = self.config.isotope_config.rtol

    def get_ms1_rtol(self, file):
        """Get the relative tolerance for MS1 for the given file."""
        return self._rtolerances_ms1.get(file, self._default_rtolerances_ms1)

    def get_ms1_atol(self, file):
        """Get the absolute tolerance for MS1 for the given file."""
        return self._atolerances_ms1.get(file, self._default_atolerances_ms1)

    def get_ms2_rtol(self, file):
        """Get the relative tolerance for MS2 for the given file."""
        return self._rtolerances_ms2.get(file, self._default_rtolerances_ms2)

    def get_ms2_atol(self, file):
        """Get the absolute tolerance for MS2 for the given file."""
        return self._atolerances_ms2.get(file, self._default_atolerances_ms2)

    def get_isotope_rtol(self, file):
        """Get the relative tolerance for isotope detection for the given file."""
        return self._isotope_rtol.get(file, self._default_isotope_rtol)
